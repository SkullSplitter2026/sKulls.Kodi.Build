# -*- coding: utf-8 -*-
"""
Debrid-Konten (Punkt 183): Restlaufzeit von Real-Debrid, Premiumize, AllDebrid, TorBox und Debrid-Link anzeigen
und rechtzeitig erinnern.

Die Anmeldung (Token/API-Schlüssel) steht schon in den Addons (ResolveURL, Fen, Umbrella …) oder unter „Zugänge &
API-Schlüssel“. Der Wizard fragt damit nur die Konto-Seite des jeweiligen Dienstes ab (https, offizielle Adresse) -
gespeichert werden nur Dienst, Ablaufdatum und Addon, nie der Token.
"""

import calendar
import re
import time

from resources.lib import accounts
from resources.lib.common import load_state, log, save_state
from resources.lib.texts import T

# Dienst -> Name, Konto-Adresse, Art der Anmeldung
SERVICES = [
    ("realdebrid", "Real-Debrid", "https://api.real-debrid.com/rest/1.0/user"),
    ("premiumize", "Premiumize", "https://www.premiumize.me/api/account/info"),
    ("alldebrid", "AllDebrid", "https://api.alldebrid.com/v4/user?agent=kodiwizard"),
    ("torbox", "TorBox", "https://api.torbox.app/v1/api/user/me"),
    ("debridlink", "Debrid-Link", "https://debrid-link.com/api/v2/account/infos"),
]
MATCH = {"realdebrid": r"realdebrid|real_debrid|(^|_)rd(_|$)", "premiumize": r"premiumize|(^|_)pm(_|$)",
         "alldebrid": r"alldebrid|all_debrid|(^|_)ad(_|$)", "torbox": r"torbox|(^|_)tb(_|$)",
         "debridlink": r"debrid_?link|debridlink|(^|_)dl(_|$)"}
TOKEN = re.compile(r"token|api_?key|apikey|(^|_)key$")
NOT_TOKEN = re.compile(r"refresh|client|secret|expir|date|user|name|enable|priority|order|auth_?url|device|code")
MAX_TRIES = 6
DAY = 86400


def _iso(text):
    """„2026-11-05T12:00:00.000Z“ -> Unix-Zeit (UTC)"""
    match = re.match(r"(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2}):(\d{2}))?", str(text or ""))
    if not match:
        return 0
    parts = [int(x or 0) for x in match.groups()]
    return calendar.timegm((parts[0], parts[1], parts[2], parts[3], parts[4], parts[5], 0, 0, 0))


def parse(key, status, data):
    """Antwort eines Dienstes -> (gültig?, Premium?, Ablauf als Unix-Zeit oder 0). None = Anmeldung abgelehnt"""
    data = data if isinstance(data, dict) else {}
    now = time.time()
    if status in (401, 403):
        return None
    if key == "realdebrid" and status == 200 and "username" in data:
        expires = _iso(data.get("expiration"))
        return True, data.get("type") == "premium" and expires > now, expires
    if key == "premiumize" and data.get("status") == "success":
        expires = int(data.get("premium_until") or 0)
        return True, expires > now, expires
    if key == "alldebrid":
        if data.get("status") != "success":
            return None
        user = (data.get("data") or {}).get("user") or {}
        expires = int(user.get("premiumUntil") or 0)
        return True, bool(user.get("isPremium")) and (not expires or expires > now), expires
    if key == "torbox" and data.get("success"):
        info = data.get("data") or {}
        expires = _iso(info.get("premium_expires_at"))
        return True, bool(info.get("plan")) and expires > now, expires
    if key == "debridlink" and data.get("success"):
        left = int((data.get("value") or {}).get("premiumLeft") or 0)
        return True, left > 0, int(now + left) if left > 0 else 0
    if data.get("status") == "error" or data.get("success") is False:
        return None
    return False, False, 0           # unbekannte Antwort - später erneut versuchen


def candidates(key, addons=None, data_root=None):
    """Anmeldungen eines Dienstes aus den Addons und den gespeicherten Zugängen: [(Wert, Addon)]"""
    found, seen = [], set()
    stored = (accounts.load().get(key) or {}).get("key", "").strip()
    if stored:
        found.append((stored, T("Zugänge")))
        seen.add(stored)
    pattern = re.compile(MATCH[key])
    for addon_id, folder in addons if addons is not None else accounts.installed_addons():
        values = accounts.current_values(addon_id, data_root)
        for sid in accounts.setting_ids(folder):
            norm = accounts.norm(sid)
            value = (values.get(sid) or "").strip()
            if value and len(value) >= 12 and pattern.search(norm) and TOKEN.search(norm) \
                    and not NOT_TOKEN.search(norm) and value not in seen:
                seen.add(value)
                found.append((value, addon_id))
    return found


def _ask(key, url, value, call):
    """Konto-Seite mit einer Anmeldung abfragen - Bearer-Kopfzeile, Premiumize zusätzlich als apikey"""
    from urllib.parse import quote
    status, data = call(url, headers={"Authorization": "Bearer " + value})
    result = parse(key, status, data)
    if result is None and key == "premiumize":
        status, data = call(url + "?apikey=" + quote(value, safe=""))
        result = parse(key, status, data)
    return result


def check(progress=None, call=None, addons=None, data_root=None):
    """Alle Dienste mit Anmeldung prüfen und das Ergebnis (ohne Tokens) merken.
    Rückgabe: [{"key", "name", "ok", "premium", "expires", "source", "error"}]"""
    from resources.lib import net
    call = call or net.call_api
    addons = addons if addons is not None else accounts.installed_addons()
    result = []
    for number, (key, name, url) in enumerate(SERVICES):
        if progress:
            progress(number * 100 // len(SERVICES), name)
        found = candidates(key, addons, data_root)
        if not found:
            continue
        entry = {"key": key, "name": name, "ok": False, "premium": False, "expires": 0, "source": "", "error": ""}
        for value, source in found[:MAX_TRIES]:
            try:
                answer = _ask(key, url, value, call)
            except Exception as e:  # noqa: BLE001 - keine Verbindung
                entry["error"] = str(e)
                break
            if answer and answer[0]:
                entry.update(ok=True, premium=answer[1], expires=answer[2], source=source, error="")
                break
            entry["error"] = T("Anmeldung abgelaufen oder ungültig - im Addon neu anmelden")
        result.append(entry)
    state = load_state()
    state["debrid"] = {"checked": time.time(),
                       "accounts": [{k: e[k] for k in ("key", "name", "ok", "premium", "expires", "source")}
                                    for e in result]}
    save_state(state)
    log("Debrid geprüft: {0}".format(", ".join("{0} {1}".format(e["name"], days_left(e) if e["ok"] else "-")
                                              for e in result) or "keine Anmeldung"))
    return result


def days_left(entry, now=None):
    """Ganze Tage bis zum Ablauf (0 = heute, negativ = abgelaufen); None = ohne Ablaufdatum"""
    expires = entry.get("expires") or 0
    if not expires:
        return None
    return int((expires - (now or time.time())) // DAY)


def status_text(entry):
    if not entry.get("ok"):
        return T("Anmeldung ungültig")
    days = days_left(entry)
    if not entry.get("premium") or (days is not None and days < 0):
        return T("abgelaufen")
    if days is None:
        return T("Premium aktiv")
    when = time.strftime("%d.%m.%Y", time.localtime(entry["expires"]))
    return T("noch {0} Tage (bis {1})").format(days, when) if days != 1 else T("noch 1 Tag (bis {0})").format(when)


def summary(stored):
    """Kurzfassung für die Zeile in Save Data: „Real-Debrid: noch 23 Tage · TorBox: abgelaufen“"""
    entries = stored.get("accounts") or []
    if not stored.get("checked"):
        return ""
    if not entries:
        return T("keine Anmeldung gefunden")
    return "  ·  ".join("{0}: {1}".format(e["name"], status_text(e)) for e in entries)


def report(result):
    if not result:
        return T("In keinem Addon ist ein Debrid-Konto angemeldet (Real-Debrid, Premiumize, AllDebrid, TorBox, "
                 "Debrid-Link). Anmelden z.B. in ResolveURL: Konto verknüpfen.")
    lines = []
    for e in result:
        days = days_left(e)
        color = "FF5FD38D" if e["ok"] and e["premium"] and (days is None or days > 7) else \
            "FFFFCC4D" if e["ok"] and e["premium"] else "FFFF6B6B"
        lines.append("[B]{0}[/B]  [COLOR {1}]{2}[/COLOR]".format(e["name"], color, status_text(e)))
        if e.get("source"):
            lines.append("   " + T("Anmeldung aus: {0}").format(e["source"]))
        if e.get("error"):
            lines.append("   " + e["error"])
        lines.append("")
    lines.append(T("Erinnerung: Einstellungen > An Debrid-Ablauf erinnern."))
    return "[CR]".join(lines)


def due_reminders(state, now=None):
    """Konten, an die heute erinnert werden soll: [(Eintrag, Tage)] - einmal am Tag je Konto"""
    days_before = int(state.get("debrid_days", 7) or 0)
    if not days_before:
        return []
    today = time.strftime("%Y-%m-%d", time.localtime(now or time.time()))
    told = state.get("debrid_told") or {}
    result = []
    for entry in (state.get("debrid") or {}).get("accounts") or []:
        days = days_left(entry, now)
        if entry.get("ok") and days is not None and days <= days_before and days >= -3 \
                and told.get(entry["key"]) != today:
            result.append((entry, days))
    return result


def remind(notify, now=None):
    """Täglich im Dienst: Restlaufzeit neu abfragen (höchstens alle 20 Stunden) und erinnern. notify(Text)"""
    state = load_state()
    if not int(state.get("debrid_days", 7) or 0):
        return 0
    checked = (state.get("debrid") or {}).get("checked") or 0
    if (now or time.time()) - checked > 20 * 3600:
        check()
        state = load_state()
    due = due_reminders(state, now)
    if not due:
        return 0
    told = state.get("debrid_told") or {}
    today = time.strftime("%Y-%m-%d", time.localtime(now or time.time()))
    for entry, days in due:
        if days < 0:
            notify(T("{0}: Premium ist abgelaufen - bitte verlängern").format(entry["name"]))
        elif days == 0:
            notify(T("{0}: Premium endet heute").format(entry["name"]))
        else:
            notify(T("{0}: Premium endet in {1} Tagen").format(entry["name"], days))
        told[entry["key"]] = today
    state["debrid_told"] = told
    save_state(state)
    return len(due)
