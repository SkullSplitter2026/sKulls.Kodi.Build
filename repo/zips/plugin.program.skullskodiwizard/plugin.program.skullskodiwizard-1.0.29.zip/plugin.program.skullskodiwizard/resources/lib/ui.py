# -*- coding: utf-8 -*-
"""
Wizard-Zentrale: ein Vollbild-Fenster (sk_main.xml), unabhängig vom installierten Skin.

Aufbau:  100 = Menü links,  150 = Unter-Tabs (Wartung),  200 = Kacheln (Builds, Addons, Werkzeuge),
         210 = Zeilen (Einstellungen, Save Data, Backups, Kontakt ...)
Zeilen haben eine Art (Property "kind"): action, toggle, choice (mit Links/Rechts umschalten), info, header.
"""

import os
import re
import time

import xbmc
import xbmcgui

from resources.lib import backup, builds, config, dialogs, maintenance, savedata, tuning
from resources.lib.common import (ADDON_NAME, ADDON_VERSION, ADDON_PATH, INTERVALS, human_size, kill_kodi,
                                  kodi_major, load_state, log, log_error, save_state)
from resources.lib.texts import T

MENU, SUBTABS, TILES, ROWS = 100, 150, 200, 210
LEFT, RIGHT, UP, DOWN = 1, 2, 3, 4
BACK = (9, 10, 92)
HELP_ACTIONS = (11, 117)       # Info-Taste, Kontextmenü (langes Drücken von OK auf vielen Fernbedienungen)
MENU_ITEMS = [("builds", "Builds", "builds"), ("info", "Build-Info", "info"), ("gui", "GUI-Fix", "gui"),
              ("addons", "Addons", "addons"),
              ("maint", "Wartung", "maint"), ("backup", "Backup/Restore", "backup"), ("save", "Save Data", "save"),
              ("settings", "Einstellungen", "settings"), ("contact", "Kontakt", "contact")]
MAINT_TABS = [("clean", "Bereinigen"), ("addon", "Addon-Werkzeuge"), ("log", "Protokolle"),
              ("tweak", "System-Optimierung"), ("misc", "Sonstiges")]
QUICK_PREFIXES = ("clean_", "addon_", "log_", "tweak_", "misc_")
QUICK_EXCLUDE = {"misc_fresh", "misc_quit", "misc_reload", "misc_addondb", "clean_all", "clean_thumbs"}
INTERVAL_TEXT = {"never": "Nie", "start": "Bei jedem Start", "daily": "Täglich", "3days": "Alle 3 Tage",
                 "weekly": "Wöchentlich", "monthly": "Monatlich"}
SAVE_TEXT = [("addons", "Addon-Einstellungen"), ("favourites", "Favoriten"), ("sources", "Quellen (sources.xml)"), ("profiles", "Profile"),
             ("advancedsettings", "advancedsettings.xml"), ("whitelist", "Addons behalten (Whitelist)")]


ICONS = os.path.join(ADDON_PATH, "resources", "skins", "Default", "media", "icons")


def icon(name):
    return os.path.join(ICONS, name + ".png")


def is_colored(path):
    """Buntes Symbol (eigenes Bild oder bunte Kachel aus dem Forge) - wird nicht eingefärbt"""
    if not path.startswith(ICONS):
        return False
    colored = (config.get("icons") or {}).get("colored") or []
    return os.path.splitext(os.path.basename(path))[0] in colored


def _item(label, label2="", kind="action", key="", art="", detail="", badge="", fanart="", chip=""):
    item = xbmcgui.ListItem(T(label) if label else "", label2)
    item.setProperty("kind", kind)
    item.setProperty("key", key)
    if detail:
        item.setProperty("detail", detail)
    if badge:
        item.setProperty("badge", badge)
    if chip:
        item.setProperty("chip", chip)       # Abzeichen oben rechts: Neu, Update, Empfohlen
    images = {}
    if art:
        images.update(thumb=art, icon=art)
        if art.startswith(ICONS):
            item.setProperty("glyph", "true")   # Symbol aus dem Wizard: in Akzentfarbe einfärben ...
            if is_colored(art):
                item.setProperty("colored", "true")     # ... außer es ist bunt
    if fanart:
        images["fanart"] = fanart
    if images:
        item.setArt(images)
    return item


LAYOUT_TEXT = {"tiles": "Große Kacheln", "small": "Kleine Kacheln", "list": "Liste"}
LAYOUT_KEYS = ["tiles", "small", "list"]
# Kategorien/Zweck eines Builds (Punkt 166)
CATEGORY_NAMES = {"leicht": "Leicht", "sport": "Sport", "kinder": "Kinder", "musik": "Musik",
                  "4k": "4K", "film": "Film & Serie", "live": "Live-TV"}
NEW_DAYS = 14          # so lange gilt ein Build als „Neu“


def current_layout():
    """Ansicht der Kacheln: Wahl im Wizard, sonst die Vorgabe aus dem Forge"""
    value = load_state().get("layout") or config.get("layout") or "tiles"
    return value if value in LAYOUT_TEXT else "tiles"


def _is_new(build):
    try:
        built = time.mktime(time.strptime(str(build.get("built", ""))[:10], "%Y-%m-%d"))
    except (ValueError, OverflowError):
        return False
    return time.time() - built < NEW_DAYS * 86400


def _point_text(path):
    """„vom 05.10.2026 14:30 (Vor Build-Installation)“"""
    when = time.strftime("%d.%m.%Y %H:%M", time.localtime(os.path.getmtime(path)))
    name = backup.get_name(path)
    return T("vom {0}").format(when) + (" ({0})".format(name) if name else "")


class Main(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.view = kwargs.get("start", "builds")
        self.subtab = "clean"
        self.row_keys = []
        self.tile_keys = []
        self.error = ""
        self.colors = config.get("colors") or {}

    # ---------- Aufbau ----------
    def update_header(self):
        """Kopfzeile: Kodi-Version, installierter Build, Hinweis auf verfügbare Updates"""
        state = load_state()
        current = state.get("build")
        info = "Kodi {0}".format(xbmc.getInfoLabel("System.BuildVersion").split(" ")[0])
        if current:
            info += " · " + T("Build") + ": {0} {1}".format(current.get("name", ""), current.get("version", ""))
        if state.get("updates"):
            info += " · [COLOR {0}]{1}[/COLOR]".format(self.colors.get("accent2", "FFFFCC4D"), T("Update verfügbar"))
        info += " · " + T("Info-Taste: Hilfe")
        self.setProperty("header_info", info)

    def onInit(self):
        self.setProperty("title", ADDON_NAME)
        self.update_header()
        self.setProperty("hint", T("OK: auswählen   ·   Zurück: Menü / Schließen   ·   Links/Rechts: Wert ändern"))
        menu = self.getControl(MENU)
        menu.reset()
        for key, label, icon_name in MENU_ITEMS:
            if key == "addons" and not config.get("addons"):
                continue
            item = xbmcgui.ListItem(T(label))
            item.setProperty("key", key)
            item.setArt({"icon": icon(icon_name)})
            if is_colored(icon(icon_name)):
                item.setProperty("colored", "true")
            menu.addItem(item)
        tabs = self.getControl(SUBTABS)
        tabs.reset()
        for key, label in MAINT_TABS:
            item = xbmcgui.ListItem(T(label))
            item.setProperty("key", key)
            tabs.addItem(item)
        self._select_menu(self.view)
        self.show_view(self.view)
        self.setFocusId(MENU)

    def _select_menu(self, key):
        menu = self.getControl(MENU)
        for index in range(menu.size()):
            if menu.getListItem(index).getProperty("key") == key:
                menu.selectItem(index)

    def show_view(self, view):
        self.view = view
        self.setProperty("view", view)
        getattr(self, "view_" + view)()

    def _tiles(self, items):
        control = self.getControl(TILES)
        control.reset()
        self.setProperty("tilesize", current_layout())     # sk_main: Layout je nach Ansicht
        self.setProperty("layout", "tiles")
        for item in items:
            control.addItem(item)

    def _rows(self, items):
        control = self.getControl(ROWS)
        control.reset()
        self.setProperty("layout", "rows")
        for item in items:
            control.addItem(item)
        for index in range(control.size()):     # erste bedienbare Zeile auswählen
            if control.getListItem(index).getProperty("kind") not in ("header", "info"):
                control.selectItem(index)
                break

    def content_id(self):
        return TILES if self.getProperty("layout") == "tiles" else ROWS

    # ---------- Ansichten ----------
    def _build_text(self, build, key):
        """Mehrsprachiger Build-Text (Punkt 176): englische Variante, wenn Kodi nicht deutsch ist."""
        from resources.lib import texts
        if not texts.GERMAN and build.get(key + "_en"):
            return build[key + "_en"]
        return build.get(key, "")

    def view_builds(self, refresh=False):
        items = []
        cats = []
        active_cat = load_state().get("build_category", "")
        try:
            current = builds.detect_installed()
            cats = builds.categories()
            if active_cat and active_cat not in cats:
                active_cat = ""
            if cats:        # Filter nach Zweck (Punkt 166): zyklischer Kopf-Eintrag
                shown = T(CATEGORY_NAMES.get(active_cat, active_cat)) if active_cat else T("Alle")
                items.append(_item(T("Kategorie"), "<  {0}  >".format(shown), key="cat_filter",
                                   art=icon("filter"), detail=T("Builds nach Zweck filtern")))
            blist = [b for b in builds.builds(refresh) if not active_cat or b.get("category") == active_cat]
            top_dl = max((b.get("downloads", 0) for b in blist), default=0)   # „beliebt“ (Punkt 165)
            for build in blist:
                installed = current and current.get("id") == build["id"]
                newer = installed and builds.update_available()
                badge = T("Update verfügbar") if newer else (T("installiert") if installed else "")
                if build.get("locked") and not badge:
                    badge = T("mit Passwort")
                label2 = "v{0} · Kodi {1} · {2}".format(build.get("version", "?"), build.get("kodi", "?"),
                                                        human_size(build.get("size", 0)))
                detail = self._build_text(build, "description")       # mehrsprachig (Punkt 176)
                if build.get("category"):       # Zweck/Kategorie anzeigen (Punkt 166)
                    detail = "[{0}]  {1}".format(T(CATEGORY_NAMES.get(build["category"], build["category"])),
                                                 detail).strip()
                if build.get("needs_accounts"):   # benötigte Zugänge anzeigen (Punkt 188)
                    from resources.lib import accounts as _acc
                    names = ", ".join(_acc.service_name(a) for a in build["needs_accounts"])
                    detail += "  ·  " + T("Zugänge: {0}").format(names)
                if build.get("built"):
                    detail += "  ·  " + T("Erstellt: {0}").format(build["built"])
                if build.get("addons"):
                    detail += "  ·  " + T("{0} Addons").format(build["addons"])
                if build.get("locked"):
                    detail += "  ·  " + T("Mit Passwort geschützt")
                if build.get("themes"):
                    detail += "  ·  " + T("{0} Theme(s)").format(len(build["themes"]))
                if build.get("gallery"):
                    detail += "  ·  " + T("{0} Bilder").format(len(build["gallery"]))
                if build.get("downloads"):        # Downloadzahl (Punkt 165)
                    detail += "  ·  " + T("{0}× geladen").format(build["downloads"])
                if not installed and backup.parked(build["id"]):
                    detail += "  ·  " + T("geparkt")
                unsuitable = builds.platform_mismatch(build)
                if unsuitable:
                    detail = T("[B]Passt nicht zu diesem Gerät[/B] - nur für {0}").format(
                        builds.platform_text(unsuitable)) + "  ·  " + detail
                elif builds.kodi_mismatch(build):
                    detail = T("Für Kodi {0} gemacht, hier läuft Kodi {1}").format(build.get("kodi"), kodi_major()) + \
                        "  ·  " + detail
                chip = T("Update") if newer else T("Passt nicht") if unsuitable else \
                    T("Empfohlen") if build.get("badge") == "empfohlen" else \
                    T("Beliebt") if top_dl and build.get("downloads", 0) == top_dl else \
                    T("Neu") if not installed and _is_new(build) else ""
                items.append(_item(build.get("name", build["id"]), label2, key=build["id"],
                                   art=build.get("icon") or icon("build"), detail=detail, badge=badge,
                                   fanart=build.get("fanart", ""), chip=chip))
        except Exception as e:  # noqa: BLE001
            log_error("Build-Liste: {0}".format(e))
            items = [_item("Build-Liste nicht erreichbar", T("OK: erneut versuchen"), key="retry",
                           art=icon("warning"), detail=str(e))]
        if not items:
            items = [_item("Keine Builds in der Liste", "", kind="info", art=icon("info"))]
        items.append(_item("Build aus Datei", T("Lokale ZIP: USB-Stick, Netzwerk, Download-Ordner"), key="local_build",
                           art=icon("package"), detail=T("Installiert einen Build aus einer ZIP auf diesem Gerät oder "
                                                         "im Netzwerk - ohne Server. Save Data bleibt erhalten.")))
        for recent in load_state().get("recent", [])[:3]:
            items.append(_item(recent["label"], T("Zuletzt benutzt"), key="recent:" + recent["key"],
                               art=recent.get("icon", ""), detail=recent.get("label2", "")))
        self._tiles(items)

    def view_info(self):
        info = builds.build_info()
        m, b = info["marker"], info["build"]
        sysrows = [_item(T("System"), "", kind="header")]     # Systeminfo-Seite (Punkt 178)
        sysrows += [_item(k, v, kind="info") for k, v in builds.system_info()]
        if not m and not b:
            self._rows([_item("Kein Build installiert - nach der Installation stehen hier Version, Datum und alle "
                              "Addons des Builds.", kind="info"),
                        _item("Als Textdatei speichern", T("Systeminfo z.B. auf USB-Stick oder Netzwerk"),
                              key="info_save")] + sysrows)
            return
        rows = [_item("Build", "{0} {1}".format(m.get("name") or b.get("name", ""), m.get("version") or
                                                 b.get("version", "")), kind="info"),
                _item("Erstellt", m.get("built") or T("unbekannt"), kind="info"),
                _item("Installiert", m.get("installed") or b.get("installed") or T("unbekannt"), kind="info"),
                _item("Für Kodi", "{0}  ·  {1}".format(m.get("kodi") or "?", T("jetzt: Kodi {0}").format(kodi_major())),
                      kind="info"),
                _item("Skin", m.get("skin") or "?", kind="info"),
                _item("Als Textdatei speichern", T("z.B. auf USB-Stick oder Netzwerk"), key="info_save")]
        if info["rows"]:
            rows.append(_item(T("Addons im Build ({0})").format(len(info["rows"])), kind="header"))
            for r in info["rows"]:
                state = {"updated": T("aktualisiert auf {0}").format(r["now"]), "missing": T("fehlt"),
                         "disabled": T("ausgeschaltet")}.get(r["state"], "")
                rows.append(_item(r["name"], "{0}  ·  {1}".format(r.get("version", ""), state) if state else
                                  "{0}  ·  {1}".format(r["id"], r.get("version", "")), key="addon:" + r["id"]))
        else:
            rows.append(_item("Der Build enthält keine Inhaltsliste (älterer Build oder nicht mit dem sKulls Forge "
                              "erstellt).", kind="info"))
        if info["extra"]:
            rows.append(_item(T("Zusätzlich installiert ({0})").format(len(info["extra"])), kind="header"))
            for a in info["extra"]:
                rows.append(_item(a["name"], "{0}  ·  {1}".format(a["id"], a["version"]), key="addon:" + a["id"]))
        rows += sysrows
        self._rows(rows)

    def view_gui(self):
        rows = [_item("Spielt nur die Oberfläche des Builds neu ein: Skin-Einstellungen, Hauptmenü, Widgets und "
                      "Ansichten. Addons, Konten und Daten bleiben unverändert.", kind="info")]
        current = builds.installed()
        build = None
        try:
            build = builds.find(current["id"]) if current else None
        except Exception:  # noqa: BLE001
            pass
        local = builds.local_gui()
        if not current:
            rows.append(_item("Kein Build installiert", kind="info"))
        elif not (build and (build.get("gui") or {}).get("zip")) and not local:
            rows.append(_item("Für diesen Build gibt es kein GUI-Paket", kind="info"))
        else:
            gui = (build or {}).get("gui") or {}
            package = "v{0} · {1} · {2}".format(build.get("version"), human_size(gui.get("size", 0)),
                                                 T("SHA-256 geprüft")) if gui.get("zip") else \
                T("aus Datei: {0}").format(os.path.basename(local))
            rows += [_item("Build", "{0} {1}".format(current.get("name"), current.get("version")), kind="info"),
                     _item("GUI-Paket", package, kind="info"),
                     _item("Zuletzt angewendet", load_state().get("gui_fix_date") or T("nie"), kind="info"),
                     _item("GUI-Fix anwenden", "", key="gui_fix")]
        self._rows(rows)

    def view_addons(self):
        items = [_item(a.get("name") or a["id"], a["id"], key=a["id"], art=a.get("icon") or icon("addons"),
                       detail=a.get("description", ""),
                       badge=T("installiert") if xbmc.getCondVisibility("System.HasAddon({0})".format(a["id"])) else "")
                 for a in (config.get("addons") or [])]
        self._tiles(items or [_item("Keine Addons hinterlegt", kind="info")])

    def view_maint(self):
        tabs = self.getControl(SUBTABS)
        for index in range(tabs.size()):
            if tabs.getListItem(index).getProperty("key") == self.subtab:
                tabs.selectItem(index)
        t = self.subtab
        if t == "clean":
            items = [
                _item("Alles aufräumen", T("Cache, Pakete, Absturzberichte, alte Datenbanken und Vorschaubilder"),
                      key="clean_all", art=icon("clean")),
                _item("Cache leeren", human_size(maintenance.cache_size()), key="clean_cache", art=icon("delete")),
                _item("Pakete löschen", human_size(maintenance.packages_size()), key="clean_packages",
                      art=icon("package")),
                _item("Vorschaubilder", human_size(maintenance.thumbs_size()), key="clean_thumbs", art=icon("image"),
                      detail=T("Werden beim Blättern neu geladen. Kodi startet danach neu.")),
                _item("Alte Datenbanken", human_size(maintenance.old_databases_size()), key="clean_db",
                      art=icon("database")),
                _item("Absturzberichte", human_size(maintenance.crash_size()), key="clean_crash", art=icon("warning")),
                _item("Speicher-Assistent", T("Größte Addon-Daten und Caches einzeln leeren"), key="clean_assistant",
                      art=icon("database"))]
        elif t == "addon":
            items = [
                _item("Addons entfernen", T("Auswahl aus installierten Addons"), key="addon_remove", art=icon("remove")),
                _item("Addon-Daten entfernen", T("Einstellungen einzelner Addons"), key="addon_data", art=icon("delete")),
                _item("Aktivieren / Deaktivieren", T("Addons ein- oder ausschalten"), key="addon_toggle",
                      art=icon("toggle")),
                _item("Alle Addons aktualisieren", T("Repositories neu laden und alle Updates installieren"),
                      key="addon_updateall", art=icon("refresh"),
                      detail=T("Lädt die Addon-Listen aller Repositories neu und installiert jedes verfügbare Update. "
                               "Meldet Kodi Updates sonst nur, gilt das nur für diesen Lauf.")),
                _item("Ergebnis der Aktualisierung", self._update_result_short(), key="addon_updateresult",
                      art=icon("history")),
                _item("Updates erzwingen", T("Alle Repositories neu prüfen"), key="addon_update", art=icon("refresh")),
                _item("Repositories prüfen", T("Erreichbarkeit aller Repositories"), key="addon_repos",
                      art=icon("repo")),
                _item("Abhängigkeiten prüfen", T("Fehlende oder ausgeschaltete Module finden und reparieren"),
                      key="addon_deps", art=icon("link"),
                      detail=T("Prüft alle eingeschalteten Addons: fehlt ein benötigtes Modul oder ist es "
                               "ausgeschaltet, wird es eingeschaltet bzw. aus den Repositories installiert.")),
                _item("Update-Verhalten", T(maintenance.UPDATE_MODES[maintenance.update_mode()]), key="addon_mode",
                      art=icon("settings"))]
        elif t == "log":
            text = maintenance.read_log(maintenance.log_file())
            _lines, errors, warnings = maintenance.log_problems(text)
            items = [
                _item("Log anzeigen", "kodi.log", key="log_show", art=icon("document")),
                _item("Fehler suchen", T("{0} Fehler, {1} Warnungen").format(errors, warnings), key="log_errors",
                      art=icon("warning")),
                _item("Log filtern", T("Nach Fehlern, Begriff oder Addon"), key="log_filter", art=icon("search")),
                _item("Log speichern", T("Als Datei auf USB-Stick oder Netzwerk"), key="log_export",
                      art=icon("save")),
                _item("Debug-Logging", T("an") if maintenance.debug_logging() else T("aus"), key="log_debug",
                      art=icon("bug")),
                _item("Altes Log", "kodi.old.log", key="log_old", art=icon("history")),
                _item("Wizard-Log", T("Vorgänge des Wizards"), key="log_wizard", art=icon("wizard"))]
        elif t == "tweak":
            info = tuning.device_info(cleanable=False)
            summary = []
            if info["ram_total"]:
                summary.append(T("RAM {0}").format(tuning.gb(info["ram_total"])))
            if info["disk_total"]:
                summary.append(T("Frei: {0}").format(tuning.gb(info["disk_free"])))
            items = [
                _item("Leistung & Speicher", "  ·  ".join(summary), key="tweak_device", art=icon("speed"),
                      detail=T("Zeigt Arbeitsspeicher und Speicherplatz und schlägt passende Einstellungen vor: "
                               "Puffer, Lesefaktor, Bildgrößen und automatische Wartung.")),
                _item("advancedsettings.xml", T("vorhanden") if maintenance.advanced_text() else T("nicht vorhanden"),
                      key="tweak_advanced", art=icon("document")),
                _item("Unbekannte Quellen", T("erlaubt") if maintenance.unknown_sources() else T("gesperrt"),
                      key="tweak_unknown", art=icon("shield")),
                _item("Netzwerk", T("Zeitlimits und Wiederholungen"), key="tweak_network", art=icon("globe")),
                _item("Bildwiederholrate", T(maintenance.REFRESH_MODES[maintenance.refresh_mode()]),
                      key="tweak_refresh", art=icon("display")),
                _item("Speedtest", T("Geschwindigkeit der Verbindung"), key="tweak_speed", art=icon("speed"))]
        else:
            items = [
                _item("Profil neu laden", T("Oberfläche ohne Neustart neu laden"), key="misc_reload", art=icon("refresh")),
                _item("Kodi beenden", T("Sofort schließen"), key="misc_quit", art=icon("power")),
                _item("Quellen prüfen", T("Tote Einträge in sources.xml"), key="misc_sources", art=icon("link")),
                _item("Addon-Datenbank", T("Reparieren und neu aufbauen"), key="misc_addondb", art=icon("database")),
                _item("Skin zurücksetzen", T("Auf Estuary zurückschalten"), key="misc_skin", art=icon("palette")),
                _item("Fresh Start", T("Kodi auf Werkseinstellung - Save Data, Wizard und Repository bleiben"), key="misc_fresh",
                      art=icon("recycle"), badge=T("Vorsicht"))]
        self._tiles(items)

    def view_backup(self):
        state = load_state()
        rows = [_item("Backup erstellen", kind="header")]
        for kind, label in backup.KINDS.items():
            rows.append(_item(label, T("inkl. Passwörter & Logins") if kind == "full" else "",
                              key="backup_" + kind))
        rows += [_item(T("Favoriten & Quellen übertragen"), kind="header"),     # Punkt 106
                 _item("Exportieren", T("kleine Datei auf USB/Netzwerk - für ein anderes Gerät"), key="fav_export"),
                 _item("Importieren", T("Favoriten & Quellen von einem anderen Gerät einspielen"), key="fav_import")]
        rows += [_item("Speicherort", backup.folder(), kind="choice", key="backup_folder"),
                 _item("Wiederherstellungspunkt", T("vor Installation und Fresh Start: an (die letzten 2 bleiben)")
                       if state.get("restore_point", True) else T("aus"), kind="toggle", key="backup_auto"),
                 _item("Automatisch", kind="header"),
                 _item("Automatisch sichern", "<  {0}  >".format(T(INTERVAL_TEXT.get(state.get("autobackup_interval"),
                                                                                      "Nie"))),
                       kind="choice", key="autobackup_interval"),
                 _item("Art", "<  {0}  >".format(T(backup.KINDS.get(state.get("autobackup_kind"), ""))), kind="choice",
                       key="autobackup_kind"),
                 _item("Aufbewahren", "<  {0}  >".format(T("{0} Backups").format(state.get("autobackup_keep") or 3)),
                       kind="choice", key="autobackup_keep"),
                 _item("Wiederherstellen", kind="header")]
        point = backup.last_restore_point()
        if point:
            rows.append(_item("Letzte Installation rückgängig machen", _point_text(point), key="undo_install"))
        entries = backup.entries()
        for path, label, size in entries:
            rows.append(_item(label, human_size(size), key="restore:" + path))
        if not entries:
            rows.append(_item("Noch keine Backups vorhanden", kind="info"))
        rows.append(_item("Aus Datei ...", "", key="restore_file"))
        self._rows(rows)

    def view_save(self):
        state = load_state()
        rows = [_item("Bleibt bei Build-Installation, GUI-Fix und Fresh Start erhalten.", kind="info")]
        for key, label in SAVE_TEXT:
            on = state.get("savedata", {}).get(key)
            extra = ""
            if key in savedata.ADDON_CATEGORIES:
                extra = "  ·  " + T("{0} Addons").format(len(savedata.addon_ids(key)))
            elif key == "whitelist":
                extra = "  ·  " + T("{0} Addons").format(len(state.get("whitelist", [])))
            rows.append(_item(label, (T("an") if on else T("aus")) + extra, kind="toggle", key="save:" + key))
        rows += [_item("Zugänge & API-Schlüssel", T("einmal eingeben, in alle passenden Addons eintragen"),
                       key="accounts", art=icon("shield")),
                 _item("Whitelist bearbeiten", "", key="save_whitelist"),
                 _item("Jetzt sichern", T("{0} Dateien gespeichert").format(savedata.stored_count()), key="save_now"),
                 _item("Wiederherstellen", "", key="save_restore"),
                 _item("Gespeicherte löschen", "", key="save_clear")]
        self._rows(rows)

    def view_settings(self):
        state = load_state()

        def choice(label, key):
            return _item(label, "<  {0}  >".format(T(INTERVAL_TEXT.get(state.get(key), "Nie"))), kind="choice", key=key)

        def toggle(label, key):
            return _item(label, T("an") if state.get(key) else T("aus"), kind="toggle", key=key)
        rows = [_item("Updates", kind="header"),
                choice("Nach Build- und Wizard-Updates suchen", "update_interval"),
                _item("Verfügbare Updates", self._updates_text(state), kind="info"),
                _item("Jetzt nach Updates suchen", "", key="check_updates"),
                _item("Wartung", kind="header"),
                choice("Wartung automatisch", "maint_interval"),
                toggle("Dabei Cache leeren", "maint_cache"),
                toggle("Dabei alte Pakete löschen", "maint_packages"),
                toggle("Dabei Vorschaubilder löschen", "maint_thumbs"),
                _item("Allgemein", kind="header"),
                toggle("Benachrichtigungen anzeigen", "notifications"),
                *self._rss_rows(),
                toggle("Startbild beim Öffnen", "splash"),
                _item("Ansicht", "<  {0}  >".format(T(LAYOUT_TEXT[current_layout()])), kind="choice", key="layout"),
                _item("PIN für gefährliche Aktionen", T("an") if state.get("pin_hash") else T("aus"), key="pin_set"),
                _item("Einrichtungsassistent starten", "", key="setup_assistant"),
                _item("Sprache", T("wie Kodi"), kind="info"),
                _item("Version", "{0} {1}".format(ADDON_NAME, ADDON_VERSION), kind="info"),
                _item("Wizard", kind="header"),
                _item("Selbstprüfung", self._selfcheck_text(state), key="selfcheck_run"),
                _item("Wizard reparieren", T("Wizard-Dateien neu vom Server laden"), key="selfcheck_repair")]
        self._rows(rows)

    @staticmethod
    def _rss_rows():
        from resources.lib import rss
        if not rss.feed():
            return []
        return [_item("Build-News als Laufschrift (RSS)", T("an") if rss.active() else T("aus"), kind="toggle",
                      key="rss")]

    @staticmethod
    def _selfcheck_text(state):
        check = state.get("selfcheck") or {}
        if not check:
            return T("Jetzt prüfen")
        if not check.get("available"):
            return T("nicht verfügbar")
        bad = check.get("bad") or []
        when = time.strftime("%d.%m.%Y %H:%M", time.localtime(check.get("time", 0)))
        if bad:
            return "[COLOR FFFF6B6B]" + T("{0} Datei(en) beschädigt").format(len(bad)) + "[/COLOR]  ·  " + when
        return T("in Ordnung") + "  ·  " + when

    @staticmethod
    def _updates_text(state):
        from resources.lib import service
        if state.get("updates"):
            return service.update_text(state["updates"])
        checked = state.get("last_update_check")
        return T("keine") + ("  ·  " + T("geprüft {0}").format(time.strftime("%d.%m.%Y %H:%M",
                                                                          time.localtime(checked))) if checked else "")

    def view_contact(self):
        contact = config.get("contact") or {}
        rows = [_item(contact.get("text") or "Vielen Dank, dass du dich für unseren Build entschieden hast.",
                      kind="info")]
        for label, value in contact.get("lines", []):
            rows.append(_item(label, value, kind="info"))
        rows += [_item("Wizard", "{0} · {1}".format(ADDON_VERSION, T("erstellt mit sKulls Forge")), kind="info"),
                 _item("Was ist neu", "", key="whats_new"),
                 _item(T("Kurze Tour"), T("Die wichtigsten Bereiche erklärt"), key="tour", art=icon("info"))]
        qr = os.path.join(ADDON_PATH, "resources", "skins", "Default", "media", "contact_qr.png")
        self.setProperty("qr", qr if os.path.isfile(qr) else "")
        self._rows(rows)

    # ---------- Bedienung ----------
    def onAction(self, action):
        action_id = action.getId()
        focus = self.getFocusId()
        if action_id in HELP_ACTIONS and self.show_help():
            return
        if action_id in BACK:
            if focus == MENU:
                self.close()
            else:
                self.setFocusId(MENU)
            return
        if focus == MENU:
            if action_id in (UP, DOWN):
                key = self.getControl(MENU).getSelectedItem().getProperty("key")
                if key != self.view:
                    self.show_view(key)
            elif action_id == RIGHT:
                self._focus_content()
        elif focus == SUBTABS:
            if action_id in (LEFT, RIGHT):
                key = self.getControl(SUBTABS).getSelectedItem().getProperty("key")
                if key != self.subtab:
                    self.subtab = key
                    self.view_maint()
            elif action_id == DOWN:
                self.setFocusId(TILES)
        elif focus == ROWS and action_id in (LEFT, RIGHT):
            item = self.getControl(ROWS).getSelectedItem()
            if item and item.getProperty("kind") == "choice":
                self.change_choice(item.getProperty("key"), 1 if action_id == RIGHT else -1)
            elif action_id == LEFT:
                self.setFocusId(MENU)

    def show_help(self):
        """Info-Taste: ausführliche Erklärung zur gewählten Kachel oder Zeile"""
        from resources.lib import help as wizard_help
        focus = self.getFocusId()
        if focus not in (TILES, ROWS, MENU):
            return False
        item = self.getControl(focus).getSelectedItem()
        if item is None:
            return False
        key = item.getProperty("key")
        if focus == MENU:
            key = "menu_" + key
        text = wizard_help.text_for(key, item.getLabel(), item.getLabel2(), item.getProperty("detail"))
        dialogs.text(item.getLabel() or T("Hilfe"), text)
        return True

    # ---------- Logging ----------
    def _log_source(self, heading):
        m = maintenance
        sources = [("kodi.log", T("Aktuelle Sitzung"), m.log_file()),
                   ("kodi.old.log", T("Vorige Sitzung (nach einem Absturz)"), m.log_file(old=True)),
                   (T("Wizard-Log"), T("Vorgänge des Wizards"), m.WIZARD_LOG)]
        sources = [s for s in sources if os.path.isfile(s[2])]
        if not sources:
            dialogs.ok(heading, "Kein Log vorhanden.")
            return None
        if len(sources) == 1:
            return sources[0]
        index = dialogs.select(heading, [(name, hint) for name, hint, _p in sources], search=False)
        return sources[index] if index is not None else None

    def log_filter(self):
        m = maintenance
        source = self._log_source("Log filtern")
        if not source:
            return
        name, _hint, path = source
        text = m.read_log(path, limit=2 * 1024 * 1024)
        index = dialogs.select("Log filtern", [(T(label), "") for _k, label in m.LOG_FILTERS], search=False)
        if index is None:
            return
        mode = m.LOG_FILTERS[index][0]
        term = ""
        if mode == "term":
            term = dialogs.keyboard("Suchbegriff (z.B. Addon-Name, Fehlertext)")
            if not term:
                return
        elif mode == "addon":
            found = m.log_addons(text)
            if not found:
                dialogs.ok("Log filtern", "Im Log kommt kein Addon vor.")
                return
            choice = dialogs.select("Nach Addon ...", [(a, T("{0} Zeilen").format(n)) for a, n in found])
            if choice is None:
                return
            term = found[choice][0]
        lines = m.filter_log(text, mode, term)
        label = T(m.LOG_FILTERS[index][1]).rstrip(". ") + (": " + term if term else "")
        if not lines:
            dialogs.ok("Log filtern", T("Keine passenden Zeilen in {0}.").format(name))
            return
        dialogs.text("{0} · {1} · {2}".format(name, label, T("{0} Zeilen").format(len(lines))),
                     "[CR]".join(l.replace("[", "(").replace("]", ")") for l in lines[-1500:]))
        if dialogs.confirm("Log filtern", "Diese Zeilen als Datei speichern (USB-Stick, Netzwerk ...)?",
                           yes="Speichern", no="Schließen"):
            self._save_log_text("\n".join(lines), name.replace(".log", "") + "-gefiltert")

    def log_export(self):
        source = self._log_source("Log speichern")
        if not source:
            return
        name, _hint, path = source
        text = maintenance.read_log(path, limit=20 * 1024 * 1024)
        self._save_log_text(text, name.replace(".log", "").replace(" ", "-").lower())

    def _save_log_text(self, text, base):
        scrub = dialogs.confirm("Log speichern", "Passwörter, Tokens und MAC-Adressen unkenntlich machen? "
                                                 "Empfohlen, wenn du das Log weitergibst.", yes="Ja", no="Nein")
        folder = xbmcgui.Dialog().browse(3, T("Wohin speichern? (USB-Stick, Netzwerk ...)"), "files")
        if not folder:
            return
        if scrub:
            text = maintenance.scrub_log(text)
        name = "{0}-{1}.log".format(base, time.strftime("%Y%m%d-%H%M"))
        try:
            target = maintenance.export_log(text, folder, name)
        except Exception as e:  # noqa: BLE001
            log_error("Log speichern: {0}".format(e))
            dialogs.ok("Log speichern", T("Speichern fehlgeschlagen: {0}").format(e))
            return
        log("Log gespeichert: {0}".format(target))
        dialogs.ok("Log speichern", T("Gespeichert: {0}").format(target))

    def _remember_recent(self, key, item):
        state = load_state()
        recent = [r for r in state.get("recent", []) if r.get("key") != key]
        recent.insert(0, {"key": key, "label": item.getLabel(), "label2": item.getProperty("detail"),
                          "icon": item.getArt("thumb")})
        state["recent"] = recent[:3]
        save_state(state)

    def pin_ok(self, heading="PIN eingeben"):
        """Gefährliche Aktion: PIN abfragen, wenn eine gesetzt ist"""
        import hashlib
        state = load_state()
        if not state.get("pin_hash"):
            return True
        value = dialogs.pin(heading)
        if value is None:
            return False
        if hashlib.sha256((state.get("pin_salt", "") + value).encode("utf-8")).hexdigest() == state["pin_hash"]:
            return True
        dialogs.ok("PIN", "Falsche PIN.")
        return False

    def set_pin(self):
        import hashlib
        state = load_state()
        if state.get("pin_hash"):
            index = dialogs.select("PIN für gefährliche Aktionen", [(T("PIN ändern"), ""), (T("PIN entfernen"), "")],
                                   search=False)
            if index is None or not self.pin_ok("Bisherige PIN eingeben"):
                return
            if index == 1:
                state = load_state()
                state["pin_hash"], state["pin_salt"] = "", ""
                save_state(state)
                dialogs.notify("PIN entfernt")
                return
        first = dialogs.pin("Neue PIN (4 bis 8 Ziffern)")
        if first is None:
            return
        if not (4 <= len(first) <= 8 and first.isdigit()):
            dialogs.ok("PIN", "Die PIN muss aus 4 bis 8 Ziffern bestehen.")
            return
        if dialogs.pin("PIN wiederholen") != first:
            dialogs.ok("PIN", "Die PINs stimmen nicht überein.")
            return
        salt = os.urandom(8).hex()
        state = load_state()
        state["pin_salt"], state["pin_hash"] = salt, hashlib.sha256((salt + first).encode("utf-8")).hexdigest()
        save_state(state)
        dialogs.ok("PIN", "Fresh Start, Build-Installation, Wiederherstellen, Addons und Daten entfernen fragen jetzt "
                          "nach der PIN.")

    @staticmethod
    def _update_result_short():
        result = maintenance.update_result()
        if not result:
            return T("Noch nicht ausgeführt")
        return T("{0} aktualisiert, {1} fehlgeschlagen").format(len(result[0]), len(result[2]))

    def _focus_content(self):
        if self.view == "maint":
            self.setFocusId(SUBTABS)
        else:
            self.setFocusId(self.content_id())

    def onClick(self, control_id):
        if control_id == MENU:
            self._focus_content()
            return
        if control_id == SUBTABS:
            self.setFocusId(TILES)
            return
        item = self.getControl(control_id).getSelectedItem()
        if item is None:
            return
        kind, key = item.getProperty("kind"), item.getProperty("key")
        if kind in ("info", "header") or not key:
            return
        position = self.getControl(control_id).getSelectedPosition()
        if kind == "action" and key.startswith(QUICK_PREFIXES) and key not in QUICK_EXCLUDE:
            self._remember_recent(key, item)
        try:
            if kind == "toggle":
                self.toggle(key)
            elif kind == "choice":
                self.change_choice(key, 1)
            else:
                self.run_action(key)
        except Exception as e:  # noqa: BLE001
            log_error("Aktion {0}: {1}".format(key, e))
            dialogs.ok("Fehler", str(e))
        self.show_view(self.view)
        try:
            self.getControl(control_id).selectItem(position)
        except RuntimeError:
            pass
        if getattr(self, "_focus_after", None):
            self.setFocusId(self._focus_after)
            self._focus_after = None

    # ---------- Einstellungen / Schalter ----------
    def toggle(self, key):
        if key == "rss":
            from resources.lib import rss
            rss.remove() if rss.active() else rss.apply(force=True)
            return
        state = load_state()
        if key.startswith("save:"):
            name = key[5:]
            state["savedata"][name] = not state["savedata"].get(name)
        elif key == "backup_auto":
            state["restore_point"] = not state.get("restore_point", True)
        else:
            state[key] = not state.get(key)
        save_state(state)

    def change_choice(self, key, step):
        state = load_state()
        if key == "backup_folder":
            folder = xbmcgui.Dialog().browse(3, T("Speicherort für Backups"), "files")
            if folder:
                state["backup_folder"] = folder
                save_state(state)
            self.view_backup()
            return
        if key == "layout":
            index = (LAYOUT_KEYS.index(current_layout()) + step) % len(LAYOUT_KEYS)
            state["layout"] = LAYOUT_KEYS[index]
            save_state(state)
            position = self.getControl(ROWS).getSelectedPosition()
            self.show_view(self.view)
            self.getControl(ROWS).selectItem(position)
            return
        if key == "autobackup_kind":
            keys = backup.AUTO_KINDS
        elif key == "autobackup_keep":
            keys = list(range(1, 11))
        else:
            keys = [k for k, _s in INTERVALS]
        current = state.get(key, keys[0])
        index = (keys.index(current) + step) % len(keys) if current in keys else 0
        state[key] = keys[index]
        if key == "autobackup_interval" and keys[index] != "never" and not state.get("last_autobackup"):
            state["last_autobackup"] = time.time()      # nicht sofort, sondern ab jetzt im Intervall
        save_state(state)
        position = self.getControl(ROWS).getSelectedPosition()
        self.show_view(self.view)
        self.getControl(ROWS).selectItem(position)

    # ---------- Aktionen ----------
    def run_action(self, key):
        if key == "retry":
            self.view_builds(refresh=True)
        elif key == "local_build":
            self.install_local_build()
        elif key == "fav_export":        # Favoriten & Quellen übertragen (Punkt 106)
            self.export_favourites()
        elif key == "fav_import":
            self.import_favourites()
        elif key.startswith("recent:"):
            self.maintenance(key[7:])
        elif key == "pin_set":
            self.set_pin()
        elif key == "selfcheck_run":
            self.selfcheck()
        elif key == "selfcheck_repair":
            self.repair_wizard()
        elif key == "setup_assistant":
            from resources.lib import service
            service.setup_assistant()
        elif key == "info_save":
            self.save_build_info()
        elif key == "cat_filter":        # Kategorie-Filter weiterschalten (Punkt 166)
            options = [""] + builds.categories()
            state = load_state()
            current = state.get("build_category", "")
            current = current if current in options else ""
            state["build_category"] = options[(options.index(current) + 1) % len(options)]
            save_state(state)
            self.view_builds()
        elif key.startswith("addon:"):
            return
        elif self.view == "builds":
            self.build_menu(builds.find(key))
        elif self.view == "addons":
            self.install_addon(key)
        elif key == "gui_fix":
            self.gui_fix()
        elif key.startswith(("clean_", "addon_", "log_", "tweak_", "misc_")):
            self.maintenance(key)
        elif key.startswith("backup_"):
            self.create_backup(key[7:])
        elif key == "undo_install":
            self.undo_install()
        elif key == "accounts":
            self.accounts()
        elif key.startswith("restore"):
            self.restore(key)
        elif key.startswith("save_"):
            self.save_action(key)
        elif key == "check_updates":
            from resources.lib import service
            result = service.check_updates(interactive=True)
            self.update_header()
            if result == "builds":
                self._select_menu("builds")
                self.view = "builds"
                self._focus_after = TILES
            elif not result:
                dialogs.ok("Updates", "Alles ist aktuell.")
        elif key == "whats_new":
            build = builds.find((builds.installed() or {}).get("id", "")) if builds.installed() else None
            dialogs.text("Was ist neu", self._build_text(build or {}, "changelog") or T("Keine Angaben"))
        elif key == "tour":                  # geführte Tour erneut starten (Punkt 174)
            from resources.lib import service
            service.tour(force=True)

    def install_previous(self, build):
        """Eine ältere, noch online liegende Version des Builds installieren (Punkt 191)."""
        versions = [p for p in (build.get("previous") or []) if p.get("zip") and p.get("sha256")]
        if not versions:
            return
        index = dialogs.select(T("Ältere Version installieren"),
                               [("v{0}".format(p.get("version", "?")), human_size(p.get("size", 0))) for p in versions])
        if index is None:
            return
        if not self.pin_ok():
            return
        item = versions[index]
        old = dict(build, version=item.get("version", ""), zip=item["zip"], sha256=item["sha256"],
                   size=item.get("size", 0), locked=bool(item.get("locked")), lock=item.get("lock"))
        for gone in ("previous", "changelog", "changelog_en", "gui", "themes"):   # gehören zur aktuellen Version
            old.pop(gone, None)
        key = self.build_key(old) if old.get("locked") else None
        if old.get("locked") and not key:
            return
        self.install_build(old, key, pin_checked=True)

    def _offer_accounts(self, build):
        """Nach der Installation anbieten, die vom Build benötigten Zugänge einzutragen (Punkt 188)."""
        need = [a for a in (build.get("needs_accounts") or []) if a]
        if not need:
            return
        from resources.lib import accounts as acc
        names = ", ".join(acc.service_name(a) for a in need)
        if dialogs.confirm(T("Zugänge einrichten"),
                           T("Dieser Build nutzt: {0}. Jetzt Zugänge/Schlüssel eintragen?").format(names)):
            self.accounts()

    # Builds
    def build_menu(self, build):
        if not build:
            return
        current = builds.installed()
        options = [("Neu installieren" if current and current.get("id") == build["id"] else "Installieren", "install")]
        if build.get("changelog"):
            options.append(("Was ist neu", "changelog"))
        if build.get("manifest"):
            options.append(("Inhalt anzeigen", "contents"))
        if build.get("gallery"):
            options.append((T("Bilder ansehen ({0})").format(len(build["gallery"])), "gallery"))
        if build.get("video"):            # Vorschau-Video (Punkt 167)
            options.append((T("Vorschau-Video abspielen"), "video"))
        if build.get("previous"):         # ältere Versionen (Punkt 191)
            options.append((T("Ältere Version installieren"), "previous"))
        parked = backup.parked(build["id"]) if not (current and current.get("id") == build["id"]) else None
        if parked:
            options.insert(0, (T("Geparkten Stand zurückholen (v{0}, {1})").format(parked.get("version", "?"),
                                                                                  parked.get("date", "")), "unpark"))
        if current and current.get("id") == build["id"]:
            if (build.get("gui") or {}).get("zip"):
                options.append(("GUI-Fix", "gui"))
            if backup.last_restore_point():
                options.append(("Letzte Installation rückgängig machen", "undo"))
            if build.get("themes"):
                options.append(("Themes", "themes"))
        choice = dialogs.select("{0} v{1}".format(build.get("name"), build.get("version")),
                                [(T(label), "") for label, _k in options])
        if choice is None:
            return
        action = options[choice][1]
        if action == "install":
            if not self.pin_ok():          # PIN vor dem Build-Passwort
                return
            key = self.build_key(build) if build.get("locked") else None
            if build.get("locked") and not key:
                return
            self.install_build(build, key, pin_checked=True)
            self._offer_accounts(build)
        elif action == "gallery":
            dialogs.gallery("{0} v{1}".format(build.get("name"), build.get("version")), build["gallery"])
        elif action == "unpark":
            self.unpark(build, parked)
        elif action == "undo":
            self.undo_install()
        elif action == "changelog":
            dialogs.text("Was ist neu", self._build_text(build, "changelog") or T("Keine Angaben"))
        elif action == "video":          # Vorschau-Video abspielen (Punkt 167)
            import xbmc
            xbmc.Player().play(build["video"])
        elif action == "previous":       # ältere Version installieren (Punkt 191)
            self.install_previous(build)
        elif action == "contents":
            from resources.lib import net
            try:
                manifest = net.fetch_json(build["manifest"])
            except Exception as e:  # noqa: BLE001
                dialogs.error("Inhalt", str(e))     # mit QR-Hilfe (Punkt 175)
                return
            addons = manifest.get("addons", []) if isinstance(manifest, dict) else []
            lines = [T("Erstellt: {0}").format(manifest.get("built", "-")), T("Skin: {0}").format(manifest.get("skin", "-")),
                     "", T("Addons im Build ({0})").format(len(addons))]
            lines += ["{0}  ·  {1}  ·  {2}".format(a.get("name"), a.get("id"), a.get("version")) for a in addons]
            dialogs.text("{0} v{1}".format(build.get("name"), build.get("version")), "[CR]".join(lines))
        elif action == "gui":
            self.gui_fix()
        elif action == "themes":
            themes = build["themes"]
            index = dialogs.select("Themes", [(t.get("name", "?"), t.get("description", "")) for t in themes])
            if index is not None:
                _r, error = dialogs.run("Theme", lambda ui: builds.apply_theme(build, themes[index], ui))
                if not error:
                    xbmc.executebuiltin("ReloadSkin()")

    def build_key(self, build):
        """Schlüssel für einen geschützten Build: gemerkt oder per Passwort-Eingabe. None = abgebrochen"""
        from resources.lib import lock
        info = build.get("lock") or {}
        state = load_state()
        saved = (state.get("build_keys") or {}).get(build["id"])
        if saved and lock.check(saved, info):
            return saved
        for _attempt in range(3):
            password = dialogs.keyboard(T("Passwort für {0}").format(build.get("name")), hidden=True)
            if not password:
                return None
            xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
            try:
                key = lock.derive(password, info)
            except lock.LockError as e:
                xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
                dialogs.ok("Passwort", T(str(e)))
                return None
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
            if lock.check(key, info):
                if dialogs.confirm("Passwort", "Passwort auf diesem Gerät merken? Dann fragt der Wizard bei Updates "
                                               "dieses Builds nicht erneut.", yes="Merken", no="Nein"):
                    state = load_state()
                    keys = state.get("build_keys") or {}
                    keys[build["id"]] = key        # der abgeleitete Schlüssel, nicht das Passwort
                    state["build_keys"] = keys
                    save_state(state)
                return key
            dialogs.ok("Passwort", "Falsches Passwort.")
        return None

    def selfcheck(self):
        from resources.lib import selfcheck
        bad = selfcheck.run()
        if bad is None:
            dialogs.ok("Selbstprüfung", "Dieser Wizard bringt keine Prüfsummen mit (mit einer älteren Version des "
                                         "sKulls Forge gebaut).")
        elif not bad:
            dialogs.ok("Selbstprüfung", "Alle Dateien des Wizards sind in Ordnung.")
        else:
            lines = [T("{0} Datei(en) beschädigt oder verändert:").format(len(bad)), ""]
            lines += ["{0}  ·  {1}".format(rel, T(what)) for rel, what in bad]
            lines += ["", T("Abhilfe: Einstellungen > Wizard reparieren")]
            dialogs.text("Selbstprüfung", "[CR]".join(lines))
        self.show_view(self.view)

    def repair_wizard(self):
        if repair_wizard_files():
            self.close()

    def dependencies(self):
        report = maintenance.dependency_report()
        missing, disabled = report["missing"], report["disabled"]
        if not missing and not disabled:
            dialogs.ok("Abhängigkeiten", "Alle benötigten Module sind installiert und eingeschaltet.")
            return
        lines = []
        if missing:
            lines += ["[B]" + T("Fehlen ({0})").format(len(missing)) + "[/B]"]
            lines += ["{0}  ·  {1}".format(d, T("für {0}").format(", ".join(n[:3]))) for d, n in sorted(missing.items())]
        if disabled:
            lines += ["", "[B]" + T("Ausgeschaltet ({0})").format(len(disabled)) + "[/B]"]
            lines += ["{0}  ·  {1}".format(d, T("für {0}").format(", ".join(n[:3]))) for d, n in sorted(disabled.items())]
        dialogs.text("Abhängigkeiten", "[CR]".join(lines))
        if dialogs.confirm("Abhängigkeiten", T("Jetzt reparieren? Ausgeschaltete Module werden eingeschaltet, fehlende "
                                               "fragt Kodi einzeln zur Installation an ({0}).").format(len(missing)),
                           yes="Reparieren", no="Abbrechen"):
            switched, started = maintenance.repair_dependencies(report)
            dialogs.ok("Abhängigkeiten", T("{0} eingeschaltet, {1} zur Installation angestoßen. Danach am besten "
                                           "noch einmal prüfen.").format(switched, started))

    def advanced_manual(self):
        """advancedsettings.xml von Hand: häufige Einträge mit Tipp, eigener Eintrag, Entfernen"""
        m = maintenance
        while True:
            rows = []
            for path, label, kind, _tip in m.ADVANCED_ENTRIES:
                value = m.advanced_value(path)
                if value is not None and kind == "mb" and value.isdigit():
                    value = "{0} MB".format(int(value) // 1048576)
                rows.append((T(label), value if value is not None else T("Kodi-Standard")))
            rows.append((T("Eigener Eintrag ..."), T("Pfad selbst eingeben, z.B. network/curlretries")))
            index = dialogs.select("Werte von Hand eingeben", rows)
            if index is None:
                return
            if index == len(m.ADVANCED_ENTRIES):
                path = dialogs.keyboard("Pfad (z.B. network/curlretries)", "")
                if not path:
                    continue
                kind, tip, label = "text", T("Eigener Eintrag - Kodi-Wiki: advancedsettings.xml"), path
            else:
                path, label, kind, tip = m.ADVANCED_ENTRIES[index]
                label, tip = T(label), T(tip)
            current = m.advanced_value(path)
            action = dialogs.select(label, [(T("Wert eingeben"), current or T("Kodi-Standard")),
                                            (T("Tipp anzeigen"), ""), (T("Entfernen (Kodi-Standard)"), "")], search=False)
            if action == 1:
                dialogs.text(label, tip)
                action = 0 if dialogs.confirm(label, "Jetzt einen Wert eingeben?") else None
            if action == 2:
                m.set_advanced_value(path, None)
                dialogs.notify(T("Entfernt - gilt nach dem Neustart"))
            elif action == 0:
                self._advanced_input(path, label, kind, tip, current)

    def _advanced_input(self, path, label, kind, tip, current):
        m = maintenance
        if kind == "bool":
            choice = dialogs.select(label, [(T("an (true)"), ""), (T("aus (false)"), "")], search=False)
            if choice is None:
                return
            value = "true" if choice == 0 else "false"
        else:
            default = current or ""
            if kind == "mb" and default.isdigit():
                default = str(int(default) // 1048576)
            text = dialogs.keyboard(label, default)
            if text is None or not text.strip():
                return
            text = text.strip()
            if kind in ("int", "mb"):
                if not text.isdigit():
                    dialogs.ok(label, "Bitte nur Ziffern eingeben.")
                    return
                value = str(int(text) * 1048576) if kind == "mb" else text
                if kind == "mb" and int(text) * 3 > tuning.ram_mb() > 0:
                    if not dialogs.confirm(label, T("{0} MB Puffer belegen etwa {1} MB RAM - mehr als das Gerät hat "
                                                    "({2} MB). Trotzdem setzen?").format(text, int(text) * 3,
                                                                                       tuning.ram_mb())):
                        return
            else:
                value = text
        try:
            m.set_advanced_value(path, value)
        except ValueError as e:
            dialogs.ok(label, str(e))
            return
        dialogs.notify(T("Gespeichert - gilt nach dem Neustart"))

    def databases(self):
        """Datenbanken mit Markierung: alt (löschbar), aktuell, von Kodi geöffnet - mit Tipps"""
        rows = maintenance.database_report()
        if not rows:
            dialogs.ok("Datenbanken", "Keine Datenbanken gefunden.")
            return
        status_text = {"alt": "[COLOR FFFFCC4D]" + T("unbenutzt - löschbar") + "[/COLOR]",
                       "aktuell": T("in Benutzung"), "offen": T("von Kodi geöffnet"), "unbekannt": T("unbekannt")}
        items, deletable = [], []
        for index, (path, name, size, status, meaning, kodi) in enumerate(rows):
            extra = "{0}  ·  {1}".format(human_size(size), status_text[status])
            if kodi:
                extra += "  ·  Kodi {0}".format(kodi)
            items.append((name + ("  -  " + T(meaning) if meaning else ""), extra))
            if status == "alt":
                deletable.append(index)
        if not deletable:
            dialogs.text("Datenbanken", "[CR]".join("{0}  ·  {1}".format(a, b) for a, b in items) + "[CR][CR]" +
                         T("Keine unbenutzten Datenbanken - nichts zu löschen."))
            return
        dialogs.text("Datenbanken - Tipps", T(
            "Kodi legt bei jedem Versions-Update neue Datenbanken an (z.B. MyVideos131.db für Kodi 21) und lässt die "
            "alten liegen. Gelb markierte Datenbanken gehören zu einer älteren Kodi-Version und werden nicht mehr "
            "benutzt - sie können weg. Datenbanken „in Benutzung“ enthalten deine Bibliothek, „von Kodi geöffnete“ "
            "(Addons, Textures) nie löschen. Im nächsten Schritt sind nur die unbenutzten vorausgewählt."))
        chosen = dialogs.select("Unbenutzte Datenbanken löschen", items, multi=True, preselect=deletable, search=False)
        if not chosen:
            return
        skipped = [rows[i][1] for i in chosen if i not in deletable]
        targets = [rows[i] for i in chosen if i in deletable]
        if skipped:
            dialogs.ok("Datenbanken", T("Werden nicht gelöscht, weil sie benutzt werden: {0}").format(", ".join(skipped)))
        if not targets or not dialogs.confirm("Datenbanken", T("{0} unbenutzte Datenbank(en) löschen ({1})?").format(
                len(targets), human_size(sum(r[2] for r in targets)))):
            return
        freed = 0
        for path, _n, size, _s, _m, _k in targets:
            try:
                os.remove(path)
                freed += size
            except OSError:
                pass
        dialogs.notify(T("{0} frei").format(human_size(freed)))
        self.show_view(self.view)

    def storage_assistant(self):
        """Größte Addon-Daten und Caches anzeigen und einzeln leeren"""
        m = maintenance
        while True:
            report = m.storage_report()
            if not report:
                dialogs.ok("Speicher-Assistent", "Keine Addon-Daten gefunden.")
                return
            index = dialogs.select("Speicher-Assistent", [(T(label), "{0}{1}".format(
                human_size(total), "  ·  " + T("Cache {0}").format(human_size(cache)) if cache and key.startswith(
                    "addon:") else "")) for key, label, total, cache in report])
            if index is None:
                return
            key, label, total, cache = report[index]
            if key == "thumbs":
                if dialogs.confirm("Vorschaubilder", "Alle Vorschaubilder löschen? Kodi startet danach neu."):
                    m.clear_thumbs()
                    kill_kodi()
                continue
            if key == "packages":
                dialogs.notify(T("{0} frei").format(human_size(m.clear_packages())))
                continue
            name = key[6:]
            options = []
            if cache:
                options.append((T("Cache leeren"), human_size(cache)))
            options.append((T("Alle Daten löschen"), T("Einstellungen und Anmeldungen gehen verloren")))
            choice = dialogs.select(name, options, search=False)
            if choice is None:
                continue
            if cache and choice == 0:
                dialogs.notify(T("{0} frei").format(human_size(m.clear_addon_cache(name))))
            elif self.pin_ok() and dialogs.confirm("Alle Daten löschen", T("Alle Daten von {0} löschen?").format(name),
                                                   danger=True):
                dialogs.notify(T("{0} frei").format(human_size(m.clear_addon_data(name))))

    def save_build_info(self):
        import xbmcvfs
        folder = xbmcgui.Dialog().browse(3, T("Ordner für die Build-Info"), "files")
        if not folder:
            return
        info = builds.build_info()
        m, b = info["marker"], info["build"]
        name = "build_info_{0}_{1}.txt".format(m.get("id") or b.get("id") or "kodi", m.get("version") or
                                               b.get("version") or "")
        path = folder.rstrip("/\\") + ("/" if "://" in folder or folder.startswith("/") else os.sep) + name
        handle = xbmcvfs.File(path, "w")
        try:
            text = re.sub(r"\[/?(?:B|I|COLOR|UPPERCASE|LOWERCASE|CAPITALIZE)(?: [^\]]*)?\]", "",
                          builds.build_info_text(info).replace("[CR]", "\n"))   # Textdatei ohne Kodi-Formatierung
            ok = handle.write(text.encode("utf-8"))
        finally:
            handle.close()
        if ok is False:
            dialogs.ok("Build-Info", T("Konnte nicht gespeichert werden: {0}").format(path))
        else:
            dialogs.ok("Build-Info", T("Gespeichert: {0}").format(path))

    def export_favourites(self):
        """Favoriten & Quellen als kleine Datei auf USB/Netzwerk schreiben (Punkt 106)."""
        dest = xbmcgui.Dialog().browse(3, T("Zielordner wählen"), "files")
        if not dest:
            return
        try:
            path = backup.export_transfer(dest)
        except Exception as e:  # noqa: BLE001
            dialogs.ok(T("Favoriten & Quellen übertragen"), str(e))
            return
        if path:
            dialogs.ok(T("Favoriten & Quellen übertragen"), T("Gespeichert: {0}").format(path))
        else:
            dialogs.ok(T("Favoriten & Quellen übertragen"), T("Keine Favoriten oder Quellen gefunden."))

    def import_favourites(self):
        """Favoriten & Quellen von einem anderen Gerät einspielen (Punkt 106)."""
        src = xbmcgui.Dialog().browse(1, T("Datei wählen"), "files", ".zip")
        if not src or not src.lower().endswith(".zip"):
            return
        try:
            count = backup.import_transfer(src)
        except Exception as e:  # noqa: BLE001
            dialogs.ok(T("Favoriten & Quellen übertragen"), str(e))
            return
        dialogs.ok(T("Favoriten & Quellen übertragen"), T("{0} Datei(en) übernommen. Kodi neu starten, damit alles "
                                                          "greift.").format(count))

    def _offer_park(self, target):
        """Vor einem Wechsel: den installierten Build parken? True/False, None = abgebrochen"""
        current = builds.installed()
        if not current or current.get("id") == target.get("id"):
            return False
        index = dialogs.select(T("„{0}“ vor dem Wechsel parken?").format(current.get("name", current.get("id"))),
                               [(T("Parken und wechseln"), T("Komplett-Backup - zum Zurückwechseln")),
                                (T("Ohne Parken wechseln"), "")], search=False)
        return None if index is None else index == 0

    def _park_current(self):
        current = builds.installed()
        _r, error = dialogs.run(T("Parke {0}").format(current.get("name", current.get("id"))),
                                lambda ui: backup.park(current, ui) and None)
        return not error

    def unpark(self, build, parked):
        if not self.pin_ok():
            return
        if not dialogs.confirm("Build-Wechsel", T("Den geparkten Stand von {0} (v{1}, {2}) zurückholen? Die bisherige "
                                                  "Einrichtung wird ersetzt. Kodi startet danach neu.").format(
                parked.get("name"), parked.get("version"), parked.get("date")), yes="Zurückholen", no="Abbrechen"):
            return
        park = self._offer_park(build)
        if park is None or (park and not self._park_current()):
            return

        def work(ui):
            backup.restore(parked["path"], ui, fresh=True)
            builds.remember({"id": build["id"], "name": parked.get("name", build.get("name")),
                             "version": parked.get("version", "")})
            return builds.after_install_text()
        _r, error = dialogs.run("Build-Wechsel", work)
        if error:
            builds.cleanup_leftovers()
            return
        kill_kodi()

    def install_build(self, build, key=None, pin_checked=False):
        if not pin_checked and not self.pin_ok():
            return
        text = T("{0} v{1} installieren? Die bisherige Einrichtung wird ersetzt - Save Data bleibt erhalten.").format(
            build.get("name"), build.get("version"))
        unsuitable = builds.platform_mismatch(build)
        if unsuitable:
            text += "[CR][CR][B]" + T("Achtung: Der Build ist nur für {0} gemacht - auf diesem Gerät können Teile "
                                      "fehlen oder nicht starten.").format(builds.platform_text(unsuitable)) + "[/B]"
        if builds.kodi_mismatch(build):
            text += "[CR][CR]" + T("Achtung: Der Build ist für Kodi {0} gemacht, installiert ist Kodi {1}.").format(
                build.get("kodi"), kodi_major())
        text += "[CR][CR]" + download_estimate(build.get("size", 0))
        if not dialogs.confirm("Build installieren", text, yes="Installieren", no="Abbrechen",
                               danger=bool(unsuitable)):
            return
        park = self._offer_park(build)
        if park is None or (park and not self._park_current()):
            return
        _result, error = dialogs.run(T("Installiere {0} v{1}").format(build.get("name"), build.get("version")),
                                     lambda ui: builds.install(build, ui, key=key) and builds.after_install_text(),
                                     done="Fertig")
        if error:
            builds.cleanup_leftovers()
            return
        kill_kodi()

    def install_local_build(self):
        if not self.pin_ok():
            return
        path = xbmcgui.Dialog().browse(1, T("Build-Datei wählen (ZIP oder geschützt .skz)"), "files", ".zip|.skz")
        if not path:
            return
        try:
            protected = builds.local_lock(path)        # automatisch erkennen: mit oder ohne Passwort
        except builds.BuildError as e:
            dialogs.ok("Build aus Datei", T(str(e)))
            return
        if protected:
            key = self.build_key(protected)
            if not key:
                return
            if not dialogs.confirm("Build aus Datei", T("{0} ist mit einem Passwort geschützt - Passwort stimmt. Jetzt "
                                                        "installieren? Die bisherige Einrichtung wird ersetzt - Save "
                                                        "Data, der Wizard und sein Repository bleiben erhalten.").format(
                    protected.get("name")), yes="Installieren", no="Abbrechen"):
                return

            def work(ui):
                plain = builds.decrypt_local(path, protected, key, ui)
                try:
                    builds.install_local(plain, ui, name=protected.get("name"))
                finally:
                    builds.cleanup_leftovers()
                return builds.after_install_text()
            _r, error = dialogs.run(T("Installiere {0}").format(protected.get("name")), work, done="Fertig")
            if error:
                builds.cleanup_leftovers()
                return
            kill_kodi()
            return
        if not builds.is_build_zip(path):
            dialogs.ok("Build aus Datei", "Die ZIP enthält keinen Kodi-Build (addons/ oder userdata/ fehlen).")
            return
        if not dialogs.confirm("Build aus Datei", T("{0} installieren? Die bisherige Einrichtung wird ersetzt - Save "
                                                    "Data, der Wizard und sein Repository bleiben erhalten.").format(
                os.path.basename(path)), yes="Installieren", no="Abbrechen"):
            return
        _r, error = dialogs.run(T("Installiere {0}").format(os.path.basename(path)),
                                lambda ui: builds.install_local(path, ui) and builds.after_install_text(), done="Fertig")
        if error:
            builds.cleanup_leftovers()
            return
        kill_kodi()

    def gui_fix(self):
        current = builds.installed()
        build = builds.find(current["id"]) if current else None
        if not build and not builds.local_gui():
            return
        build = build or {"name": (current or {}).get("name", "Build")}
        if not dialogs.confirm("GUI-Fix", "Oberfläche des Builds neu einspielen? Addons und Daten bleiben."):
            return
        _r, error = dialogs.run("GUI-Fix", lambda ui: builds.gui_fix(build, ui) or "Kodi wird jetzt beendet.")
        if not error:
            state = load_state()
            state["gui_fix_date"] = time.strftime("%d.%m.%Y")
            save_state(state)
            kill_kodi()

    def install_addon(self, addon_id):
        if xbmc.getCondVisibility("System.HasAddon({0})".format(addon_id)):
            dialogs.ok("Addons", "Dieses Addon ist bereits installiert.")
            return
        xbmc.executebuiltin("InstallAddon({0})".format(addon_id), True)

    # Wartung
    def maintenance(self, key):
        m = maintenance
        freed = None
        if key == "clean_all":
            parts = m.cleanup_parts()
            chosen = dialogs.select("Alles aufräumen - was soll weg?",
                                    [(T(label), human_size(size) + ("  ·  " + T("Neustart") if restart else ""))
                                     for _k, label, size, restart in parts], multi=True,
                                    preselect=list(range(len(parts))), search=False)
            if not chosen:
                return
            keys = [parts[i][0] for i in chosen]
            restart = any(parts[i][3] for i in chosen)
            if not dialogs.confirm("Alles aufräumen", T("{0} löschen?").format(", ".join(T(parts[i][1]) for i in chosen))
                                   + (" " + T("Kodi startet danach neu.") if restart else "")):
                return
            freed = m.cleanup(keys)
            if restart:
                dialogs.ok("Alles aufräumen", T("{0} frei. Kodi wird jetzt beendet.").format(human_size(freed)))
                kill_kodi()
            else:
                dialogs.notify(T("{0} frei").format(human_size(freed)))
                self.show_view(self.view)
            return
        if key == "clean_db":
            self.databases()
            return
        simple = {"clean_cache": m.clear_cache, "clean_packages": m.clear_packages, "clean_db": m.clear_old_databases,
                  "clean_crash": m.clear_crash_logs}
        if key in simple:
            freed = simple[key]()
        elif key == "clean_thumbs":
            if dialogs.confirm("Vorschaubilder", "Alle Vorschaubilder löschen? Kodi startet danach neu."):
                m.clear_thumbs()
                kill_kodi()
            return
        elif key in ("addon_remove", "addon_data", "addon_toggle"):
            if key != "addon_toggle" and not self.pin_ok():
                return
            protected = builds.protected_addons()
            addons = [a for a in m.user_addons() if a["id"] not in protected]
            table = m.origins()
            labels = []
            for a in addons:
                origin = m.origin_text(a["id"], table)
                labels.append((a["name"], "{0} · {1}{2} · {3}".format(
                    a["version"], (origin[11:] if origin.startswith("repository.") else origin) if origin else
                    "[COLOR FFFFCC4D]" + T("ohne Repository") + "[/COLOR]",
                    "" if a["enabled"] else " · " + T("aus"), a["id"])))
            chosen = dialogs.select({"addon_remove": "Addons entfernen", "addon_data": "Addon-Daten entfernen",
                                     "addon_toggle": "Aktivieren / Deaktivieren"}[key], labels, multi=True)
            if not chosen:
                return
            ids = [addons[i]["id"] for i in chosen]
            if key == "addon_remove" and dialogs.confirm("Addons entfernen",
                                                         T("{0} Addons samt Daten entfernen?").format(len(ids))):
                m.remove_addons(ids)
            elif key == "addon_data" and dialogs.confirm("Addon-Daten entfernen",
                                                           T("Einstellungen von {0} Addons löschen?").format(len(ids))):
                m.remove_addon_data(ids)
            elif key == "addon_toggle":
                for i in chosen:
                    m.set_enabled([addons[i]["id"]], not addons[i]["enabled"])
            return
        elif key == "addon_update":
            m.force_updates()
            dialogs.notify("Repositories werden geprüft")
        elif key == "addon_updateall":
            mode = m.update_mode()
            if mode != 0 and not dialogs.confirm("Alle Addons aktualisieren", T(
                    "Kodi ist so eingestellt: „{0}“. Jetzt trotzdem einmal alle verfügbaren Updates installieren? "
                    "Danach gilt wieder deine Einstellung.").format(T(m.UPDATE_MODES[mode])),
                    yes="Aktualisieren", no="Abbrechen"):
                return
            m.update_all_once()
            dialogs.ok("Alle Addons aktualisieren", "Kodi lädt jetzt die Addon-Listen aller Repositories neu und "
                                                    "installiert die Updates im Hintergrund. Das kann einige Minuten "
                                                    "dauern - Kodi meldet jedes installierte Update.")
        elif key == "addon_updateresult":
            result = m.update_result()
            if not result:
                dialogs.ok("Ergebnis der Aktualisierung", "„Alle Addons aktualisieren“ wurde noch nicht ausgeführt.")
                return
            updated, added, failed, when = result
            lines = [T("Seit {0}").format(time.strftime("%d.%m.%Y %H:%M", time.localtime(when))), ""]
            lines += ["[B]" + T("Aktualisiert ({0})").format(len(updated)) + "[/B]"]
            lines += ["{0}  {1} > {2}".format(n, a, b) for n, a, b in updated] or [T("keine")]
            if added:
                lines += ["", "[B]" + T("Neu installiert ({0})").format(len(added)) + "[/B]"]
                lines += ["{0}  {1}".format(n, v) for n, v in added]
            lines += ["", "[B]" + T("Fehlgeschlagen ({0})").format(len(failed)) + "[/B]"]
            lines += failed or [T("keine")]
            dialogs.text("Ergebnis der Aktualisierung", "[CR]".join(lines))
        elif key == "clean_assistant":
            self.storage_assistant()
        elif key == "addon_deps":
            self.dependencies()
        elif key == "addon_repos":
            result, _e = dialogs.run("Repositories prüfen", lambda ui: m.check_repositories(
                lambda p, name: ui.update(p, name)))
            if result is not None:
                lines = []
                for name, ok, total, repo_id in result:
                    if ok == total:
                        status = "[COLOR FF5FD38D]OK[/COLOR]"
                    elif ok:
                        status = "[COLOR FFFFCC4D]" + T("teilweise") + "[/COLOR]"
                    else:
                        status = "[COLOR FFFF6B6B]" + T("nicht erreichbar") + "[/COLOR]"
                    lines.append("{0}  [B]{1}[/B]  {2}  ·  {3}".format(
                        status, name, repo_id, T("{0} von {1} Adressen erreichbar").format(ok, total)))
                bad = sum(1 for _n, ok, total, _i in result if ok < total)
                head = T("{0} Repositories geprüft, {1} mit Problemen").format(len(result), bad)
                dialogs.text("Repositories", head + "[CR][CR]" + "[CR]".join(lines) if result
                             else T("Keine Repositories installiert"))
        elif key == "addon_mode":
            index = dialogs.select("Update-Verhalten", [(T(x), "") for x in m.UPDATE_MODES])
            if index is not None:
                m.set_update_mode(index)
        elif key == "log_show":
            dialogs.text("kodi.log", m.read_log(m.log_file()))
        elif key == "log_old":
            dialogs.text("kodi.old.log", m.read_log(m.log_file(old=True)) or T("Nicht vorhanden"))
        elif key == "log_wizard":
            dialogs.text("Wizard-Log", m.wizard_log() or T("Noch leer"))
        elif key == "log_errors":
            lines, _e, _w = m.log_problems(m.read_log(m.log_file()))
            dialogs.text("Fehler und Warnungen", "[CR]".join(lines[-400:]) or T("Keine Fehler gefunden"))
        elif key == "log_filter":
            self.log_filter()
        elif key == "log_export":
            self.log_export()
        elif key == "log_debug":
            m.set_debug_logging(not m.debug_logging())
        elif key == "tweak_device":
            dialogs.device()
        elif key == "tweak_advanced":
            text = m.advanced_text()
            index = dialogs.select("advancedsettings.xml", [(T("Empfehlung für dieses Gerät"), T("RAM und Speicher prüfen")),
                                                            (T("Anzeigen"), ""), (T("Netzwerk-Vorlage eintragen"), ""),
                                                            (T("Datei löschen"), ""),
                                                            (T("Werte von Hand eingeben"), T("mit Tipps zu jedem Eintrag"))])
            if index == 4:
                self.advanced_manual()
            elif index == 0:
                dialogs.device()
            elif index == 1:
                dialogs.text("advancedsettings.xml", text.replace("<", "&lt;") if text else T("Nicht vorhanden"))
            elif index == 2:
                m.apply_network_preset()
            elif index == 3 and dialogs.confirm("advancedsettings.xml", "Datei wirklich löschen?"):
                m.remove_advanced()
        elif key == "tweak_unknown":
            m.set_unknown_sources(not m.unknown_sources())
        elif key == "tweak_network":
            m.apply_network_preset()
            dialogs.notify("Netzwerk-Einstellungen eingetragen")
        elif key == "tweak_refresh":
            index = dialogs.select("Bildwiederholrate", [(T(x), "") for x in m.REFRESH_MODES])
            if index is not None:
                m.set_refresh_mode(index)
        elif key == "tweak_speed":
            def work(ui):
                mbit = m.speedtest(lambda p: ui.update(p, ""))
                state = load_state()
                state["last_speed"] = round(mbit, 1)
                save_state(state)
                return T("{0} Mbit/s").format(round(mbit, 1))
            dialogs.run("Speedtest", work)
        elif key == "misc_reload":
            self.reload_after = True      # erst schließen, dann neu laden - sonst lädt Kodi das Fenster mit neu
            self.close()
        elif key == "misc_quit":
            if dialogs.confirm("Kodi beenden", "Kodi jetzt sofort schließen?"):
                kill_kodi()
        elif key == "misc_sources":
            result, _e = dialogs.run("Quellen prüfen", lambda ui: m.check_sources())
            if result is not None:
                dialogs.text("Quellen", "[CR]".join("{0}  {1}  {2}".format(
                    "?" if ok is None else ("OK" if ok else T("fehlt")), name, path) for name, path, ok in result)
                    or T("Keine Quellen eingetragen"))
        elif key == "misc_addondb":
            if dialogs.confirm("Addon-Datenbank", "Datenbank neu aufbauen? Kodi startet danach neu, alle Addons "
                                                  "werden wieder eingeschaltet.", danger=True):
                m.repair_addon_database()
                kill_kodi()
        elif key == "misc_skin":
            m.reset_skin()
        elif key == "misc_fresh":
            if self.pin_ok() and dialogs.confirm("Fresh Start", "Kodi komplett zurücksetzen? Alle Addons und Einstellungen werden "
                                              "gelöscht - nur Save Data, die Whitelist, der Wizard und sein "
                                              "Repository bleiben.", danger=True) and \
                    dialogs.confirm("Fresh Start", "Wirklich? Das lässt sich nicht rückgängig machen.", yes="Ja, zurücksetzen",
                                    danger=True):
                _r, error = dialogs.run("Fresh Start", lambda ui: (m.fresh_start(ui), "Kodi wird jetzt beendet.")[1])
                if not error:
                    kill_kodi()
        if freed is not None:
            dialogs.notify(T("{0} frei").format(human_size(freed)))

    # Backup
    def create_backup(self, kind):
        if kind == "folder":
            return
        name = dialogs.keyboard("Name für das Backup (optional)", "")
        if name is None:
            return
        path, error = dialogs.run(T("Backup erstellen"), lambda ui: backup.create(kind, ui, name=name))
        if path:
            dialogs.ok("Backup erstellt", backup.describe(path))

    def restore(self, key):
        if not self.pin_ok():
            return
        if key == "restore_file":
            path = xbmcgui.Dialog().browse(1, T("Backup wählen"), "files", ".zip")
            if not path:
                return
        else:
            path = key.split(":", 1)[1]
            index = dialogs.select(os.path.basename(path), [(T("Wiederherstellen"), ""), (T("Löschen"), "")])
            if index is None:
                return
            if index == 1:
                if dialogs.confirm("Backup löschen", os.path.basename(path)):
                    backup.delete(path)
                return
        full = os.path.basename(path).startswith(("kodi_full_", "kodi_park_", "kodi_restore_"))
        if not dialogs.confirm("Wiederherstellen", T("Backup {0} zurückspielen? Kodi startet danach neu.").format(
                os.path.basename(path)), danger=full):
            return
        _r, error = dialogs.run("Wiederherstellen", lambda ui: backup.restore(path, ui, fresh=full) and
                                builds.after_install_text())
        if not error:
            kill_kodi()

    # Zugänge & API-Schlüssel
    def accounts(self):
        from resources.lib import accounts as acc
        while True:
            stored = acc.load()
            items = []
            for svc in acc.SERVICES:
                have = stored.get(svc["key"]) or {}
                items.append((T(svc["name"]), "  ·  ".join("{0}: {1}".format(T(label), acc.mask(have[f]))
                                                           for f, label in svc["fields"].items() if have.get(f))
                              or T("nicht gespeichert")))
            items.append((T("Anmeldung von einem Addon übernehmen"), T("Real-Debrid, Trakt, Premiumize ...")))
            index = dialogs.select("Zugänge & API-Schlüssel", items)
            if index is None:
                return
            if index == len(acc.SERVICES):
                self.account_sync()
            else:
                self.account_service(acc.SERVICES[index])

    def account_service(self, svc):
        from resources.lib import accounts as acc
        stored = acc.load()
        have = stored.get(svc["key"]) or {}
        options = [("Eingeben / ändern", "edit")]
        found = acc.found_values(svc["key"])
        if found:
            options.append((T("Aus einem Addon übernehmen ({0} gefunden)").format(len(found)), "take"))
        if have:
            options += [("In alle passenden Addons eintragen", "apply"), ("Gespeicherten Wert löschen", "forget")]
        index = dialogs.select(T(svc["name"]), [(T(label), "") for label, _k in options])
        if index is None:
            return
        action = options[index][1]
        if action == "edit":
            values = dict(have)
            for field, label in svc["fields"].items():
                text = dialogs.keyboard("{0}: {1}".format(T(svc["name"]), T(label)), values.get(field, ""),
                                        hidden=field != "user")
                if text is None:
                    return
                values[field] = text.strip()
            stored[svc["key"]] = values
            acc.save(stored)
            if dialogs.confirm(T(svc["name"]), "Gespeichert. Jetzt in alle passenden Addons eintragen?"):
                self.account_apply(svc, values)
        elif action == "take":
            pick = dialogs.select("Aus einem Addon übernehmen", [(a, "{0}: {1}".format(T(svc["fields"][f]),
                                                                                     acc.mask(v)))
                                                               for a, f, v in found])
            if pick is not None:
                _addon, field, value = found[pick]
                have = dict(have, **{field: value})
                stored[svc["key"]] = have
                acc.save(stored)
                dialogs.notify(T("Gespeichert"))
        elif action == "apply":
            self.account_apply(svc, have)
        elif action == "forget":
            if dialogs.confirm(T(svc["name"]), "Gespeicherten Wert auf diesem Gerät löschen? In Addons "
                                               "eingetragene Werte bleiben."):
                stored.pop(svc["key"], None)
                acc.save(stored)

    def account_apply(self, svc, values):
        from resources.lib import accounts as acc
        entries = [e for e in acc.plan(svc["key"]) if values.get(e[2])]
        if not entries:
            dialogs.ok(T(svc["name"]), "In den installierten Addons gibt es dafür keine passende Einstellung.")
            return
        chosen = dialogs.select(T("Wo eintragen? ({0} Fundstellen)").format(len(entries)),
                                [(a, "{0}  ·  {1}".format(s, T(svc["fields"][f]))) for a, s, f in entries],
                                multi=True, preselect=range(len(entries)))
        if not chosen:
            return
        done, errors = acc.apply([entries[i] for i in chosen], values)
        text = T("{0} Einstellung(en) eingetragen.").format(done)
        if errors:
            text += "[CR][CR]" + T("Nicht möglich (Addon ausgeschaltet?): {0}").format(", ".join(errors[:6]))
        dialogs.ok(T(svc["name"]), text)

    def account_sync(self):
        from resources.lib import accounts as acc
        index = dialogs.select("Anmeldung von einem Addon übernehmen", [(T(s["name"]), "") for s in acc.SYNC])
        if index is None:
            return
        svc = acc.SYNC[index]
        sources = acc.sync_sources(svc["key"])
        if not sources:
            dialogs.ok(T(svc["name"]), "Kein Addon ist hier angemeldet. Bitte zuerst in einem Addon anmelden "
                                       "(z.B. ResolveURL: Konto verknüpfen) und dann übernehmen.")
            return
        pick = dialogs.select(T("Welches Addon ist angemeldet?"), [(a, T("{0} Werte").format(n)) for a, n in sources])
        if pick is None:
            return
        entries = acc.sync_plan(svc["key"], sources[pick][0])
        targets = sorted({a for a, _s, _v in entries})
        if not targets:
            dialogs.ok(T(svc["name"]), "Kein anderes Addon hat dieselben Einstellungen - die Anmeldung lässt sich "
                                       "nur innerhalb einer Addon-Familie übertragen.")
            return
        chosen = dialogs.select(T("Übertragen an ({0} Addons)").format(len(targets)), [(a, "") for a in targets],
                                multi=True, preselect=range(len(targets)))
        if not chosen:
            return
        wanted = {targets[i] for i in chosen}
        done, errors = acc.apply_sync([e for e in entries if e[0] in wanted])
        dialogs.ok(T(svc["name"]), T("{0} Einstellung(en) übertragen.").format(done) +
                   ("[CR][CR]" + ", ".join(errors[:6]) if errors else ""))

    def undo_install(self):
        """Letzte Build-Installation (oder Fresh Start) rückgängig: neuesten Wiederherstellungspunkt zurückspielen"""
        if not self.pin_ok():
            return
        path = backup.last_restore_point()
        if not path:
            dialogs.ok("Rückgängig", "Kein Wiederherstellungspunkt vorhanden.")
            return
        if not dialogs.confirm("Letzte Installation rückgängig machen", T(
                "Den Stand {0} zurückholen? Was seitdem geändert wurde, geht verloren. Kodi startet danach neu.").format(
                _point_text(path)), yes="Zurückholen", danger=True):
            return
        _r, error = dialogs.run("Rückgängig", lambda ui: backup.restore(path, ui, fresh=True) and
                                builds.after_install_text())
        if not error:
            kill_kodi()

    # Save Data
    def save_action(self, key):
        if key == "save_now":
            count = savedata.save()
            dialogs.notify(T("{0} Dateien gesichert").format(count))
        elif key == "save_restore":
            if dialogs.confirm("Save Data", "Gesicherte Anmeldungen und Dateien zurückspielen?"):
                savedata.restore()
                dialogs.notify("Save Data zurückgespielt")
        elif key == "save_clear":
            if self.pin_ok() and dialogs.confirm("Save Data", "Alle gesicherten Daten löschen?", danger=True):
                savedata.clear()
        elif key == "save_whitelist":
            state = load_state()
            addons = maintenance.user_addons()
            chosen = [i for i, a in enumerate(addons) if a["id"] in state.get("whitelist", [])]
            result = dialogs.select("Whitelist", [(a["name"], a["id"]) for a in addons], multi=True, preselect=chosen)
            if result is not None:
                state["whitelist"] = [addons[i]["id"] for i in result]
                save_state(state)


def download_estimate(size):
    """„Download: 812 MB - ca. 2 Minuten bei 50 Mbit/s“ (Geschwindigkeit aus dem letzten Speedtest)"""
    speed = float(load_state().get("last_speed") or 0)
    if not size:
        return ""
    if speed <= 0:
        return T("Download: {0} - für eine Zeitschätzung einmal den Speedtest ausführen (Wartung > System-Optimierung).").format(
            human_size(size))
    seconds = size * 8 / (speed * 1000000.0)
    when = T("unter einer Minute") if seconds < 60 else T("ca. {0} Minuten").format(int(round(seconds / 60.0)) or 1)
    return T("Download: {0} - {1} bei {2} Mbit/s").format(human_size(size), when, speed)


def repair_wizard_files():
    """Wizard-Dateien neu vom Server laden (Selbstprüfung). True = erledigt"""
    try:
        info = builds.load_list(refresh=True).get("wizard") or {}
    except Exception as e:  # noqa: BLE001
        dialogs.ok("Wizard reparieren", T("Build-Liste nicht erreichbar: {0}").format(e))
        return False
    if not info.get("zip"):
        dialogs.ok("Wizard reparieren", "Auf dem Server liegt kein Wizard.")
        return False
    if not dialogs.confirm("Wizard reparieren", T("Wizard {0} neu vom Server laden und alle Dateien ersetzen? "
                                                  "Einstellungen und Backups bleiben erhalten.").format(
            info.get("version", "?")), yes="Reparieren", no="Abbrechen"):
        return False
    _r, error = dialogs.run("Wizard reparieren", lambda ui: builds.install_wizard_update(info, ui) or
                            "Der Wizard wurde neu geladen. Bitte den Wizard neu öffnen.")
    if error:
        return False
    from resources.lib import selfcheck
    selfcheck.run()
    xbmc.executebuiltin("UpdateLocalAddons")
    return True


def open_main(start="builds"):
    from resources.lib import selfcheck
    allowed = selfcheck.guard()
    if allowed == "repair":
        repair_wizard_files()
        return
    if not allowed:
        return
    if load_state().get("splash", True):
        try:
            dialogs.splash()
        except Exception:  # noqa: BLE001 - Startbild ist nur Schmuck
            pass
    window = Main("sk_main.xml", ADDON_PATH, "Default", "1080i", start=start)
    window.doModal()
    reload_after = getattr(window, "reload_after", False)
    del window
    log("Wizard geschlossen")
    if reload_after:
        maintenance.reload_profile()
