# -*- coding: utf-8 -*-
"""Widget fürs Hauptmenü des Skins (Punkt 285): plugin://<Wizard-ID>/ - siehe resources/lib/widget.py"""
import sys

from resources.lib import widget

widget.run(sys.argv)
