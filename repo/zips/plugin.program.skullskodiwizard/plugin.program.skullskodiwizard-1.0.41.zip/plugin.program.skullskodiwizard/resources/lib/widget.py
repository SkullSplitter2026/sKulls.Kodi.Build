# -*- coding: utf-8 -*-
"""
Widget fürs Hauptmenü (Punkt 285): plugin://<Wizard-ID>/ liefert eine kleine Liste für die Startseite des Skins -
installierter Build, „Update verfügbar“ und Schnellzugriffe (Wizard, Builds, Updates suchen, Cache leeren, Wartung).
Die Liste kommt nur aus dem gespeicherten Zustand (kein Netz) - sie lädt also sofort.

Ein Klick auf einen Eintrag ruft das Plugin mit ?action=... auf; „open“ startet den Wizard (auf Wunsch gleich mit
einer Seite), „check“ sucht nach Updates, „clean“ leert Cache und alte Pakete.
"""

import os
import time
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.common import ADDON_ID, ADDON_NAME, ADDON_PATH, human_size, jsonrpc, load_state, log, unbold
from resources.lib.texts import T

ROOT = "plugin://{0}/".format(ADDON_ID)
ICONS = os.path.join(ADDON_PATH, "resources", "skins", "Default", "media", "icons")
ADDON_ICON = os.path.join(ADDON_PATH, "icon.png")


def url(**params):
    return ROOT + ("?" + urllib.parse.urlencode(params) if params else "")


def _icon(name):
    path = os.path.join(ICONS, name + ".png")
    return path if os.path.isfile(path) else ADDON_ICON


def _when(stamp):
    if not stamp:
        return T("noch nie")
    return time.strftime("%d.%m. %H:%M", time.localtime(stamp))


def items(state=None):
    """[(Titel, zweite Zeile, Symbol, Adresse)]"""
    from resources.lib.service import update_text
    state = state or load_state()
    current = state.get("build") or {}
    updates = state.get("updates") or {}
    builds_url = url(action="open", view="builds")
    if current:
        rows = [("{0} v{1}".format(unbold(current.get("name", "")), current.get("version", "?")).strip(),
                 T("Installierter Build"), "builds", builds_url)]
    else:
        rows = [(T("Noch kein Build installiert"), T("Builds ansehen und installieren"), "builds", builds_url)]
    if updates:
        rows.append((T("Update verfügbar"), update_text(updates), "refresh", builds_url))
    rows += [(T("Wizard öffnen"), unbold(ADDON_NAME), "wizard", url(action="open")),
             (T("Nach Updates suchen"), T("Zuletzt: {0}").format(_when(state.get("last_update_check"))), "refresh",
              url(action="check")),
             (T("Cache leeren"), T("Cache und alte Pakete löschen"), "clean", url(action="clean")),
             (T("Wartung"), T("Aufräumen, Addons, Log, Optimierung"), "maint", url(action="open", view="maint"))]
    return rows


def _listitem(label, label2, icon_name):
    item = xbmcgui.ListItem(label, label2)
    icon = _icon(icon_name)
    item.setArt({"icon": icon, "thumb": icon, "fanart": os.path.join(ADDON_PATH, "fanart.jpg")})
    item.setProperty("IsPlayable", "false")
    try:                                # Kodi 20+: InfoTag statt setInfo
        item.getVideoInfoTag().setPlot(label2)
    except AttributeError:
        item.setInfo("video", {"plot": label2})
    return item


def listing(handle):
    for label, label2, icon_name, target in items():
        xbmcplugin.addDirectoryItem(handle, target, _listitem(label, label2, icon_name), isFolder=False)
    xbmcplugin.setContent(handle, "files")
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def act(action, params):
    from resources.lib import dialogs
    if action == "open":
        view = params.get("view", "")
        xbmc.executebuiltin("RunScript({0}{1})".format(ADDON_ID, ",view=" + view if view.isalnum() else ""))
    elif action == "check":
        from resources.lib import service
        if not service.check_updates():
            dialogs.notify(T("Alles aktuell - keine Updates"))
    elif action == "clean":
        from resources.lib import maintenance
        freed = maintenance.cleanup(["cache", "packages"])
        dialogs.notify(T("{0} frei").format(human_size(freed)))
    else:
        log("Widget: unbekannte Aktion {0}".format(action))


def run(argv):
    """Einstieg für widget.py: argv = [plugin://…, Handle, ?Abfrage]"""
    handle = int(argv[1]) if len(argv) > 1 and argv[1].lstrip("-").isdigit() else -1
    params = dict(urllib.parse.parse_qsl((argv[2] if len(argv) > 2 else "").lstrip("?")))
    if params.get("action"):
        act(params["action"], params)
    elif handle >= 0:
        listing(handle)


def add_favourite():
    """Schnellzugriff über Kodis Favoriten (laufen auf jedem Skin): öffnet die Widget-Liste. True = eingetragen"""
    result = jsonrpc("Favourites.AddFavourite", {"title": "{0} - {1}".format(unbold(ADDON_NAME), T("Schnellzugriff")),
                                                 "type": "window", "window": "programs", "windowparameter": ROOT,
                                                 "thumbnail": ADDON_ICON})
    return result == "OK"
