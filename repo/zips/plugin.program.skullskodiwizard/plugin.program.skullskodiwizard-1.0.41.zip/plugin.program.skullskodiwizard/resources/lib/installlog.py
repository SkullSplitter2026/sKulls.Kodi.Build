# -*- coding: utf-8 -*-
"""
Installationsprotokoll (Punkt 279): jede Build-Installation schreibt ihre Schritte mit Dauer, die Warnungen und alle
Meldungen in addon_data/<Wizard>/install_logs. Ansehen direkt nach der Installation (Knopf „Protokoll“ im
Fortschrittsfenster) oder später unter Wartung > Log > Installationsprotokolle, auf Wunsch als Datei speichern.
"""

import json
import os
import time

import xbmc
import xbmcgui

from resources.lib.common import (ADDON_NAME, ADDON_VERSION, DATA, PLATFORM_NAMES, device_platform, log, log_error,
                                  unbold)
from resources.lib.texts import T

FOLDER = os.path.join(DATA, "install_logs")
INDEX = os.path.join(FOLDER, "index.json")
KEEP = 10                       # so viele Protokolle bleiben, ältere werden gelöscht


def _clock(seconds):
    seconds = int(max(0, seconds))
    if seconds >= 3600:
        return "{0}:{1:02d}:{2:02d}".format(seconds // 3600, seconds % 3600 // 60, seconds % 60)
    return "{0}:{1:02d}".format(seconds // 60, seconds % 60)


def _stamp(moment, fmt="%H:%M:%S"):
    return time.strftime(fmt, time.localtime(moment))


def is_warning(level):
    return level >= xbmc.LOGWARNING


def text(title, started, steps, durations, messages, error=None, now=None):
    """Protokoll als Text. steps: Namen der Schritte (übersetzt), durations: Dauer je erledigtem Schritt,
    messages: [(Zeit, Stufe, Meldung)] aus common.capture"""
    now = now or time.time()
    durations = list(durations) + [now - started - sum(durations)] * (len(steps) - len(durations))
    warnings = [(t, m) for t, level, m in messages if is_warning(level)]
    width = max([len(s) for s in steps] + [20])
    lines = [T("Installationsprotokoll"), "=" * 60,
             T("Vorgang: {0}").format(unbold(title)),
             T("Wizard: {0} {1}").format(unbold(ADDON_NAME), ADDON_VERSION),
             "Kodi: {0}".format(xbmc.getInfoLabel("System.BuildVersion")),
             T("System: {0}").format(PLATFORM_NAMES.get(device_platform(), "?")),
             T("Beginn: {0}").format(_stamp(started, "%Y-%m-%d %H:%M:%S")),
             T("Dauer: {0}").format(_clock(now - started)),
             T("Ergebnis: {0}").format(T("Fehler - {0}").format(error) if error else
                                       T("Erfolgreich") if not warnings else
                                       T("Erfolgreich, mit {0} Warnung(en)").format(len(warnings))),
             "", T("Schritte ({0})").format(len(steps))]
    for index, name in enumerate(steps):
        mark = "XX" if error and index == len(steps) - 1 else "OK"
        lines.append("  [{0}]  {1}  {2:>8}".format(mark, name.ljust(width), _clock(durations[index])))
    lines += ["", T("Warnungen ({0})").format(len(warnings))]
    lines += ["  {0}  {1}".format(_stamp(t), m) for t, m in warnings] or ["  " + T("keine")]
    lines += ["", T("Alle Meldungen ({0})").format(len(messages))]
    lines += ["  {0}  {1}{2}".format(_stamp(t), "! " if is_warning(level) else "", m) for t, level, m in messages] \
        or ["  " + T("keine")]
    return "\n".join(lines) + "\n", len(warnings)


def _load_index():
    try:
        with open(INDEX, "r", encoding="utf-8") as f:
            data = json.load(f)
        return [e for e in data if isinstance(e, dict) and e.get("file")] if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_index(entries):
    with open(INDEX, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=1, ensure_ascii=False)


def save(title, started, steps, durations, messages, error=None):
    """Protokoll schreiben, nur die letzten KEEP behalten. Rückgabe: Pfad (None, wenn das Schreiben scheitert)"""
    now = time.time()
    content, warnings = text(title, started, steps, durations, messages, error, now)
    try:
        if not os.path.isdir(FOLDER):
            os.makedirs(FOLDER)
        stem = "install-{0}".format(_stamp(started, "%Y%m%d-%H%M%S"))
        name, number = stem + ".txt", 1
        while os.path.exists(os.path.join(FOLDER, name)):       # zwei Läufe in derselben Sekunde
            number += 1
            name = "{0}-{1}.txt".format(stem, number)
        path = os.path.join(FOLDER, name)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        entries = [e for e in _load_index() if e["file"] != name]
        entries.insert(0, {"file": name, "title": unbold(title), "date": _stamp(started, "%Y-%m-%d %H:%M"),
                           "duration": int(now - started), "ok": not error, "warnings": warnings})
        for old in entries[KEEP:]:
            try:
                os.remove(os.path.join(FOLDER, old["file"]))
            except OSError:
                pass
        _save_index(entries[:KEEP])
    except OSError as e:
        log_error("Installationsprotokoll nicht gespeichert: {0}".format(e))
        return None
    log("Installationsprotokoll: {0}".format(name))
    return path


def entries():
    """Gespeicherte Protokolle, neuestes zuerst (nur solche, deren Datei noch da ist)"""
    return [e for e in _load_index() if os.path.isfile(os.path.join(FOLDER, e["file"]))]


def summary(entry):
    """Zweite Zeile in Listen: Datum, Dauer, Ergebnis"""
    result = T("Fehler") if not entry.get("ok") else \
        T("{0} Warnung(en)").format(entry["warnings"]) if entry.get("warnings") else T("Erfolgreich")
    return "{0}  ·  {1}  ·  {2}".format(entry.get("date", ""), _clock(entry.get("duration", 0)), result)


def read(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        return T("Protokoll nicht lesbar: {0}").format(e)


def export(path):
    """Als Datei speichern (USB-Stick, Netzwerk ...). Rückgabe: Ziel oder None"""
    from resources.lib import dialogs, maintenance
    folder = xbmcgui.Dialog().browse(3, T("Wohin speichern? (USB-Stick, Netzwerk ...)"), "files")
    if not folder:
        return None
    try:
        target = maintenance.export_log(read(path), folder, os.path.basename(path))
    except Exception as e:  # noqa: BLE001
        log_error("Installationsprotokoll speichern: {0}".format(e))
        dialogs.ok("Installationsprotokoll", T("Speichern fehlgeschlagen: {0}").format(e))
        return None
    log("Installationsprotokoll gespeichert: {0}".format(target))
    dialogs.ok("Installationsprotokoll", T("Gespeichert: {0}").format(target))
    return target


def show(path, heading="Installationsprotokoll", allow_delete=False):
    """Ansehen / als Datei speichern (/ löschen). Rückgabe: True, wenn gelöscht"""
    from resources.lib import dialogs
    options = [(T("Ansehen"), T("Schritte, Dauer, Warnungen und alle Meldungen"), "document", "view"),
               (T("Als Datei speichern"), T("Auf USB-Stick oder Netzwerk - z.B. zum Weitergeben an den Support"),
                "save", "export")]
    if allow_delete:
        options.append((T("Löschen"), T("Nur dieses Protokoll"), "delete", "delete"))
    while True:
        index = dialogs.select(heading, [(label, "", info, symbol) for label, info, symbol, _k in options],
                               search=False)
        if index is None:
            return False
        action = options[index][3]
        if action == "view":
            dialogs.text(heading, read(path).replace("\n", "[CR]"))
        elif action == "export":
            export(path)
        else:
            try:
                os.remove(path)
            except OSError:
                pass
            _save_index([e for e in _load_index() if e["file"] != os.path.basename(path)])
            return True


def browse():
    """Wartung > Log > Installationsprotokolle: Liste aller gespeicherten Protokolle"""
    from resources.lib import dialogs
    while True:
        items = entries()
        if not items:
            dialogs.ok("Installationsprotokolle", "Noch keine Build-Installation protokolliert.")
            return
        index = dialogs.select("Installationsprotokolle", [(e.get("title", e["file"]), summary(e), "",
                                                            "history" if e.get("ok") else "warning") for e in items],
                               search=False)
        if index is None:
            return
        show(os.path.join(FOLDER, items[index]["file"]), items[index].get("title") or "Installationsprotokoll",
             allow_delete=True)
