# -*- coding: utf-8 -*-
"""
Netzwerk: lädt die Build-Liste und die Builds von der Adresse, die der sKulls Forge beim Bauen einträgt
(z.B. GitHub Pages oder ein eigener Webserver). Downloads werden gegen Größe und SHA-256 aus der Build-Liste geprüft.

Abgebrochene Downloads (Abbrechen, WLAN weg, Kodi beendet) bleiben als .part liegen und werden beim nächsten Mal mit
einer Range-Anfrage fortgesetzt - aber nur, wenn es dieselbe Datei ist (gleiche Prüfsumme und Größe laut Build-Liste,
gemerkt in .part.json). Kann der Server nicht fortsetzen (Antwort 200 statt 206), wird neu geladen.
"""

import hashlib
import json
import os
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

from resources.lib import config
from resources.lib.texts import T
from resources.lib.common import ADDON_ID, ADDON_VERSION, log

TIMEOUT = 30
CHUNK = 256 * 1024


class NetError(Exception):
    def __init__(self, message="", code=0):
        super().__init__(message)
        self.code = code              # HTTP-Status, 0 = keine Antwort vom Server


def _context():
    try:
        import certifi  # script.module.certifi, falls vorhanden
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:  # noqa: BLE001
        return ssl.create_default_context()


def url_for(name):
    """Name aus der Build-Liste -> Adresse (absolute Adressen bleiben, wie sie sind)"""
    if name.startswith(("https://", "http://")):
        return name
    base = (config.get("server") or {}).get("base", "")
    return base.rstrip("/") + "/" + name.lstrip("/")


def _open(name, timeout=TIMEOUT, headers=None):
    url = url_for(name)
    if not url.startswith(("https://", "http://")):
        raise NetError(T("Keine Adresse für die Build-Liste eingetragen"))
    request = urllib.request.Request(url, headers=dict({"User-Agent": "{0}/{1} Kodi".format(ADDON_ID, ADDON_VERSION)},
                                                       **(headers or {})))
    try:
        if url.startswith("https://"):
            return urllib.request.urlopen(request, timeout=timeout, context=_context())
        return urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.HTTPError as e:
        raise NetError(T("Server-Fehler {0}").format(e.code), e.code)
    except Exception as e:  # noqa: BLE001
        raise NetError(str(e))


SLOW_MBIT = 2.0                 # darunter warnt der Netzwerk-Check
SLOW_MINUTES = 45               # oder wenn der Download voraussichtlich länger dauert


def _reason(error):
    """Fehlertext ohne Python-Hülle („<urlopen error [Errno 11001] ...>“ -> „[Errno 11001] ...“)"""
    text = str(getattr(error, "reason", "") or error)
    return text.replace("<urlopen error ", "").rstrip(">")


def precheck(name, size=0, seconds=3.0, sample=8 * 1024 * 1024, resolve=None, opener=None):
    """Netzwerk-Check vor dem Download (Punkt 284): Name des Servers auflösen (DNS), Verbindung aufbauen und kurz
    die Datei selbst laden (Geschwindigkeitstest, höchstens seconds/sample). Rückgabe:
    {"host", "ok", "kind" ("" | url | dns | connect | http | slow), "problem", "speed" (Mbit/s, 0 = unbekannt),
     "minutes" (geschätzte Download-Dauer, 0 = unbekannt), "ms" (Antwortzeit)}"""
    resolve = resolve or socket.getaddrinfo
    url = url_for(name)
    parts = urllib.parse.urlparse(url)
    result = {"host": parts.hostname or "", "ok": False, "kind": "", "problem": "", "speed": 0.0, "minutes": 0,
              "ms": 0}
    if parts.scheme not in ("http", "https") or not parts.hostname:
        result.update(kind="url", problem=T("Keine gültige Download-Adresse in der Build-Liste."))
        return result
    try:
        resolve(parts.hostname, parts.port or (443 if parts.scheme == "https" else 80))
    except (socket.gaierror, socket.herror, UnicodeError, OSError) as e:
        log("Netzwerk-Check: DNS {0}: {1}".format(parts.hostname, e))
        result.update(kind="dns", problem=T(
            "Der Server {0} ist nicht auffindbar (DNS). Meist fehlt die Internetverbindung - WLAN/LAN prüfen und "
            "ob andere Seiten laden.").format(parts.hostname))
        return result
    started = time.time()
    try:
        response = (opener or _open)(name, timeout=15, headers={"Range": "bytes=0-{0}".format(sample - 1)})
    except NetError as e:
        if e.code == 404:
            problem = T("Die Build-Datei fehlt auf dem Server (404) - der Anbieter muss sie neu hochladen.")
        elif e.code in (401, 403):
            problem = T("Der Server verweigert den Download ({0}).").format(e.code)
        elif e.code:
            problem = T("Der Server meldet einen Fehler ({0}) - später noch einmal versuchen.").format(e.code)
        else:
            problem = T("Keine Verbindung zum Server {0}: {1}").format(parts.hostname, _reason(e))
        log("Netzwerk-Check: {0}: {1}".format(parts.hostname, e))
        result.update(kind="http" if e.code else "connect", problem=problem)
        return result
    result["ms"] = int((time.time() - started) * 1000)
    loaded, begin = 0, time.time()
    try:
        with response:
            while loaded < sample and time.time() - begin < seconds:
                chunk = response.read(min(CHUNK, sample - loaded))
                if not chunk:
                    break
                loaded += len(chunk)
    except (socket.timeout, OSError) as e:
        result.update(kind="connect", problem=T("Die Verbindung zum Server {0} bricht ab: {1}").format(
            parts.hostname, _reason(e)))
        return result
    spent = max(time.time() - begin, 0.05)
    if loaded >= 256 * 1024 or (size and loaded >= size):        # zu wenig Daten = keine verlässliche Messung
        result["speed"] = round(loaded * 8 / spent / 1000000.0, 1)
        if size and result["speed"]:
            result["minutes"] = int(size * 8 / (result["speed"] * 1000000.0) / 60 + 0.999)
    result["ok"] = True
    if result["speed"] and (result["speed"] < SLOW_MBIT or result["minutes"] > SLOW_MINUTES):
        result["kind"] = "slow"
    log("Netzwerk-Check: {0} erreichbar ({1} ms), {2} Mbit/s".format(parts.hostname, result["ms"],
                                                                     result["speed"] or "?"))
    return result


def fetch_json(name, limit=2 * 1024 * 1024):
    with _open(name) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise NetError("Antwort zu groß")
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError:
        raise NetError("Ungültige Antwort vom Server")


def call_api(url, headers=None, timeout=15, limit=512 * 1024):
    """Anfrage an einen fremden Dienst (Schlüssel- und Konto-Prüfung, Punkte 183/186): (HTTP-Status, JSON oder None).
    HTTP-Fehler wie 401 sind hier eine Antwort, kein Fehler; ohne Verbindung -> NetError. Schlüssel nie ins Log."""
    request = urllib.request.Request(url, headers=dict({"User-Agent": "{0}/{1} Kodi".format(ADDON_ID, ADDON_VERSION),
                                                        "Accept": "application/json"}, **(headers or {})))
    try:
        response = urllib.request.urlopen(request, timeout=timeout, context=_context())
        status = getattr(response, "status", 200)
    except urllib.error.HTTPError as e:
        response, status = e, e.code
    except Exception as e:  # noqa: BLE001
        raise NetError(str(e))
    try:
        data = response.read(limit)
    except Exception:  # noqa: BLE001
        data = b""
    finally:
        try:
            response.close()
        except Exception:  # noqa: BLE001
            pass
    try:
        return status, json.loads(data.decode("utf-8")) if data else None
    except ValueError:
        return status, None


def _part_matches(tmp, sha256, size):
    """Gehört die angefangene Datei zu genau diesem Download?"""
    try:
        with open(tmp + ".json") as f:
            meta = json.load(f)
    except (OSError, ValueError):
        return False
    have = os.path.getsize(tmp) if os.path.isfile(tmp) else 0
    return bool(sha256) and meta.get("sha256") == sha256 and int(meta.get("size") or 0) == int(size or 0) and \
        0 < have < (int(size) if size else have + 1)


def _discard(tmp):
    for path in (tmp, tmp + ".json"):
        try:
            os.remove(path)
        except OSError:
            pass


def download(name, dest, sha256="", size=0, progress=None):
    """Lädt nach dest. progress(geladen, gesamt) -> False bricht ab. Prüft Größe und SHA-256.
    Ein abgebrochener Download wird beim nächsten Aufruf fortgesetzt (siehe oben)."""
    digest = hashlib.sha256()
    tmp = dest + ".part"
    folder = os.path.dirname(dest)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    offset = 0
    if _part_matches(tmp, sha256, size):
        offset = os.path.getsize(tmp)
    else:
        _discard(tmp)
    with open(tmp + ".json", "w") as f:
        json.dump({"sha256": sha256, "size": int(size or 0), "name": name}, f)
    response = _open(name, timeout=60, headers={"Range": "bytes={0}-".format(offset)} if offset else None)
    with response:
        if offset and getattr(response, "status", 200) != 206:
            log("Server kann nicht fortsetzen - lade {0} neu".format(name))
            offset = 0
        if offset:
            with open(tmp, "rb") as f:      # Prüfsumme über den schon geladenen Teil
                for chunk in iter(lambda: f.read(CHUNK), b""):
                    digest.update(chunk)
            log("Setze Download fort: {0} ab {1} Bytes".format(name, offset))
        loaded = offset
        length = int(response.headers.get("Content-Length") or 0)
        total = (offset + length) if length else int(size or 0)
        with open(tmp, "ab" if offset else "wb") as f:
            while True:
                chunk = response.read(CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                digest.update(chunk)
                loaded += len(chunk)
                if progress and progress(loaded, total) is False:
                    raise NetError("Abgebrochen")        # .part bleibt - beim nächsten Mal geht es hier weiter
    if size and loaded != int(size):
        if loaded > int(size):
            _discard(tmp)
        raise NetError(T("Download unvollständig ({0} von {1} Bytes)").format(loaded, size))
    if sha256 and digest.hexdigest().lower() != sha256.lower():
        _discard(tmp)
        raise NetError("Prüfsumme stimmt nicht - Datei beschädigt oder verändert")
    os.replace(tmp, dest)
    _discard(tmp)
    log("Geladen: {0} ({1} Bytes, SHA-256 {2})".format(name, loaded, "geprüft" if sha256 else "ohne Prüfung"))
    return dest
