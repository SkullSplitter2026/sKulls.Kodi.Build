# -*- coding: utf-8 -*-
"""
Build vom USB-Stick (Punkt 283): eingesteckte Wechseldatenträger nach Build-ZIPs (und geschützten .skz) durchsuchen.
Die Builds-Seite bietet gefundene Builds direkt an, „Build aus Datei“ zeigt sie zuerst, und der Dienst meldet einen
neu eingesteckten Stick mit Build.

Wo Sticks auftauchen: Android /storage/<ID>, LibreELEC/CoreELEC /var/media, Linux /media und /run/media,
macOS /Volumes, Windows Laufwerke vom Typ „Wechseldatenträger“. Gesucht wird nur zwei Ordner tief, mit Zeitlimit.
"""

import json
import os
import time
import zipfile

from resources.lib.common import device_platform, log

SKIP_DIRS = {"android", "lost.dir", "system volume information", "$recycle.bin", ".trashes", ".spotlight-v100",
             ".fseventsd", "dcim", "music", "movies", "pictures", "podcasts", "ringtones", "alarms", "notifications"}
MIN_SIZE = 1024 * 1024          # kleinere ZIPs sind keine Builds
DEPTH = 2                       # Stick-Wurzel und zwei Ordnerebenen darunter
_cache = {"roots": None, "found": []}


def _subdirs(path):
    try:
        return [os.path.join(path, n) for n in sorted(os.listdir(path)) if os.path.isdir(os.path.join(path, n))]
    except OSError:
        return []


def _windows_removable():
    try:
        import ctypes
        kernel = ctypes.windll.kernel32
        mask = kernel.GetLogicalDrives()
    except Exception:  # noqa: BLE001
        return []
    drives = []
    for index in range(26):
        if mask & (1 << index):
            root = "{0}:\\".format(chr(65 + index))
            if kernel.GetDriveTypeW(root) == 2:          # DRIVE_REMOVABLE
                drives.append(root)
    return drives


def roots(platform=None):
    """Eingehängte Wechseldatenträger dieses Geräts"""
    platform = platform if platform is not None else device_platform()
    if platform == "windows":
        return _windows_removable()
    found = []
    if platform == "android":
        found = [p for p in _subdirs("/storage") if os.path.basename(p).lower() not in ("emulated", "self",
                                                                                        "enc_emulated", "sdcard0")]
    elif platform == "osx":
        found = [p for p in _subdirs("/Volumes") if os.path.realpath(p) != "/"]
    elif platform == "linux":
        found = _subdirs("/var/media") + _subdirs("/mnt")          # LibreELEC/CoreELEC, von Hand eingehängt
        for user in _subdirs("/run/media"):                        # /run/media/<Benutzer>/<Stick>
            found += _subdirs(user)
        for path in _subdirs("/media"):                            # /media/<Stick> oder /media/<Benutzer>/<Stick>
            inner = [] if _has_files(path) else _subdirs(path)
            found += inner or [path]
    return [p for p in found if os.access(p, os.R_OK)]


def _has_files(path):
    try:
        return any(os.path.isfile(os.path.join(path, n)) for n in os.listdir(path))
    except OSError:
        return False


def zip_info(path):
    """Build-Angaben aus einer ZIP: None = kein Build, sonst {"name", "version"} (aus userdata/.skbuild.json,
    das der sKulls Forge in jeden Build legt - sonst leer)"""
    from resources.lib import builds
    try:
        with zipfile.ZipFile(path) as z:
            names = [n.replace("\\", "/") for n in z.namelist()]
            prefix = builds._zip_prefix(names)
            if not any(n[len(prefix):].startswith(("addons/", "userdata/")) for n in names):
                return None
            marker = next((n for n in names if n.endswith("userdata/.skbuild.json")), None)
            if not marker:
                return {}
            data = json.loads(z.read(marker).decode("utf-8"))
            return {"name": data.get("name", ""), "version": data.get("version", "")} if isinstance(data, dict) else {}
    except (OSError, ValueError, zipfile.BadZipFile, KeyError):
        return None


def _side_info(path):
    """Geschützter Build (.skz): Angaben aus <Datei>.json daneben"""
    for side in (path + ".json", os.path.splitext(path)[0] + ".skz.json"):
        try:
            with open(side, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("lock"), dict):
                return {"name": data.get("name", ""), "version": data.get("version", "")}
        except (OSError, ValueError):
            continue
    return None


def scan(paths=None, seconds=4.0):
    """Builds auf den Sticks: [{"path", "file", "name", "version", "size", "mtime", "root", "protected"}],
    neueste zuerst. Zeitlimit, damit langsame Sticks den Wizard nicht aufhalten."""
    deadline = time.time() + seconds
    found = []
    for root in (roots() if paths is None else paths):
        stack = [(root, 0)]
        while stack and time.time() < deadline:
            folder, depth = stack.pop(0)
            try:
                names = sorted(os.listdir(folder))
            except OSError:
                continue
            for name in names:
                path = os.path.join(folder, name)
                low = name.lower()
                if os.path.isdir(path):
                    if depth < DEPTH and not low.startswith(".") and low not in SKIP_DIRS:
                        stack.append((path, depth + 1))
                    continue
                if not low.endswith((".zip", ".skz")) or low.endswith("_guisettings.zip"):
                    continue
                try:
                    size, mtime = os.path.getsize(path), os.path.getmtime(path)
                except OSError:
                    continue
                if size < MIN_SIZE:
                    continue
                info = _side_info(path) if low.endswith(".skz") else zip_info(path)
                if info is None:
                    continue
                found.append({"path": path, "file": name, "name": info.get("name") or os.path.splitext(name)[0],
                              "version": info.get("version", ""), "size": size, "mtime": mtime, "root": root,
                              "protected": low.endswith(".skz")})
    found.sort(key=lambda b: -b["mtime"])
    if found:
        log("USB: {0} Build(s) gefunden: {1}".format(len(found), ", ".join(b["file"] for b in found[:5])))
    return found


def cached(force=False):
    """Wie scan(), aber nur neu suchen, wenn sich die eingesteckten Sticks geändert haben"""
    current = tuple(roots())
    if force or current != _cache["roots"]:
        _cache["roots"] = current
        _cache["found"] = scan(list(current)) if current else []
    return [b for b in _cache["found"] if os.path.isfile(b["path"])]


def label2(build):
    """Zweite Zeile: Version, Größe, Stick"""
    from resources.lib.common import human_size
    parts = ["v" + build["version"]] if build.get("version") else []
    parts += [human_size(build["size"]), os.path.basename(build["root"].rstrip("/\\")) or build["root"]]
    return "  ·  ".join(parts)


class Watcher:
    """Für den Dienst: meldet neu eingesteckte Sticks, auf denen ein Build liegt (Sticks beim Start zählen nicht)"""

    def __init__(self):
        self.known = set(roots())

    def poll(self):
        current = set(roots())
        new = current - self.known
        self.known = current
        return scan(sorted(new)) if new else []
