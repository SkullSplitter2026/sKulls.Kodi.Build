# -*- coding: utf-8 -*-
"""
Wizard-Fehlerberichte (Punkt 298): schlägt im Wizard etwas fehl, kann der Nutzer - nur mit Zustimmung - einen
anonymen Bericht an den Ersteller schicken. Wohin, legt der sKulls Forge fest (wizard.json „reports“):
ntfy (Thema auf ntfy.sh oder eigenem Server - der Forge kann die Berichte abrufen), Discord-Webhook oder eine eigene
Adresse (JSON per POST).

Im Bericht: Wizard- und Kodi-Version, System, installierter Build, Vorgang, Fehlermeldung und die letzten Zeilen des
Wizard-Logs - Passwörter, Tokens und MAC-Adressen unkenntlich, keine Geräte-Kennung, keine IP im Bericht.
Höchstens 5 Berichte am Tag, derselbe Fehler höchstens einmal in 24 Stunden.
"""

import hashlib
import json
import re
import time
import urllib.request

import xbmc

from resources.lib import config
from resources.lib.common import (ADDON_ID, ADDON_NAME, ADDON_VERSION, PLATFORM_NAMES, device_platform, load_state,
                                  log, log_error, save_state)
from resources.lib.texts import T

MODES = [("ask", "Jedes Mal fragen"), ("always", "Immer senden"), ("never", "Nie senden")]
PER_DAY = 5
SAME_ERROR = 24 * 3600
LOG_LINES = 30


def settings():
    """{"kind", "url"} aus wizard.json - None, wenn der Ersteller keine Fehlerberichte eingerichtet hat"""
    cfg = config.get("reports") or {}
    if cfg.get("kind") in ("ntfy", "discord", "webhook") and str(cfg.get("url", "")).startswith("https://"):
        return cfg
    return None


def mode():
    value = load_state().get("report_mode", "ask")
    return value if value in dict(MODES) else "ask"


def _key(task, error):
    return hashlib.sha1("{0}|{1}".format(task, error).encode("utf-8")).hexdigest()[:16]


def allowed(task, error, now=None):
    """Grenzen: 5 am Tag, derselbe Fehler einmal in 24 Stunden"""
    now = now or time.time()
    sent = {k: v for k, v in (load_state().get("reports_sent") or {}).items() if now - v < SAME_ERROR}
    return len(sent) < PER_DAY and _key(task, error) not in sent


def _remember(task, error):
    state = load_state()
    now = time.time()
    sent = {k: v for k, v in (state.get("reports_sent") or {}).items() if now - v < SAME_ERROR}
    sent[_key(task, error)] = now
    state["reports_sent"] = sent
    save_state(state)


_MARKUP = re.compile(r"\[/?(?:B|I|COLOR[^\]]*|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT|CR)\]", re.I)


def plain(text):
    """Ohne Kodi-Formatierung ([B], [COLOR …] …) - Berichte sind reiner Text"""
    return _MARKUP.sub("", text or "")


def build(task, error):
    from resources.lib import maintenance
    state = load_state()
    current = state.get("build") or {}
    tail = [l for l in maintenance.wizard_log().splitlines() if l.strip()][-LOG_LINES:]
    return {"wizard": plain(ADDON_NAME), "wizard_id": ADDON_ID, "version": ADDON_VERSION,
            "kodi": xbmc.getInfoLabel("System.BuildVersion").split(" ")[0],
            "system": PLATFORM_NAMES.get(device_platform(), "?"),
            "build": plain("{0} {1}".format(current.get("name", ""), current.get("version", ""))).strip() or "-",
            "task": plain(task), "error": maintenance.scrub_log(str(error))[:1000],
            "time": time.strftime("%Y-%m-%d %H:%M:%S"), "log": maintenance.scrub_log("\n".join(tail))}


def text(report):
    lines = ["{0}: {1}".format(T("Vorgang"), report["task"]), "{0}: {1}".format(T("Fehler"), report["error"]), "",
             "Wizard: {0} {1}".format(report["wizard"], report["version"]),
             "Kodi: {0} · {1}".format(report["kodi"], report["system"]),
             "Build: {0}".format(report["build"]), "{0}: {1}".format(T("Zeit"), report["time"])]
    if report.get("log"):
        lines += ["", "Wizard-Log:", report["log"]]
    return "\n".join(lines)


def _request(cfg, report):
    body = text(report)
    if cfg["kind"] == "ntfy":
        title = "{0} {1}: {2}".format(report["wizard"], report["version"], report["task"])
        return urllib.request.Request(cfg["url"], data=body.encode("utf-8"), method="POST", headers={
            "Title": title[:120].encode("utf-8").decode("latin-1"),     # ntfy liest die Bytes als UTF-8
            "Tags": "warning,skulls-wizard",
            "Content-Type": "text/plain; charset=utf-8", "User-Agent": "{0}/{1}".format(ADDON_ID, ADDON_VERSION)})
    if cfg["kind"] == "discord":
        content = "**{0} {1}** - {2}\n```\n{3}\n```".format(report["wizard"], report["version"], report["task"],
                                                           body[:1800])
        data = json.dumps({"content": content, "username": report["wizard"][:80]}).encode("utf-8")
    else:
        data = json.dumps(dict(report, kind="skulls-wizard-error")).encode("utf-8")
    return urllib.request.Request(cfg["url"], data=data, method="POST", headers={
        "Content-Type": "application/json", "User-Agent": "{0}/{1}".format(ADDON_ID, ADDON_VERSION)})


def send(report, cfg=None, opener=None):
    """True = angekommen"""
    cfg = cfg or settings()
    if not cfg:
        return False
    try:
        from resources.lib import net
        request = _request(cfg, report)
        response = opener(request) if opener else urllib.request.urlopen(request, timeout=15, context=net._context())
        with response:
            ok = 200 <= getattr(response, "status", 200) < 300
    except Exception as e:  # noqa: BLE001 - ohne Verbindung eben kein Bericht
        log_error("Fehlerbericht nicht gesendet: {0}".format(e))
        return False
    if ok:
        _remember(report["task"], report["error"])
        log("Fehlerbericht gesendet: {0}".format(report["task"]))
    return ok


def offer(task, error):
    """Nach einem Fehler: je nach Einstellung fragen, senden oder nichts tun"""
    from resources.lib import dialogs
    if not settings() or mode() == "never" or not allowed(task, error):
        return False
    report = build(task, error)
    if mode() == "always":
        return send(report)
    info = T("Enthält Wizard- und Kodi-Version, System, Build, die Fehlermeldung und die letzten Zeilen des "
             "Wizard-Logs - ohne Passwörter, Tokens und Geräte-Kennung.")
    while True:
        choice = dialogs.select("Fehlerbericht senden?", [
            (T("Senden"), T("Hilft dem Ersteller, den Fehler zu beheben"), info, "check"),
            (T("Bericht ansehen"), T("Genau das wird gesendet"), info, "document"),
            (T("Nicht senden"), "", "", "close"),
            (T("Nie fragen"), T("Änderbar in den Einstellungen"), "", "close")], search=False)
        if choice == 1:
            dialogs.text("Fehlerbericht", text(report).replace("\n", "[CR]"))
            continue
        if choice == 3:
            state = load_state()
            state["report_mode"] = "never"
            save_state(state)
        if choice != 0:
            return False
        ok = send(report)
        dialogs.notify(T("Fehlerbericht gesendet - danke!") if ok else T("Fehlerbericht nicht gesendet (keine Verbindung)"))
        return ok
