# -*- coding: utf-8 -*-
"""
Eigene, skin-unabhängige Dialoge (Fenster aus resources/skins/Default/1080i): Bestätigen, Text, Auswahl,
Fortschritt. Nur die Bildschirmtastatur und der Dateiauswahl-Dialog kommen vom Skin.
"""

import os
import threading
import time

import xbmc
import xbmcgui

from resources.lib import config
from resources.lib.common import ADDON_NAME, ADDON_PATH, unbold
from resources.lib.texts import T

COLORS = config.get("colors") or {}
ICONS = os.path.join(ADDON_PATH, "resources", "skins", "Default", "media", "icons")
# Symbol im Kopf eines Dialogs: aus der Überschrift (deutscher Quelltext) erkannt, sonst je Art
HEADING_ICONS = (("Fehler", "warning"), ("Fresh Start", "recycle"), ("Rückgängig", "backup"),
                 ("Wiederherstell", "backup"), ("Backup", "backup"), ("Save Data", "save"), ("Lösch", "delete"),
                 ("entfernen", "remove"), ("Update", "refresh"), ("Build", "builds"), ("GUI", "gui"),
                 ("Theme", "palette"), ("Log", "document"), ("Addon", "addons"), ("Repositor", "repo"),
                 ("Speed", "speed"), ("Leistung", "speed"), ("Einstellung", "settings"), ("Kontakt", "contact"),
                 ("Wartung", "maint"), ("Aufräum", "clean"), ("Cache", "clean"), ("Datenbank", "database"),
                 ("Netzwerk", "globe"), ("Beenden", "power"), ("PIN", "shield"), ("Passwort", "shield"))

# Symbol je Auswahl-Eintrag: aus dem Text erkannt (Deutsch und Englisch, erste passende Regel gewinnt)
ITEM_ICONS = ((("suchen", "search"), "search"), (("fresh start",), "recycle"),
              (("favorit", "favourite", "favorite"), "star"), (("usb",), "package"),
              (("neu install", "reinstall", "erneut install"), "refresh"),
              (("was ist neu", "what's new", "neuigkeit", "changelog"), "star"),
              (("installier", "install"), "download"), (("herunterlad", "download"), "download"),
              (("inhalt", "content"), "package"), (("bilder", "picture", "galerie", "gallery"), "image"),
              (("video",), "video"), (("abspielen", "play"), "play"),
              (("ältere version", "older version", "vorherige version"), "history"),
              (("geparkt", "parked", "zurückholen", "rückgängig", "undo"), "undo"), (("gui",), "gui"),
              (("theme",), "palette"), (("wiederherstell", "restore"), "backup"),
              (("backup", "sicherung"), "backup"), (("lösch", "delete"), "delete"),
              (("entfern", "remove"), "remove"), (("pin", "passwort", "password"), "lock"),
              (("schlüssel", "zugang", "zugänge", "anmeld", "login", "account", "api"), "key"),
              (("sprache", "language"), "language"), (("repositor",), "repo"), (("log",), "document"),
              (("addon", "add-on"), "addons"),
              (("cache", "aufräum", "clean", "vorschaubild", "thumbnail"), "clean"),
              (("datenbank", "database"), "database"), (("update", "aktualis"), "refresh"),
              (("wartung", "maintenance"), "maint"),
              (("speicher", "storage", "ram", "leistung", "performance", "puffer", "buffer"), "speed"),
              (("bildwiederhol", "refresh rate", "anzeige", "display"), "display"),
              (("netzwerk", "network", "internet"), "globe"),
              (("an (true)", "on (true)", "empfehlung", "recommend"), "check"),
              (("aus (false)", "off (false)", "abbrechen", "cancel"), "close"),
              (("beenden", "quit", "exit", "neustart", "restart"), "power"),
              (("kontakt", "contact", "support", "hilfe", "help"), "contact"),
              (("handy", "phone", "qr"), "qr"), (("öffnen", "open", "browser", "link", "url"), "link"),
              (("einstellung", "setting", "wert", "value"), "settings"))

ACTION_BACK = (9, 10, 92)       # Zurück, Vorheriges Menü, Navigation zurück
SKIN = ("Default", "1080i")
BAR_WIDTH = 1100                # Fortschrittsbalken in sk_progress.xml (Bild 30 auf Bild 31)


def look(heading, default="info", danger=False, icon=None):
    """Kopf eines Dialogs: Symbol (bunt oder eingefärbt), Wizard-Name, Gefahr (rotes Kopfband)"""
    name = icon or ("warning" if danger else next((n for word, n in HEADING_ICONS if word in (heading or "")),
                                                     default))
    colored = (config.get("icons") or {}).get("colored") or []
    return {"icon": os.path.join(ICONS, name + ".png"), "colored": "true" if name in colored and name != "check" else "",
            "brand": ADDON_NAME, "danger": "true" if danger else ""}


def glyph(name):
    """Pfad eines Symbols des Wizards"""
    return os.path.join(ICONS, name + ".png")


def is_colored(name):
    return name in ((config.get("icons") or {}).get("colored") or [])


def item_icon(label):
    """Symbol zu einem Eintrag aus seinem Text, sonst None"""
    low = (label or "").lower()
    return next((name for words, name in ITEM_ICONS if any(w in low for w in words)), None)


def clock(seconds):
    """Dauer als m:ss bzw. h:mm:ss"""
    seconds = int(max(0, seconds))
    h, rest = divmod(seconds, 3600)
    return "{0}:{1:02d}:{2:02d}".format(h, *divmod(rest, 60)) if h else "{0}:{1:02d}".format(*divmod(rest, 60))


class _Base(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.props = kwargs.get("props", {})

    def onInit(self):
        for key, value in self.props.items():
            self.setProperty(key, unbold(value) if key == "heading" else value)    # Überschrift ist schon fett
        # Sprachausgabe (Punkt 173): Überschrift + Text zusammen, damit Kodis Screenreader beim Öffnen die ganze
        # Meldung vorliest (nicht nur den fokussierten Knopf). Ein unsichtbares Label im Skin liest diese Eigenschaft.
        voice = ". ".join(x for x in (self.props.get("heading"), self.props.get("text"),
                                      self.props.get("content")) if x)
        if voice:
            self.setProperty("voice", voice)


class ConfirmDialog(_Base):
    result = False

    def onInit(self):
        super().onInit()
        # gefährliche Aktion: „Nein“ vorauswählen, damit ein versehentliches OK nichts löscht
        self.setFocusId(12 if self.props.get("danger") and not self.props.get("single") else 11)

    def onClick(self, control_id):
        self.result = control_id == 11
        self.close()

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.result = False
            self.close()


def _facts(facts):
    """Info-Chips über dem Text: [(Symbol, Text)] - höchstens vier"""
    props = {}
    for number, (name, value) in enumerate([f for f in (facts or []) if f and f[1]][:4], 1):
        props["fact{0}".format(number)] = T(value)
        props["fact{0}_icon".format(number)] = glyph(name or "info")
    return props


def confirm(heading, text, yes="Ja", no="Nein", danger=False, icon=None, facts=None):
    """Frage mit zwei Knöpfen. facts: Info-Chips [(Symbol, Text)], z.B. Größe und Version eines Builds"""
    props = dict(look(heading, "info", danger, icon), heading=T(heading), text=T(text), yes=T(yes), no=T(no),
                 yes_icon=glyph("delete" if danger else "check"), no_icon=glyph("close"))
    props.update(_facts(facts))
    dialog = ConfirmDialog("sk_confirm.xml", ADDON_PATH, *SKIN, props=props)
    dialog.doModal()
    result = dialog.result
    del dialog
    return result


def ok(heading, text, button="OK", icon=None, facts=None):
    props = dict(look(heading, "info", icon=icon), heading=T(heading), text=T(text), yes=T(button), single="true",
                 yes_icon=glyph("check"))
    props.update(_facts(facts))
    dialog = ConfirmDialog("sk_confirm.xml", ADDON_PATH, *SKIN, props=props)
    dialog.doModal()
    del dialog


def _error_qr_path():
    path = os.path.join(ADDON_PATH, "resources", "skins", "Default", "media", "error_qr.png")
    return path if os.path.isfile(path) else ""


def error(heading, text, button="OK"):
    """Fehlermeldung mit Hilfe: Support-/FAQ-Adresse und QR-Code, falls hinterlegt (Punkt 175)."""
    url = config.get("support_url") or ""
    body = T(text)
    if url:
        body += "[CR][CR]" + T("Hilfe & FAQ: {0}").format(url)
    dialog = ConfirmDialog("sk_confirm.xml", ADDON_PATH, *SKIN,
                           props=dict(look(heading, "warning"), heading=T(heading), text=body,
                                      yes=T(button), single="true", qr=_error_qr_path(), yes_icon=glyph("check")))
    dialog.doModal()
    del dialog


def link(heading, text, qr="", yes=None, icon="globe"):
    """Link-Kachel (Punkt 177): Adresse mit QR-Code (Datei oder Adresse im Netz, z.B. Build-Seite, Punkt 278).
    Mit yes zwei Knöpfe (z.B. „Im Browser öffnen“) - Rückgabe True, wenn gewählt; sonst nur OK."""
    props = dict(look(heading, "info", icon=icon), heading=T(heading), text=text,
                 qr=qr if qr and ("://" in qr or os.path.isfile(qr)) else "")
    if yes:
        props.update(yes=yes, no=T("Schließen"), yes_icon=glyph("link"), no_icon=glyph("close"))
    else:
        props.update(yes=T("OK"), single="true", yes_icon=glyph("check"))
    dialog = ConfirmDialog("sk_confirm.xml", ADDON_PATH, *SKIN, props=props)
    dialog.doModal()
    result = bool(yes) and dialog.result
    del dialog
    return result


class TextDialog(_Base):
    def onInit(self):
        super().onInit()
        self.getControl(20).setText(self.props.get("content", ""))
        self.setFocusId(21)                  # Bildlaufleiste - gibt es nur bei langem Text
        xbmc.sleep(100)
        if self.getFocusId() != 21:
            self.setFocusId(11)

    def onClick(self, control_id):
        if control_id == 11:
            self.close()

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.close()


def text(heading, content):
    dialog = TextDialog("sk_text.xml", ADDON_PATH, *SKIN,
                        props=dict(look(heading, "document"), heading=T(heading), content=content,
                                   close=T("Schließen"), close_icon=glyph("close")))
    dialog.doModal()
    del dialog


SEARCH_FROM = 9      # ab so vielen Einträgen gibt es oben „Suchen …“


class SelectDialog(_Base):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.items = _normalize(kwargs.get("items", []), kwargs.get("fallback", "info"))
        self.multi = kwargs.get("multi", False)
        self.chosen = set(kwargs.get("preselect", []))
        self.result = None
        self.search = kwargs.get("search", len(self.items) >= SEARCH_FROM)
        self.filter = ""
        self.shown = []          # Position in der Liste -> Index in self.items (None = Suchzeile)

    def onInit(self):
        super().onInit()
        self.setProperty("multi", "true" if self.multi else "")
        self.setProperty("hint", T("OK: an-/abhaken   ·   Übernehmen: bestätigen   ·   Zurück: abbrechen") if self.multi
                         else T("OK: auswählen   ·   Zurück: abbrechen"))
        self._fill()
        self._count()
        self.setFocusId(20)

    def _count(self):
        """Zähler im Kopf: Anzahl Einträge bzw. wie viele angehakt sind"""
        total = len(self.items)
        if self.multi:
            self.setProperty("count", T("{0} von {1} ausgewählt").format(len(self.chosen), total))
        else:
            self.setProperty("count", T("{0} Einträge").format(total) if total != 1 else T("1 Eintrag"))

    def _fill(self):
        control = self.getControl(20)
        control.reset()
        self.shown = []
        if self.search:
            item = xbmcgui.ListItem(T("Suchen ..."), self.filter or T("Liste nach einem Wort filtern"))
            item.setProperty("search", "true")
            item.setArt({"icon": glyph("search")})
            control.addItem(item)
            self.shown.append(None)
        needle = self.filter.lower()
        for index, entry in enumerate(self.items):
            if needle and needle not in (entry["label"] + " " + entry["label2"]).lower():
                continue
            item = xbmcgui.ListItem(unbold(entry["label"]), entry["label2"])
            item.setProperty("selected", "true" if index in self.chosen else "")
            if entry["info"]:
                item.setProperty("info", entry["info"])
            if entry["icon"]:
                item.setArt({"icon": glyph(entry["icon"])})
                item.setProperty("colored", "true" if is_colored(entry["icon"]) else "")
            control.addItem(item)
            self.shown.append(index)
        if self.search and len(self.shown) > 1:
            control.selectItem(1)

    def onClick(self, control_id):
        if control_id == 20:
            position = self.getControl(20).getSelectedPosition()
            index = self.shown[position] if 0 <= position < len(self.shown) else None
            if index is None:      # Suchzeile
                text = keyboard("Suchen", self.filter)
                if text is not None:
                    self.filter = text.strip()
                    self._fill()
                self.setFocusId(20)
                return
            if not self.multi:
                self.result = index
                self.close()
                return
            item = self.getControl(20).getSelectedItem()
            if index in self.chosen:
                self.chosen.discard(index)
                item.setProperty("selected", "")
            else:
                self.chosen.add(index)
                item.setProperty("selected", "true")
            self._count()
        elif control_id == 11:
            self.result = sorted(self.chosen)
            self.close()
        elif control_id == 12:
            self.close()

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.close()


def _normalize(items, fallback):
    """Einträge vereinheitlichen: (Text, Zusatz[, Info[, Symbol]]) oder dict(label, label2, info, icon).
    Ohne Symbol: aus dem Text erkannt. Erkennt der Wizard bei weniger als der Hälfte etwas (z.B. eine Liste
    von Addon-Namen), bekommen alle das Symbol des Dialogs - die Liste bleibt einheitlich."""
    rows = []
    for item in items:
        if isinstance(item, dict):
            row = dict(label=item.get("label", ""), label2=item.get("label2", ""), info=item.get("info", ""),
                       icon=item.get("icon"))
        else:
            item = tuple(item) + ("", "", None)
            row = dict(label=item[0] or "", label2=item[1] or "", info=item[2] or "", icon=item[3])
        row["given"] = bool(row["icon"])
        rows.append(row)
    guessed = {id(r): item_icon(r["label"]) for r in rows if not r["given"]}
    uniform = sum(1 for v in guessed.values() if v) * 2 < len(guessed)
    for r in rows:
        if not r["given"]:
            r["icon"] = fallback if uniform else (guessed[id(r)] or fallback)
    return rows


def select(heading, items, multi=False, preselect=(), search=None):
    """items: [(Text, Zusatz[, Info[, Symbol]])] oder dicts -> Index (einfach) bzw. Liste von Indizes (mehrfach),
    None bei Abbruch. Info erscheint unten zum markierten Eintrag. Lange Listen bekommen oben „Suchen …“
    (search=None: automatisch ab SEARCH_FROM Einträgen)."""
    extra = {} if search is None else {"search": search}
    head = look(heading, "toggle")
    fallback = os.path.splitext(os.path.basename(head["icon"]))[0]
    dialog = SelectDialog("sk_select.xml", ADDON_PATH, *SKIN, items=items, multi=multi, preselect=preselect,
                          fallback=fallback,
                          props=dict(head, heading=T(heading), ok=T("Übernehmen"), cancel=T("Abbrechen"),
                                     ok_icon=glyph("check"), cancel_icon=glyph("close")), **extra)
    dialog.doModal()
    result = dialog.result
    del dialog
    return result


class ProgressDialog(_Base):
    """Fortschritt mit Schrittliste. Die Arbeit läuft in einem eigenen Thread, das Fenster bleibt bedienbar."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.steps = []
        self.durations = []          # Dauer der erledigten Schritte (Sekunden)
        self.failed = False
        self.canceled = False
        self.ready = threading.Event()
        self.started = self.step_started = time.time()
        self.log_path = ""           # Installationsprotokoll (Punkt 279) - Knopf 12 „Protokoll“ am Ende

    def onInit(self):
        super().onInit()
        self.setFocusId(11)
        self.ready.set()

    def onClick(self, control_id):
        if control_id == 11:
            if self.getProperty("finished"):
                self.close()
            else:
                self.canceled = True
                self.setProperty("line", T("Wird abgebrochen ..."))
        elif control_id == 12 and self.log_path:
            from resources.lib import installlog
            installlog.show(self.log_path)
            self.setFocusId(11)

    def onAction(self, action):
        if action.getId() in ACTION_BACK and self.getProperty("finished"):
            self.close()

    # ---- vom Arbeits-Thread aufgerufen ----
    def step(self, name):
        now = time.time()
        if self.steps:
            self.durations.append(now - self.step_started)
        self.step_started = now
        self.steps.append(T(name))
        self._render()
        self.update(0, "")

    def _render(self):
        """Schritte als Liste: erledigt (Haken, Dauer), aktuell (hervorgehoben), bei Fehler der letzte rot"""
        finished = bool(self.getProperty("finished"))
        try:
            control = self.getControl(40)
            control.reset()
        except (RuntimeError, TypeError):
            return
        for index, name in enumerate(self.steps):
            last = index == len(self.steps) - 1
            if last and self.failed:
                state, symbol = "failed", "warning"
            elif last and not finished:
                state, symbol = "current", "refresh"
            else:
                state, symbol = "done", "check"
            item = xbmcgui.ListItem(name, clock(self.durations[index]) if index < len(self.durations) else "")
            item.setProperty("state", state)
            item.setArt({"icon": glyph(symbol)})
            control.addItem(item)
        if self.steps:
            control.selectItem(len(self.steps) - 1)
        self.setProperty("stepcount", T("Schritt {0}").format(len(self.steps)) if self.steps else "")

    def update(self, percent, line=""):
        try:
            percent = max(0, min(100, int(percent)))
            self.getControl(30).setWidth(max(16, BAR_WIDTH * percent // 100))     # 16 = runde Enden
            self.setProperty("percent", str(percent) if percent else "")
        except (RuntimeError, TypeError, ValueError):
            pass
        if line is not None:
            self.setProperty("line", line)
        self._stats(percent if isinstance(percent, int) else 0)
        return not self.canceled

    def _stats(self, percent):
        """Zeile unter dem Balken: Schritt, vergangene Zeit, geschätzte Restzeit des Schritts"""
        if self.getProperty("finished"):
            return
        now = time.time()
        parts = [self.getProperty("stepcount"), T("{0} vergangen").format(clock(now - self.started))]
        spent = now - self.step_started
        if 3 <= percent < 100 and spent > 3:
            parts.append(T("noch ca. {0}").format(clock(spent * (100 - percent) / percent)))
        self.setProperty("stats", "   ·   ".join(p for p in parts if p))

    def finish(self, heading, message, failed=False):
        now = time.time()
        if self.steps and len(self.durations) < len(self.steps):
            self.durations.append(now - self.step_started)
        self.failed = failed
        self.setProperty("finished", "true")
        self.setProperty("icon", glyph("warning" if failed else "check"))
        self.setProperty("colored", "")
        self.setProperty("danger", "true" if failed else "")
        self._render()
        message = T(message)
        lines = message.split("\n")
        if len(lines) > 1 or len(message) > 90:
            # Lange Meldungen ins Textfeld (bricht um) statt der Schrittliste - unten nur die letzte Zeile
            done = "[COLOR {0}]{1}[/COLOR]".format(COLORS.get("dim", "FFFFFFFF"), "  ·  ".join(self.steps))
            self.setProperty("message", "[CR]".join(lines[:-1] or lines) + ("[CR][CR]" + done if self.steps else ""))
            message = lines[-1] if len(lines) > 1 else ""
        self.setProperty("heading", unbold(T(heading)))
        self.setProperty("line", message)
        self.setProperty("button", T("OK"))
        self.setProperty("button_icon", glyph("check"))
        if self.log_path:
            self.setProperty("logbutton", T("Protokoll"))
            self.setProperty("logbutton_icon", glyph("document"))
        steps = len(self.steps)
        self.setProperty("stats", "   ·   ".join(x for x in (
            T("Dauer {0}").format(clock(now - self.started)),
            (T("{0} Schritte").format(steps) if steps != 1 else T("1 Schritt")) if steps else "") if x))
        self.update(100, None)


def run(heading, work, done="Fertig", journal=None, report=True):
    """work(progress) läuft im Hintergrund. Rückgabe (Ergebnis, Fehler). Fenster schließt nach OK.
    journal: Titel eines Installationsprotokolls (Punkt 279) - Schritte, Dauer und Meldungen werden gespeichert,
    am Ende zeigt der Knopf „Protokoll“ sie an. report: bei einem Fehler einen Fehlerbericht anbieten (Punkt 298)."""
    props = dict(look(heading, "refresh"), heading=T(heading), button=T("Abbrechen"), button_icon=glyph("close"))
    dialog = ProgressDialog("sk_progress.xml", ADDON_PATH, *SKIN, props=props)
    outcome = {"result": None, "error": None}

    def record(error=None):
        if not journal:
            return
        from resources.lib import common, installlog
        common.capture(None)
        try:
            dialog.log_path = installlog.save(journal, dialog.started, dialog.steps, dialog.durations, messages,
                                              error) or ""
        except Exception as e:  # noqa: BLE001 - das Protokoll darf die Installation nie stören
            common.log_error("Installationsprotokoll: {0}".format(e))

    messages = []

    def worker():
        dialog.ready.wait(10)
        if journal:
            from resources.lib import common
            common.capture(messages)
        try:
            outcome["result"] = work(dialog)
            record()
            if isinstance(outcome["result"], str):
                dialog.finish(done, outcome["result"])
            else:
                dialog.finish(done, "")
        except Exception as e:  # noqa: BLE001
            outcome["error"] = str(e)
            record(str(e))
            dialog.finish("Fehler", str(e), failed=True)
    thread = threading.Thread(target=worker)
    thread.start()
    dialog.doModal()
    user_canceled = dialog.canceled
    dialog.canceled = True
    thread.join(timeout=600)
    if outcome["error"] and report and not user_canceled:
        try:
            from resources.lib import errorreport
            errorreport.offer(heading, outcome["error"])
        except Exception as e:  # noqa: BLE001 - der Bericht darf nie selbst stören
            from resources.lib.common import log_error
            log_error("Fehlerbericht: {0}".format(e))
    return outcome["result"], outcome["error"]


class DeviceDialog(_Base):
    """Leistung & Speicher: Balken für RAM und Speicher, Profil (30), Vorschlagstabelle (40), Knöpfe 51-53"""
    BAR_WIDTH = 735
    BARS = {101: (180, 214), 102: (180, 214), 111: (1005, 214), 113: (1005, 214), 112: (1005, 214)}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.info = kwargs["info"]
        self.current = kwargs["current"]
        self.memory_options = kwargs["memory_options"]
        self.read_options = kwargs["read_options"]
        self.profile = "balanced"
        self.rows = []
        self.off = set()          # abgewählte Zeilen

    def onInit(self):
        from resources.lib import tuning
        super().onInit()
        profiles = self.getControl(30)
        profiles.reset()
        for key, label in tuning.PROFILES:
            item = xbmcgui.ListItem(T(label))
            item.setProperty("key", key)
            profiles.addItem(item)
        profiles.selectItem([k for k, _l in tuning.PROFILES].index(self.profile))
        self._render_disk()
        self._refresh()
        self.setFocusId(30)

    # ---- Anzeige ----
    def _segment(self, control_id, start, width):
        """Abschnitt eines Balkens: start und width als Anteil 0..1"""
        x, y = self.BARS[control_id]
        start = max(0.0, min(1.0, start))
        width = max(0.0, min(1.0 - start, width))
        control = self.getControl(control_id)
        control.setPosition(x + int(self.BAR_WIDTH * start), y)
        control.setWidth(max(1, int(self.BAR_WIDTH * width)))

    def _color(self, key, text):
        return "[COLOR {0}]{1}[/COLOR]".format(COLORS.get(key, "FFFFFFFF"), text)

    def _render_ram(self):
        from resources.lib import tuning
        total, free = self.info.get("ram_total") or 0, self.info.get("ram_free") or 0
        buffer_row = next((r for r in self.rows if r["key"] == "memorysize"), None)
        need = (buffer_row["recommended"] or 0) * tuning.BUFFER_FACTOR if buffer_row else 0
        self.setProperty("ram_value", tuning.gb(total) if total else "?")
        if not total:
            self._segment(101, 0, 0)
            self._segment(102, 0, 0)
            self.setProperty("ram_legend", T("Kodi meldet keinen Arbeitsspeicher"))
            self.setProperty("ram_legend2", "")
            return
        used = max(0, total - free) if free else 0
        self._segment(101, 0, used / float(total))
        self._segment(102, used / float(total), need / float(total))
        self.setProperty("ram_legend", T("Belegt {0}  ·  Frei {1}").format(tuning.gb(used), tuning.gb(free))
                         if free else T("Freier Arbeitsspeicher unbekannt"))
        self.setProperty("ram_legend2", self._color("accent", T("Puffer-Vorschlag braucht etwa {0}").format(
            tuning.gb(need))))

    def _render_disk(self):
        from resources.lib import tuning
        total, free = self.info.get("disk_total") or 0, self.info.get("disk_free") or 0
        clean = self.info.get("cleanable") or 0
        if not total:
            for control_id in (111, 112, 113):
                self._segment(control_id, 0, 0)
            self.setProperty("disk_value", "?")
            self.setProperty("disk_legend", T("Speicherplatz nicht lesbar"))
            return
        used = total - free
        for control_id in (111, 113):
            self._segment(control_id, 0, used / float(total))
        self._segment(112, 0, clean / float(total))
        self.setProperty("disk_low", "true" if free < tuning.LOW_DISK else "")
        self.setProperty("disk_value", T("Frei: {0}").format(tuning.gb(free)))
        self.setProperty("disk_legend", T("Belegt {0}  ·  Gesamt {1}").format(tuning.gb(used), tuning.gb(total)))
        self.setProperty("disk_legend2", self._color("accent2", T("Aufräumbar (Cache, Pakete, Vorschaubilder): {0}")
                                                     .format(tuning.gb(clean))))

    def _refresh(self, position=None):
        from resources.lib import tuning
        self.rows = tuning.recommend(self.info, self.profile, self.current, self.memory_options, self.read_options)
        control = self.getControl(40)
        control.reset()
        for row in self.rows:
            item = xbmcgui.ListItem(row["label"])
            item.setProperty("current", row["text"][0])
            item.setProperty("recommended", row["text"][1] if row["changed"] else T("passt"))
            item.setProperty("changed", "true" if row["changed"] else "")
            item.setProperty("on", "" if row["key"] in self.off else "true")
            control.addItem(item)
        if position is not None:
            control.selectItem(position)
        self.setProperty("has_backup", "true" if tuning.has_backup() else "")
        self._render_ram()
        self._show_reason()

    def _show_reason(self):
        position = self.getControl(40).getSelectedPosition()
        if 0 <= position < len(self.rows):
            self.setProperty("reason", self.rows[position]["reason"])

    # ---- Bedienung ----
    def onAction(self, action):
        action_id = action.getId()
        if action_id in ACTION_BACK:
            self.close()
            return
        focus = self.getFocusId()
        if focus == 30 and action_id in (1, 2):
            key = self.getControl(30).getSelectedItem().getProperty("key")
            if key != self.profile:
                self.profile = key
                self._refresh()
        elif focus == 40 and action_id in (3, 4):
            self._show_reason()

    def onClick(self, control_id):
        from resources.lib import tuning
        if control_id == 30:
            self.setFocusId(40)
        elif control_id == 40:
            position = self.getControl(40).getSelectedPosition()
            row = self.rows[position]
            if row["changed"]:
                self.off.symmetric_difference_update([row["key"]])
                self.getControl(40).getSelectedItem().setProperty("on", "" if row["key"] in self.off else "true")
        elif control_id == 51:
            keys = [r["key"] for r in self.rows if r["changed"] and r["key"] not in self.off]
            if not keys:
                notify("Nichts zu ändern")
                return
            restart = tuning.apply(self.rows, keys)
            self.current = tuning.current_values()
            self._refresh(self.getControl(40).getSelectedPosition())
            ok("Leistung & Speicher", T("{0} Einstellungen übernommen.").format(len(keys)) +
               ("[CR][CR]" + T("Einige Werte gelten erst nach einem Neustart von Kodi.") if restart else ""))
            self.setFocusId(53)
        elif control_id == 52:
            if confirm("Zurücksetzen", "Die Werte von vor dem ersten Übernehmen wiederherstellen?"):
                restart = tuning.restore()
                self.current = tuning.current_values()
                self._refresh()
                if restart:
                    ok("Zurücksetzen", "Einige Werte gelten erst nach einem Neustart von Kodi.")
                self.setFocusId(51)
        elif control_id == 53:
            self.close()


def device():
    """Leistung & Speicher anzeigen - die Abfrage (Ordnergrößen) läuft hinter der Warte-Anzeige"""
    from resources.lib import tuning
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        info = tuning.device_info()
        current = tuning.current_values()
        memory_options = tuning.kodi_options("filecache.memorysize", tuning.MEMORY_OPTIONS)
        read_options = tuning.kodi_options("filecache.readfactor", tuning.READ_OPTIONS)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    device_line = [info.get("platform") or "", "{0}-Bit".format(info.get("bits")),
                   "Kodi {0}".format(info.get("kodi"))]
    dialog = DeviceDialog("sk_device.xml", ADDON_PATH, *SKIN, info=info, current=current,
                          memory_options=memory_options, read_options=read_options,
                          props={"heading": T("Leistung & Speicher"), "device": "  ·  ".join(p for p in device_line if p),
                                 "ram_title": T("Arbeitsspeicher"), "disk_title": T("Speicher"),
                                 "profile_label": T("Profil"), "profile_hint": T("Links/Rechts: Profil wechseln"),
                                 "col_setting": T("Einstellung"), "col_current": T("Aktuell"),
                                 "col_recommended": T("Vorschlag"), "apply": T("Übernehmen"),
                                 "reset": T("Zurücksetzen"), "close": T("Schließen")})
    dialog.doModal()
    del dialog


def notify(message, seconds=5):
    from resources.lib.common import ADDON_NAME
    xbmcgui.Dialog().notification(ADDON_NAME, T(message), xbmcgui.NOTIFICATION_INFO, seconds * 1000)


class GalleryDialog(_Base):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.images = kwargs.get("images", [])
        self.index = 0

    def onInit(self):
        super().onInit()
        self._show()

    def _show(self):
        self.getControl(10).setImage(self.images[self.index], True)
        self.setProperty("counter", "{0} / {1}".format(self.index + 1, len(self.images)))

    def onAction(self, action):
        action_id = action.getId()
        if action_id in ACTION_BACK:
            self.close()
        elif action_id in (1, 3) and len(self.images) > 1:          # links / hoch
            self.index = (self.index - 1) % len(self.images)
            self._show()
        elif action_id in (2, 4, 7) and len(self.images) > 1:       # rechts / runter / OK
            self.index = (self.index + 1) % len(self.images)
            self._show()


def gallery(heading, images):
    """Bildergalerie (Adressen oder Pfade): Links/Rechts blättern, Zurück schließt"""
    if not images:
        return
    dialog = GalleryDialog("sk_gallery.xml", ADDON_PATH, *SKIN, images=list(images),
                           props={"heading": T(heading), "hint": T("Links/Rechts: blättern  ·  Zurück: schließen")})
    dialog.doModal()
    del dialog


def pin(heading="PIN eingeben"):
    """Ziffern-Eingabe (verdeckt) - Fernbedienungs-freundlich. None bei Abbruch"""
    value = xbmcgui.Dialog().numeric(0, T(heading), "", True)
    return value or None


class Splash(xbmcgui.WindowXMLDialog):
    pass


def splash(seconds=0.9):
    """Kurzes Startbild mit Logo (sk_splash.xml)"""
    window = Splash("sk_splash.xml", ADDON_PATH, *SKIN)
    window.show()
    xbmc.sleep(int(seconds * 1000))
    window.close()
    del window


def keyboard(heading, default="", hidden=False):
    kb = xbmc.Keyboard(default, T(heading), hidden)
    kb.doModal()
    return kb.getText() if kb.isConfirmed() else None
