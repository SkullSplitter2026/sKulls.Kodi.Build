# -*- coding: utf-8 -*-
"""
Kodi-Log-Hilfe (Punkt 296): bekannte Fehler im kodi.log erkennen und in Klartext erklären - mit betroffenen Addons,
Häufigkeit und der passenden Abhilfe im Wizard (z.B. „Abhängigkeiten prüfen“, „Pakete löschen“).

Ausgewertet werden nur Zeilen der Stufen error/warning/fatal und die Folgezeilen dazu (Python-Tracebacks).
Die erste passende Regel je Zeile gewinnt - die genaueren stehen daher oben.
"""

import re

from resources.lib.texts import T

STAMP = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}")
LEVEL = re.compile(r"\b(error|warning|fatal)\b", re.I)
ADDON_PATH = re.compile(r"addons[/\\]((?:plugin|script|service|module|repository|pvr|skin|inputstream|resource|"
                        r"metadata|context|screensaver|weather)\.[A-Za-z0-9_.\-]*[A-Za-z0-9])", re.I)
ADDON_ID = re.compile(r"\b((?:plugin|script|service|repository|pvr|skin|inputstream|resource|metadata|context|"
                      r"module|screensaver|weather)\.[A-Za-z0-9_.\-]*[A-Za-z0-9])")
TIME = re.compile(r"^\d{4}-\d{2}-\d{2}[ T](\d{2}:\d{2}:\d{2})")

# Schlüssel, Muster, Titel (de, en), Erklärung (de, en), Abhilfe (Aktion im Wizard, Knopf)
# Aktionen: Wartungs-Schlüssel (ui.maintenance) oder ui:accounts / ui:install:<addon>
RULES = [
    ("debrid", r"(?:real-?debrid|premiumize|alldebrid|torbox|trakt).{0,120}(?:401|expired|invalid.?token|unauthori[sz]ed)",
     ("Debrid- oder Trakt-Anmeldung abgelaufen", "Debrid or Trakt login expired"),
     ("Ein Konto (Real-Debrid, Premiumize, AllDebrid, Trakt) lehnt die Anmeldung ab - meist ist die Freischaltung "
      "abgelaufen oder das Konto wurde neu verknüpft. Unter Save Data > Zugänge das Konto neu verbinden.",
      "An account (Real-Debrid, Premiumize, AllDebrid, Trakt) refuses the login - usually the authorisation expired "
      "or the account was linked elsewhere. Reconnect it under Save Data > Accounts."),
     ("ui:accounts", ("Zugänge öffnen", "Open accounts"))),
    ("module", r"No module named '?([\w.]+)'?|ModuleNotFoundError",
     ("Fehlendes Python-Modul", "Missing Python module"),
     ("Ein Addon braucht ein Modul, das fehlt oder ausgeschaltet ist. „Abhängigkeiten prüfen“ schaltet fehlende "
      "Module ein oder installiert sie aus den Repositories.",
      "An add-on needs a module that is missing or disabled. „Check dependencies“ enables or installs the "
      "missing modules from the repositories."),
     ("addon_deps", ("Abhängigkeiten prüfen", "Check dependencies"))),
    ("dependency", r"(?:dependency|dependencies).{0,80}(?:not (?:found|met|available|satisfied)|missing|failed)"
                   r"|failed to install dependency",
     ("Abhängigkeit nicht erfüllt", "Dependency not met"),
     ("Ein Addon lässt sich nicht starten oder installieren, weil ein anderes Addon fehlt, das es braucht.",
      "An add-on cannot start or install because another add-on it needs is missing."),
     ("addon_deps", ("Abhängigkeiten prüfen", "Check dependencies"))),
    ("crash", r"EXCEPTION Thrown \(PythonToCppException\)|Error Type: <class|Traceback \(most recent call last\)",
     ("Addon abgestürzt", "Add-on crashed"),
     ("Ein Addon hat einen Fehler im eigenen Programmcode. Oft behebt ein Update das; stürzt es weiter ab, helfen "
      "das Löschen seiner Addon-Daten oder eine Meldung an den Entwickler.",
      "An add-on has an error in its own code. An update often fixes it; if it keeps crashing, deleting its add-on "
      "data or reporting it to the developer helps."),
     ("addon_updateall", ("Alle Addons aktualisieren", "Update all add-ons"))),
    ("ssl", r"CERTIFICATE_VERIFY_FAILED|certificate verify failed|SSL certificate problem|SSL routines",
     ("Sichere Verbindung abgelehnt (Zertifikat)", "Secure connection refused (certificate)"),
     ("Die verschlüsselte Verbindung wurde abgelehnt. Häufigster Grund: Datum oder Uhrzeit des Geräts stimmen nicht - "
      "bitte in den Systemeinstellungen auf „automatisch“ stellen. Sonst ist das Zertifikat des Servers abgelaufen.",
      "The encrypted connection was refused. Most common reason: the device's date or time is wrong - set it to "
      "„automatic“ in the system settings. Otherwise the server's certificate has expired."),
     None),
    ("dns", r"resolve host|Name or service not known|getaddrinfo failed|name resolution|Errno -[23]\b|Errno 11001",
     ("Keine Internetverbindung (DNS)", "No internet connection (DNS)"),
     ("Kodi konnte die Adresse eines Servers nicht auflösen - meist fehlt gerade die Internetverbindung oder der "
      "DNS-Server des Routers hakt. WLAN/LAN prüfen, Router neu starten.",
      "Kodi could not resolve a server address - usually the internet connection was down or the router's DNS "
      "failed. Check Wi-Fi/LAN, restart the router."),
     ("tweak_speed", ("Speedtest", "Speed test"))),
    ("timeout", r"Timeout was reached|timed out|Operation too slow|Connection reset by peer",
     ("Server antwortet zu langsam", "Server responds too slowly"),
     ("Ein Server hat nicht rechtzeitig geantwortet. Bei langsamen Verbindungen helfen längere Zeitlimits.",
      "A server did not answer in time. With slow connections longer timeouts help."),
     ("tweak_network", ("Zeitlimits einstellen", "Adjust timeouts"))),
    ("http404", r"\b404\b.{0,40}(?:not found)?|Not Found",
     ("Inhalt nicht gefunden (404)", "Content not found (404)"),
     ("Eine Adresse gibt es nicht mehr - die Quelle wurde entfernt oder ein Repository ist veraltet. Repositories "
      "prüfen zeigt, welche nicht mehr erreichbar sind.",
      "An address no longer exists - the source was removed or a repository is outdated. Checking repositories "
      "shows which are unreachable."),
     ("addon_repos", ("Repositories prüfen", "Check repositories"))),
    ("http403", r"\b40[13]\b|Forbidden|Unauthori[sz]ed",
     ("Zugriff verweigert", "Access denied"),
     ("Ein Dienst verweigert den Zugriff - meist ist ein API-Schlüssel oder eine Anmeldung falsch oder abgelaufen.",
      "A service denies access - usually an API key or login is wrong or expired."),
     ("ui:accounts", ("Zugänge öffnen", "Open accounts"))),
    ("repo", r"CRepositoryUpdateJob|Repository.{0,60}(?:failed|unable)|addons\.xml.{0,60}(?:failed|unable)",
     ("Repository nicht erreichbar", "Repository unreachable"),
     ("Ein Repository liefert keine Addon-Liste - es ist offline, umgezogen oder eingestellt. Seine Addons bekommen "
      "dann keine Updates.",
      "A repository returns no add-on list - it is offline, moved or discontinued. Its add-ons then get no updates."),
     ("addon_repos", ("Repositories prüfen", "Check repositories"))),
    ("disk", r"No space left on device|Disk full|ENOSPC",
     ("Speicher voll", "Storage full"),
     ("Auf dem Gerät ist kein Platz mehr frei - Kodi kann nichts mehr speichern. Aufräumen schafft Platz.",
      "There is no free space left on the device - Kodi cannot save anything. Cleaning up frees space."),
     ("clean_all", ("Alles aufräumen", "Clean up everything"))),
    ("memory", r"Out of memory|Cannot allocate memory|MemoryError|std::bad_alloc",
     ("Arbeitsspeicher reicht nicht", "Not enough memory"),
     ("Dem Gerät ging der Arbeitsspeicher aus. Kleinere Puffer und Bildgrößen entlasten es.",
      "The device ran out of memory. Smaller buffers and image sizes relieve it."),
     ("tweak_device", ("Leistung & Speicher", "Performance & storage"))),
    ("database", r"database disk image is malformed|file is not a database|database is locked|SQL.{0,40}malformed",
     ("Datenbank beschädigt oder gesperrt", "Database damaged or locked"),
     ("Eine Datenbank von Kodi ist beschädigt. Alte bzw. beschädigte Datenbanken löschen - Kodi baut sie neu auf.",
      "One of Kodi's databases is damaged. Delete old or damaged databases - Kodi rebuilds them."),
     ("clean_db", ("Datenbanken", "Databases"))),
    ("package", r"(?:zip|archive|package).{0,60}(?:corrupt|invalid|failed to extract|bad)|CAddonInstallJob.{0,80}"
                r"(?:hash|checksum|failed)",
     ("Defektes Addon-Paket", "Damaged add-on package"),
     ("Ein heruntergeladenes Addon-Paket ist beschädigt. Pakete löschen - beim nächsten Versuch lädt Kodi es neu.",
      "A downloaded add-on package is damaged. Delete packages - Kodi downloads it again on the next try."),
     ("clean_packages", ("Pakete löschen", "Delete packages"))),
    ("inputstream", r"inputstream\.adaptive.{0,80}(?:not found|failed|missing|disabled)|Widevine|\bCDM\b.{0,40}fail",
     ("Wiedergabe-Modul fehlt (InputStream/Widevine)", "Playback module missing (InputStream/Widevine)"),
     ("Für geschützte Streams braucht Kodi InputStream Adaptive (und teils Widevine). Das Addon installieren bzw. "
      "einschalten.",
      "Protected streams need InputStream Adaptive (and partly Widevine). Install or enable the add-on."),
     ("ui:install:inputstream.adaptive", ("InputStream Adaptive installieren", "Install InputStream Adaptive"))),
    ("skin", r"(?:unable to load|failed to load|missing).{0,40}skin|skin.{0,40}not found",
     ("Skin lässt sich nicht laden", "Skin cannot be loaded"),
     ("Der eingestellte Skin fehlt oder ist beschädigt. Auf Estuary zurückschalten, dann den Skin neu installieren.",
      "The selected skin is missing or damaged. Switch back to Estuary, then reinstall the skin."),
     ("misc_skin", ("Skin zurücksetzen", "Reset skin"))),
    ("playback", r"OpenFile - error opening|skipping unplayable|Failed to open stream|CVideoPlayer.{0,60}"
                 r"(?:error|failed)",
     ("Video ließ sich nicht abspielen", "Video could not be played"),
     ("Ein Stream oder eine Datei war nicht erreichbar - die Quelle ist offline oder das Addon veraltet.",
      "A stream or file was not reachable - the source is offline or the add-on is outdated."),
     ("addon_updateall", ("Alle Addons aktualisieren", "Update all add-ons"))),
    ("api", r"xbmc\.python.{0,60}(?:incompatible|version)|is not compatible|requires xbmc\.python",
     ("Addon passt nicht zu dieser Kodi-Version", "Add-on does not fit this Kodi version"),
     ("Ein Addon ist für eine andere Kodi-Version gemacht. Ein Update oder eine passende Version aus dem Repository "
      "behebt das.",
      "An add-on is made for another Kodi version. An update or a matching version from the repository fixes it."),
     ("addon_updateall", ("Alle Addons aktualisieren", "Update all add-ons"))),
    ("share", r"(?:smb|nfs)://.{0,120}(?:failed|error|refused|denied)|CSMBFile|SMBDirectory",
     ("Netzwerkfreigabe nicht erreichbar", "Network share unreachable"),
     ("Eine Freigabe im Heimnetz (SMB/NFS) antwortet nicht - Rechner aus, Passwort geändert oder Quelle veraltet.",
      "A home network share (SMB/NFS) does not answer - computer off, password changed or source outdated."),
     ("misc_sources", ("Quellen prüfen", "Check sources"))),
    ("settings", r"(?:failed to load|invalid).{0,40}settings|CAddonSettings.{0,60}(?:failed|invalid)",
     ("Addon-Einstellungen beschädigt", "Add-on settings damaged"),
     ("Die Einstellungen eines Addons sind beschädigt. Die Addon-Daten dieses Addons löschen - es startet dann mit "
      "Standardwerten.",
      "An add-on's settings are damaged. Delete this add-on's data - it then starts with defaults."),
     ("addon_data", ("Addon-Daten entfernen", "Remove add-on data"))),
]
_COMPILED = [(key, re.compile(pattern, re.I), title, text, action) for key, pattern, title, text, action in RULES]


def _pick(pair):
    from resources.lib import texts
    return pair[0] if texts.GERMAN else pair[1]


def analyze(text):
    """Bekannte Probleme im Log: [{"key", "title", "text", "action", "action_label", "count", "first", "last",
    "addons", "examples", "detail"}], häufigste zuerst"""
    found = {}
    relevant = False
    block = []                      # Funde des aktuellen Fehlers - Traceback-Zeilen ergänzen dort die Addons
    when = ""
    for line in (text or "").splitlines():
        stamped = STAMP.match(line)
        if stamped:
            level = LEVEL.search(line[:80])
            relevant, block = bool(level), []
            message = line[level.end():] if level else line      # ohne Zeitstempel (Millisekunden wie „.404“)
            clock = TIME.match(line)
            when = clock.group(1) if clock else ""
        else:
            message = line
        if not relevant:
            continue
        if not stamped:
            for addon in ADDON_PATH.findall(line):
                for item in block:
                    item["addons"].add(addon)
        for key, pattern, title, explain, action in _COMPILED:
            if key == "crash" and not stamped:
                continue            # „Error Type“/„Traceback“ gehören zum schon gezählten Absturz
            match = pattern.search(message)
            if not match:
                continue
            item = found.get(key)
            if item is None:
                item = found[key] = {"key": key, "title": _pick(title), "text": _pick(explain),
                                     "action": action[0] if action else "", "action_label":
                                     _pick(action[1]) if action else "", "count": 0, "first": "", "last": "",
                                     "addons": set(), "examples": [], "detail": set()}
            if item not in block:       # ein Fehler mit mehreren passenden Zeilen zählt einmal
                item["count"] += 1
            if when:
                item["first"] = item["first"] or when
                item["last"] = when
            for addon in ADDON_PATH.findall(message) + ADDON_ID.findall(message):
                item["addons"].add(addon.rstrip("."))
            if key == "module" and match.groups() and match.group(1):
                item["detail"].add(match.group(1))
            if len(item["examples"]) < 3 and line.strip() not in item["examples"]:
                item["examples"].append(line.strip())
            if item not in block:
                block.append(item)
            break
    result = sorted(found.values(), key=lambda i: -i["count"])
    for item in result:
        item["addons"] = sorted(a for a in item["addons"] if not a.startswith("xbmc."))
        item["detail"] = sorted(item["detail"])
    return result


def summary(item):
    """Zweite Zeile: Häufigkeit, betroffene Addons, Zeit"""
    parts = [T("{0}×").format(item["count"])]
    names = item["detail"] or item["addons"]
    if names:
        parts.append(", ".join(names[:3]) + (" …" if len(names) > 3 else ""))
    if item["last"]:
        parts.append(T("zuletzt {0}").format(item["last"]))
    return "  ·  ".join(parts)


def explanation(item, scrub=None):
    """Text für den Dialog: Erklärung, Betroffene, Beispielzeilen aus dem Log"""
    lines = [item["text"]]
    if item["detail"]:
        lines += ["", T("Fehlt: {0}").format(", ".join(item["detail"]))]
    if item["addons"]:
        lines += ["", T("Betroffen: {0}").format(", ".join(item["addons"][:8]))]
    examples = [e if len(e) <= 220 else e[:217] + "..." for e in item["examples"][:2]]
    if scrub:
        examples = [scrub(e) for e in examples]
    if examples:
        lines += ["", T("Im Log ({0}×, zuletzt {1}):").format(item["count"], item["last"] or "?")]
        lines += ["[COLOR grey]{0}[/COLOR]".format(e.replace("[", "(").replace("]", ")")) for e in examples]
    return "[CR]".join(lines)
