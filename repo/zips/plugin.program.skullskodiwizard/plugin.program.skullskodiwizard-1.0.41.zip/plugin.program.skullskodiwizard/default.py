# -*- coding: utf-8 -*-
"""Startet die Wizard-Zentrale (eigenes Vollbild-Fenster, unabhängig vom Skin). „view=builds“ öffnet eine Seite
direkt (z.B. aus dem Widget, Punkt 285)."""
import sys

from resources.lib import ui

try:
    ui.open_main(next((a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("view=")), None))
except Exception as error:  # noqa: BLE001 - unerwarteter Fehler: protokollieren, Fehlerbericht anbieten (Punkt 298)
    import traceback
    from resources.lib import errorreport
    from resources.lib.common import log_error
    log_error("Wizard: {0}\n{1}".format(error, traceback.format_exc()))
    errorreport.offer("Wizard", "{0}: {1}".format(type(error).__name__, error))
