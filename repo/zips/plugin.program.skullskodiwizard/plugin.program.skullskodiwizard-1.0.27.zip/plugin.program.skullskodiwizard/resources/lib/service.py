# -*- coding: utf-8 -*-
"""
Hintergrund-Dienst (startet mit Kodi):
  - nach einer Build-Installation die Addons des Builds einschalten
  - Repository aus dem Wizard installieren (falls so eingestellt)
  - erster Start: ist schon ein Build aus der Liste installiert? Sonst anbieten, einen zu installieren
  - Build-/Wizard-Updates und Benachrichtigungen laut Intervall, automatische Wartung laut Intervall
"""

import os
import time
import zipfile

import xbmc

from resources.lib import builds, config, dialogs, maintenance
from resources.lib.common import (ADDON_ID, ADDON_PATH, ADDON_VERSION, ADDONS, interval_due, jsonrpc, load_state, log,
                                  log_error, save_state, version_key)
from resources.lib.texts import T


def wait_for_home(monitor, seconds=60):
    """Warten, bis Kodi fertig gestartet ist (Startbildschirm / Profilwahl vorbei)"""
    for _ in range(seconds * 2):
        if monitor.abortRequested():
            return False
        if xbmc.getCondVisibility("Window.IsActive(home)") and not xbmc.getCondVisibility("System.HasModalDialog"):
            return True
        monitor.waitForAbort(0.5)
    return True


def install_embedded_repo():
    """Das Repository liegt als geprüfte ZIP im Wizard - kein Download nötig"""
    repo = config.get("repo") or {}
    repo_id, zip_name = repo.get("id"), repo.get("zip")
    if not repo.get("auto_install") or not repo_id or not zip_name:
        return False
    if os.path.isdir(os.path.join(ADDONS, repo_id)):
        return False
    path = os.path.join(ADDON_PATH, "resources", "repo", zip_name)
    if not os.path.isfile(path):
        return False
    with zipfile.ZipFile(path) as z:
        for member in z.infolist():
            name = member.filename.replace("\\", "/")
            if member.is_dir() or not name.startswith(repo_id + "/") or ".." in name.split("/"):
                continue
            target = os.path.join(ADDONS, *name.split("/"))
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(member) as src, open(target, "wb") as dst:
                dst.write(src.read())
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(2000)
    jsonrpc("Addons.SetAddonEnabled", {"addonid": repo_id, "enabled": True})
    log("Repository installiert: {0}".format(repo_id))
    return True


def setup_assistant():
    """Einrichtungsassistent (erster Start, auch über die Einstellungen): Sprache, Wartung, Save Data, Backup"""
    from resources.lib import ui as wizard_ui
    state = load_state()
    language = xbmc.getInfoLabel("System.Language") or "?"
    step = dialogs.select(T("Einrichtung 1/4: Sprache - der Wizard folgt Kodi ({0})").format(language),
                          [(T("Weiter"), ""), (T("Kodi-Sprache ändern ..."), T("öffnet Kodis Einstellungen danach"))],
                          search=False)
    if step is None:
        return False
    change_language = step == 1
    options = [("weekly", T("Wöchentlich (empfohlen)")), ("monthly", T("Monatlich")), ("start", T("Bei jedem Start")),
               ("never", T("Nie"))]
    current = state.get("maint_interval")
    step = dialogs.select("Einrichtung 2/4: Automatische Wartung (Cache und alte Pakete)",
                          [(label, T("aktuell") if key == current else "") for key, label in options], search=False)
    if step is None:
        return False
    state["maint_interval"] = options[step][0]
    keys = [k for k, _l in wizard_ui.SAVE_TEXT]
    chosen = dialogs.select("Einrichtung 3/4: Das bleibt bei Build-Installationen",
                            [(T(label), "") for _k, label in wizard_ui.SAVE_TEXT], multi=True, search=False,
                            preselect=[i for i, k in enumerate(keys) if state["savedata"].get(k)])
    if chosen is None:
        return False
    state["savedata"] = {k: (i in chosen) for i, k in enumerate(keys)}
    options = [("default", T("Speicherort lassen"), state.get("backup_folder") or T("Wizard-Ordner")),
               ("folder", T("Anderer Ordner ..."), T("z.B. USB-Stick oder Netzwerk")),
               ("weekly", T("Jede Woche automatisch sichern"), T("Addons mit ihren Daten"))]
    step = dialogs.select("Einrichtung 4/4: Backups", [(label, extra) for _k, label, extra in options], search=False)
    if step is None:
        return False
    if options[step][0] == "folder":
        import xbmcgui
        path = xbmcgui.Dialog().browse(3, T("Speicherort für Backups"), "files")
        if path:
            state["backup_folder"] = path
    elif options[step][0] == "weekly":
        state["autobackup_interval"] = "weekly"
        state["last_autobackup"] = time.time()
    state["setup_done"] = True
    save_state(state)
    log("Einrichtungsassistent abgeschlossen")
    if change_language:
        xbmc.executebuiltin("ActivateWindow(interfacesettings)")
    return True


def first_run():
    state = load_state()
    if state.get("first_run_done"):
        return
    state["first_run_done"] = True
    save_state(state)
    if not state.get("setup_done"):
        try:
            setup_assistant()
        except Exception as e:  # noqa: BLE001
            log_error("Einrichtungsassistent: {0}".format(e))
    if not state.get("tour_done"):          # kurze geführte Tour beim ersten Start (Punkt 174)
        try:
            tour()
        except Exception as e:  # noqa: BLE001
            log_error("Tour: {0}".format(e))
        state = load_state()
        state["tour_done"] = True
        save_state(state)
    try:
        current = builds.detect_installed()
    except Exception as e:  # noqa: BLE001
        log_error("Erster Start - Build-Liste nicht erreichbar: {0}".format(e))
        return
    if current:
        log("Erster Start: Build {0} ist installiert".format(current.get("name")))
        return
    if dialogs.confirm("Willkommen", "Es ist noch kein Build aus der Liste installiert. Möchtest du jetzt einen "
                                     "Build auswählen und installieren?", yes="Builds anzeigen", no="Später"):
        xbmc.executebuiltin("RunAddon({0})".format(ADDON_ID))


def tour(force=False):
    """Kurze geführte Tour (Punkt 174): Builds, Wartung, Backup, Zugänge. force=True: ohne Rückfrage (aus der Hilfe)."""
    if not force and not dialogs.confirm(T("Kurze Tour"), T("Möchtest du eine kurze Tour durch die wichtigsten "
                                                            "Bereiche? (Später jederzeit unter „Kontakt“.)"),
                                         yes=T("Los"), no=T("Überspringen")):
        return
    slides = [
        (T("Builds"), T("Unter „Builds“ installierst du eine fertige Einrichtung (Addons und Einstellungen) - online "
                        "aus der Liste oder als Datei von USB oder aus dem Netzwerk.")),
        (T("Wartung"), T("„Wartung“ räumt auf: Zwischenspeicher und Vorschaubilder leeren, Pakete löschen, Log "
                         "ansehen - ohne deine Einstellungen zu verlieren.")),
        (T("Backup/Restore"), T("Unter „Backup/Restore“ sicherst du deine Einrichtung auf USB oder ins Netzwerk und "
                                "spielst sie jederzeit wieder ein.")),
        (T("Zugänge & API-Schlüssel"), T("Unter „Save Data“ trägst du Logins und Schlüssel (TMDb, Real-Debrid …) "
                                         "einmal ein - der Wizard setzt sie in alle passenden Addons.")),
    ]
    for title, text in slides:
        dialogs.ok(title, text)


def _may_notify():
    """Automatische Hinweise nur, wenn erlaubt und gerade nichts läuft (Punkt 180: Ruhe bei Wiedergabe)."""
    try:
        if xbmc.Player().isPlaying():
            return False
    except Exception:  # noqa: BLE001
        pass
    return load_state().get("notifications", True)


def check_updates(interactive=False):
    """Build-Update, Wizard-Update, Benachrichtigung. Rückgabe: True, wenn etwas angeboten wurde -
    aus dem offenen Wizard (interactive) "builds", wenn die Build-Seite gezeigt werden soll."""
    state = load_state()
    state["last_update_check"] = time.time()
    save_state(state)
    try:
        data = builds.load_list(refresh=True)
    except Exception as e:  # noqa: BLE001
        log_error("Update-Prüfung: {0}".format(e))
        if interactive:
            dialogs.error("Updates", T("Build-Liste nicht erreichbar: {0}").format(e))   # mit QR-Hilfe (Punkt 175)
        return interactive
    offered = False
    updates = {}
    wizard = data.get("wizard") or {}
    if wizard.get("version") and version_key(wizard["version"]) > version_key(ADDON_VERSION):
        offered = True
        updates["wizard"] = wizard["version"]
        msg = T("Neue Wizard-Version {0} verfügbar (installiert: {1}). Jetzt aktualisieren?").format(
            wizard["version"], ADDON_VERSION)
        changes = (wizard.get("news") or wizard.get("changelog") or "").strip()   # Was ist neu (Punkt 179)
        if changes:
            msg += "[CR][CR]" + T("Was ist neu:") + "[CR]" + changes
        if dialogs.confirm("Wizard-Update", msg, yes="Aktualisieren", no="Später"):
            _r, error = dialogs.run("Wizard-Update", lambda ui: builds.install_wizard_update(wizard, ui) or
                                    "Der Wizard wurde aktualisiert.")
            if not error:
                xbmc.executebuiltin("UpdateLocalAddons")
                updates.pop("wizard", None)
    repo = data.get("repo") or {}
    if repo.get("id") and repo.get("version") and repo.get("sha256"):
        have = builds.addon_version(repo["id"])
        if have is None or version_key(repo["version"]) > version_key(have):
            offered = True
            updates["repo"] = repo["version"]
            text = T("Neue Version {0} des Repositorys {1} verfügbar (installiert: {2}). Jetzt installieren?").format(
                repo["version"], repo["id"], have) if have is not None else T(
                "Das Repository {0} ist nicht installiert - ohne es bekommen die Addons keine Updates. Jetzt "
                "installieren?").format(repo["id"])
            if dialogs.confirm("Repository-Update", text, yes="Installieren", no="Später"):
                _r, error = dialogs.run("Repository-Update", lambda ui: builds.install_repo_update(repo, ui) or
                                        "Das Repository ist auf dem neuesten Stand.")
                if not error:
                    updates.pop("repo", None)
    newer = builds.update_available()
    if newer:
        offered = True
        updates["build"] = newer.get("version")
        current = builds.installed()
        if dialogs.confirm("Build-Update", T("Für {0} gibt es Version {1} (installiert: {2}). Jetzt ansehen?").format(
                newer.get("name"), newer.get("version"), current.get("version")), yes="Jetzt ansehen", no="Später"):
            if interactive:
                return "builds"      # Wizard ist schon offen - kein zweites Fenster
            xbmc.executebuiltin("RunAddon({0})".format(ADDON_ID))
    state = load_state()
    state["updates"] = updates
    save_state(state)
    if updates and not interactive and _may_notify():
        dialogs.notify(T("Update verfügbar: {0}").format(update_text(updates)), seconds=8)
    notify = data.get("notify") or {}
    if notify.get("id") and (interactive or _may_notify()) and int(notify["id"]) > int(state.get("notify_seen", 0)):
        offered = True
        dialogs.text(notify.get("title") or "Neuigkeiten", notify.get("text", ""))
        state = load_state()
        state["notify_seen"] = int(notify["id"])
        save_state(state)
    return offered


def update_text(updates):
    """{"wizard": "1.0.6", "repo": ...} -> „Wizard 1.0.6, Repository 1.3.0“"""
    names = (("wizard", "Wizard"), ("repo", "Repository"), ("build", "Build"))
    return ", ".join("{0} {1}".format(T(label), updates[key]) for key, label in names if updates.get(key))


def run():
    monitor = xbmc.Monitor()
    log("Dienst gestartet ({0})".format(ADDON_VERSION))
    state = load_state()
    if state.get("enable_all_pending"):
        xbmc.sleep(3000)
        builds.enable_all_addons()
        state = load_state()
        state["enable_all_pending"] = False
        save_state(state)
    builds.finish_after_exit()
    builds.cleanup_leftovers()
    try:
        from resources.lib import rss
        rss.apply()
    except Exception as e:  # noqa: BLE001
        log_error("RSS-Laufschrift: {0}".format(e))
    try:
        maintenance.restore_update_mode(force=True)    # Kodi wurde vor Ablauf neu gestartet
    except Exception as e:  # noqa: BLE001
        log_error("Update-Einstellung: {0}".format(e))
    try:
        install_embedded_repo()
    except Exception as e:  # noqa: BLE001
        log_error("Repository: {0}".format(e))
    if not wait_for_home(monitor):
        return
    first_run()
    try:
        if load_state().get("binaries_pending"):
            if not monitor.waitForAbort(10):         # Repositories nach dem Start kurz aktualisieren lassen
                builds.install_pending_binaries(monitor)
    except Exception as e:  # noqa: BLE001
        log_error("Binär-Addons: {0}".format(e))
    try:
        from resources.lib import selfcheck
        bad = selfcheck.run()
        if bad and _may_notify():
            dialogs.notify(T("Selbstprüfung: {0} Wizard-Datei(en) beschädigt - Einstellungen > Wizard reparieren").format(
                len(bad)), seconds=10)
    except Exception as e:  # noqa: BLE001
        log_error("Selbstprüfung: {0}".format(e))
    started = True
    last_tasks = 0
    while not monitor.abortRequested():
        try:
            if maintenance.restore_update_mode():
                result = maintenance.update_result()
                if result and _may_notify():
                    dialogs.notify(T("Alle Addons aktualisieren: {0} aktualisiert, {1} fehlgeschlagen").format(
                        len(result[0]), len(result[2])), seconds=10)
        except Exception as e:  # noqa: BLE001
            log_error("Update-Einstellung: {0}".format(e))
        if not started and time.time() - last_tasks < 3600:
            if monitor.waitForAbort(60):
                break
            continue
        last_tasks = time.time()
        state = load_state()
        try:
            if (started and state.get("update_interval") == "start") or \
                    interval_due(state, "update_interval", "last_update_check"):
                if state.get("update_interval") != "never":
                    check_updates()
            if not xbmc.Player().isPlaying() and ((started and state.get("autobackup_interval") == "start") or
                                                  interval_due(state, "autobackup_interval", "last_autobackup")):
                if state.get("autobackup_interval") != "never":
                    try:
                        from resources.lib import backup
                        path = backup.auto_backup()
                        if state.get("notifications", True):
                            dialogs.notify(T("Automatisches Backup erstellt: {0}").format(os.path.basename(path)))
                    except Exception as e:  # noqa: BLE001 - Wartung trotzdem ausführen
                        log_error("Automatisches Backup: {0}".format(e))
            if (started and state.get("maint_interval") == "start") or \
                    interval_due(state, "maint_interval", "last_maintenance"):
                if state.get("maint_interval") != "never":
                    freed = maintenance.auto_maintenance()
                    if freed > 1024 * 1024 and _may_notify():
                        from resources.lib.common import human_size
                        dialogs.notify(T("Wartung: {0} frei").format(human_size(freed)))
        except Exception as e:  # noqa: BLE001
            log_error("Dienst: {0}".format(e))
        started = False
        if monitor.waitForAbort(60):
            break
    log("Dienst beendet")
