# -*- coding: utf-8 -*-
"""
Zugänge & API-Schlüssel: einmal eingeben, in alle passenden Addons eintragen.

1. Schlüssel und Logins (TMDb, fanart.tv, OMDb/IMDb, TVDB, Premiumize, AllDebrid, TorBox, Debrid-Link, OpenSubtitles,
   Easynews): der Nutzer gibt den Wert ein (oder übernimmt ihn aus einem Addon, das ihn schon hat). Gesucht wird in
   den settings.xml aller installierten Addons nach Einstellungen, deren ID zum Dienst und zur Art passt (z.B.
   „tmdb_api_key“, „fanart.tv.api“). Vor dem Schreiben sieht der Nutzer jede Fundstelle und kann abwählen.
2. Anmeldungen mit Kontoverknüpfung (Real-Debrid, Premiumize, AllDebrid, TorBox, Trakt …): ein Addon, das schon
   angemeldet ist, gibt seine Werte an alle Addons weiter, die GENAU dieselben Einstellungs-IDs haben (gleiche
   Addon-Familie, z.B. ResolveURL-Ableger) - so passt alles zusammen (Token, Refresh-Token, Client-ID).
Geschrieben wird über Kodi (xbmcaddon.Addon(id).setSetting) - Kodi hält die Einstellungen sonst im Speicher und
würde eine direkt geänderte Datei überschreiben. Gespeicherte Werte liegen nur auf diesem Gerät (accounts.json).
"""

import json
import os
import re
import xml.etree.ElementTree as ET

from resources.lib.common import ADDON_DATA, ADDON_ID, ADDONS, DATA, log

STORE = os.path.join(DATA, "accounts.json")
SKIP_TYPES = {"action", "lsep", "sep", "label", "bool", "boolean", "enum", "select", "labelenum", "slider",
              "number", "integer", "folder", "file", "fileenum", "date", "time", "ipaddress"}
# keine Werte, sondern Schalter, Adressen o.ä. - nie überschreiben
EXCLUDE = re.compile(r"enable|enabled|^use_|_use$|show|lang|priority|timeout|expir|limit|sort|url|host|port|"
                     r"version|cache|last|auto|mode|order|count|interval|quality|debug|test|help|info$")
KEY_FIELD = re.compile(r"(api_?key|apikey|api|_key$|^key$|token|pin)$|api_?key|apikey")
USER_FIELD = re.compile(r"(user|username|login|email|account)$")
PASS_FIELD = re.compile(r"(pass|password|passwd|pwd)$")

# key: interner Name, name: Anzeige, match: Dienst in der Einstellungs-ID, fields: was eingegeben wird
SERVICES = [
    {"key": "tmdb", "name": "TMDb (The Movie Database)", "match": r"tmdb|themoviedb|moviedb",
     "fields": {"key": "API-Schlüssel (v3)"}},
    {"key": "fanarttv", "name": "fanart.tv", "match": r"fanart_?tv|fanarttv|fanart",
     "fields": {"key": "Persönlicher API-Schlüssel"}},
    {"key": "omdb", "name": "OMDb (IMDb-Bewertungen)", "match": r"omdb|imdb", "fields": {"key": "API-Schlüssel"}},
    {"key": "tvdb", "name": "TheTVDB", "match": r"tvdb", "fields": {"key": "API-Schlüssel / PIN"}},
    {"key": "premiumize", "name": "Premiumize", "match": r"premiumize|(^|_)pm(_|$)", "fields": {"key": "API-Schlüssel"}},
    {"key": "alldebrid", "name": "AllDebrid", "match": r"alldebrid|all_debrid|(^|_)ad(_|$)",
     "fields": {"key": "API-Schlüssel"}},
    {"key": "torbox", "name": "TorBox", "match": r"torbox|(^|_)tb(_|$)", "fields": {"key": "API-Schlüssel"}},
    {"key": "debridlink", "name": "Debrid-Link", "match": r"debrid_?link|debridlink|(^|_)dl(_|$)",
     "fields": {"key": "API-Schlüssel"}},
    {"key": "opensubtitles", "name": "OpenSubtitles", "match": r"opensubtitles|opensubs|(^|_)os(_|$)",
     "fields": {"user": "Benutzername", "password": "Passwort"}},
    {"key": "easynews", "name": "Easynews", "match": r"easynews|(^|_)en(_|$)",
     "fields": {"user": "Benutzername", "password": "Passwort"}},
    # Weitere Dienste (Punkt 187)
    {"key": "mdblist", "name": "MDBList", "match": r"mdblist", "fields": {"key": "API-Schlüssel"}},
    {"key": "simkl", "name": "Simkl", "match": r"simkl", "fields": {"key": "API-Schlüssel"}},
    {"key": "anilist", "name": "AniList", "match": r"anilist", "fields": {"key": "Token"}},
    {"key": "opensubtitlescom", "name": "OpenSubtitles.com (API)", "match": r"opensubtitles_?com|ostcom",
     "fields": {"user": "Benutzername", "key": "API-Schlüssel"}},
    {"key": "plex", "name": "Plex", "match": r"(^|_)plex",
     "fields": {"user": "Benutzername", "password": "Passwort"}},
    {"key": "jellyfin", "name": "Jellyfin / Emby", "match": r"jellyfin|emby",
     "fields": {"user": "Benutzername", "password": "Passwort"}},
]
# Anmeldungen, die zwischen gleichartigen Addons kopiert werden (Token + Refresh + Client-ID gehören zusammen)
SYNC = [
    {"key": "realdebrid", "name": "Real-Debrid", "match": r"realdebrid|real_debrid|(^|_)rd(_|$)"},
    {"key": "premiumize", "name": "Premiumize", "match": r"premiumize|(^|_)pm(_|$)"},
    {"key": "alldebrid", "name": "AllDebrid", "match": r"alldebrid|all_debrid|(^|_)ad(_|$)"},
    {"key": "torbox", "name": "TorBox", "match": r"torbox|(^|_)tb(_|$)"},
    {"key": "debridlink", "name": "Debrid-Link", "match": r"debrid_?link|debridlink"},
    {"key": "trakt", "name": "Trakt", "match": r"trakt"},
    {"key": "easynews", "name": "Easynews", "match": r"easynews"},
]
FIELD_RE = {"key": KEY_FIELD, "user": USER_FIELD, "password": PASS_FIELD}


def norm(setting_id):
    """„RealDebridResolver.token“ -> „realdebridresolver_token“"""
    return re.sub(r"[^a-z0-9]+", "_", (setting_id or "").lower()).strip("_")


def service(key, table=None):
    return next((s for s in (table or SERVICES) if s["key"] == key), None)


def service_name(key):
    """Anzeigename eines Dienstes/Zugangs anhand seines Schlüssels (Punkt 188) – unbekannte bleiben stehen."""
    found = service(key) or service(key, SYNC)
    return found["name"] if found else key


# ---------------- gespeicherte Werte (nur dieses Gerät) ----------------
def load():
    try:
        with open(STORE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save(data):
    os.makedirs(os.path.dirname(STORE), exist_ok=True)
    tmp = STORE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)
    os.replace(tmp, STORE)


def mask(value):
    value = value or ""
    return value[:3] + "…" + value[-3:] if len(value) > 8 else "•" * len(value)


# ---------------- Addons und ihre Einstellungen ----------------
def installed_addons(root=None):
    """[(Addon-ID, Ordner)] aller Addons mit Einstellungen - außer dem Wizard selbst"""
    root = root or ADDONS
    result = []
    for name in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        folder = os.path.join(root, name)
        if name != ADDON_ID and os.path.isfile(os.path.join(folder, "resources", "settings.xml")):
            result.append((name, folder))
    return result


def setting_ids(folder):
    """Text-Einstellungen eines Addons (alte und neue settings.xml-Form) - Schalter, Listen usw. fallen weg"""
    try:
        root = ET.parse(os.path.join(folder, "resources", "settings.xml")).getroot()
    except (OSError, ET.ParseError):
        return []
    ids = []
    for elem in root.iter("setting"):
        sid = elem.get("id")
        kind = (elem.get("type") or "text").lower()
        if sid and kind not in SKIP_TYPES and sid not in ids:
            ids.append(sid)
    return ids


def current_values(addon_id, data_root=None):
    """Gespeicherte Einstellungen eines Addons (userdata/addon_data/<id>/settings.xml, beide Formen)"""
    path = os.path.join(data_root or ADDON_DATA, addon_id, "settings.xml")
    try:
        root = ET.parse(path).getroot()
    except (OSError, ET.ParseError):
        return {}
    values = {}
    for elem in root.iter("setting"):
        sid = elem.get("id")
        if sid:
            values[sid] = elem.get("value") if elem.get("value") is not None else (elem.text or "")
    return values


def matches(svc, setting_id, field, addon_id=""):
    """Passt die Einstellung zum Dienst? Der Dienst steht in der Einstellungs-ID oder im Addon selbst (z.B.
    service.subtitles.opensubtitles mit „OSuser“)"""
    sid = norm(setting_id)
    if EXCLUDE.search(sid) or not (re.search(svc["match"], sid) or re.search(svc["match"], norm(addon_id))):
        return False
    if field == "key":
        return bool(KEY_FIELD.search(sid)) and not USER_FIELD.search(sid) and not PASS_FIELD.search(sid)
    return bool(FIELD_RE[field].search(sid))


def plan(service_key, fields=None, addons=None):
    """Fundstellen für einen Dienst: [(Addon-ID, Einstellungs-ID, Feld)]"""
    svc = service(service_key)
    result = []
    for addon_id, folder in addons if addons is not None else installed_addons():
        for sid in setting_ids(folder):
            for field in fields or svc["fields"]:
                if matches(svc, sid, field, addon_id):
                    result.append((addon_id, sid, field))
                    break
    return result


def found_values(service_key, addons=None, data_root=None):
    """Schon eingetragene Werte (zum Übernehmen): [(Addon-ID, Feld, Wert)] - je Feld und Wert einmal"""
    seen, result = set(), []
    for addon_id, sid, field in plan(service_key, addons=addons):
        value = (current_values(addon_id, data_root).get(sid) or "").strip()
        if value and (field, value) not in seen:
            seen.add((field, value))
            result.append((addon_id, field, value))
    return result


def _kodi_setter(addon_id, setting_id, value):
    import xbmcaddon
    xbmcaddon.Addon(addon_id).setSetting(setting_id, value)


def apply(entries, values, setter=None):
    """entries: [(Addon-ID, Einstellungs-ID, Feld)], values: Feld -> Wert. Rückgabe: (geschrieben, Fehler)"""
    setter = setter or _kodi_setter
    done, errors = 0, []
    for addon_id, sid, field in entries:
        value = values.get(field, "")
        if not value:
            continue
        try:
            setter(addon_id, sid, value)
            done += 1
        except Exception as e:  # noqa: BLE001 - z.B. ausgeschaltetes Addon
            errors.append("{0}: {1}".format(addon_id, e))
    log("Zugänge eingetragen: {0} Einstellung(en), {1} Fehler".format(done, len(errors)))
    return done, errors


# ---------------- Anmeldung von einem Addon auf gleichartige kopieren ----------------
def sync_ids(sync_key, folder):
    svc = service(sync_key, SYNC)
    return [sid for sid in setting_ids(folder) if re.search(svc["match"], norm(sid))
            and not re.search(r"enable|enabled|priority|order", norm(sid))]


def sync_sources(sync_key, addons=None, data_root=None):
    """Addons, die beim Dienst angemeldet sind: [(Addon-ID, Anzahl Werte)]"""
    result = []
    for addon_id, folder in addons if addons is not None else installed_addons():
        values = current_values(addon_id, data_root)
        filled = [sid for sid in sync_ids(sync_key, folder) if (values.get(sid) or "").strip()]
        if filled:
            result.append((addon_id, len(filled)))
    return result


def sync_plan(sync_key, source_id, addons=None, data_root=None):
    """Was kopiert wird: [(Ziel-Addon, Einstellungs-ID, Wert)] - nur Ziele mit genau denselben IDs"""
    addons = addons if addons is not None else installed_addons()
    folders = dict(addons)
    source_values = current_values(source_id, data_root)
    wanted = {sid: source_values[sid] for sid in sync_ids(sync_key, folders[source_id])
              if (source_values.get(sid) or "").strip()}
    result = []
    for addon_id, folder in addons:
        if addon_id == source_id:
            continue
        ids = set(setting_ids(folder))
        if wanted and set(wanted) <= ids:          # dieselbe Familie: alle Felder vorhanden
            result += [(addon_id, sid, value) for sid, value in sorted(wanted.items())]
    return result


def apply_sync(entries, setter=None):
    return apply([(a, s, s) for a, s, _v in entries], {s: v for _a, s, v in entries}, setter)
