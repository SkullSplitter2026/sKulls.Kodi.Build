# -*- coding: utf-8 -*-
"""
Einstellungen des Wizards, die der sKulls Forge beim Bauen in resources/wizard.json einträgt
(Server, Repository, Addons, Farben, Kontakt).
"""

import json
import os

from resources.lib.common import ADDON_PATH, log_error


def load():
    try:
        with open(os.path.join(ADDON_PATH, "resources", "wizard.json"), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:  # noqa: BLE001
        log_error("Wizard-Konfiguration nicht lesbar: {0}".format(e))
        return {}


CONFIG = load()


def get(key, default=None):
    return CONFIG.get(key, default)
