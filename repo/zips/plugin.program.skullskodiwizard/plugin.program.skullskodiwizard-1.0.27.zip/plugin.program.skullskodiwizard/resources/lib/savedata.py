# -*- coding: utf-8 -*-
"""
Save Data: persönliche Einstellungen überstehen Build-Installation, GUI-Fix und Fresh Start.

Gesichert werden Favoriten, Quellen, Profile, advancedsettings.xml und die Einstellungen (addon_data/<id>, ohne
Cache) der Addons, die im sKulls Forge eingetragen sind.
"""

import os
import shutil

from resources.lib import config
from resources.lib.common import ADDON_DATA, ADDONS, DATA, USERDATA, load_state, log

STORE = os.path.join(DATA, "savedata")
ADDON_CATEGORIES = ("addons",)
FILES = {"favourites": "favourites.xml", "sources": "sources.xml", "profiles": "profiles.xml",
         "advancedsettings": "advancedsettings.xml"}
SKIP_DIRS = {"cache", "temp", "thumbs", "thumbnails", "images", "logs", "downloads"}
MAX_FILE = 5 * 1024 * 1024   # große Dateien (Datenbanken, Downloads) nicht mitnehmen


def addon_ids(category):
    return [a for a in (config.get("savedata") or {}).get(category, []) if a]


def active_categories(state=None):
    state = state or load_state()
    return [c for c, on in state.get("savedata", {}).items() if on]


def _copy_tree(src, dst):
    count = 0
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if d.lower() not in SKIP_DIRS]
        target = os.path.join(dst, os.path.relpath(root, src))
        for name in files:
            path = os.path.join(root, name)
            try:
                if os.path.getsize(path) > MAX_FILE:
                    continue
                if not os.path.isdir(target):
                    os.makedirs(target)
                shutil.copy2(path, os.path.join(target, name))
                count += 1
            except OSError:
                pass
    return count


def save(state=None):
    """Aktive Kategorien sichern. Rückgabe: Anzahl gesicherter Dateien"""
    categories = active_categories(state)
    if os.path.isdir(STORE):
        shutil.rmtree(STORE, ignore_errors=True)
    count = 0
    for category in categories:
        if category in ADDON_CATEGORIES:
            for addon_id in addon_ids(category):
                src = os.path.join(ADDON_DATA, addon_id)
                if os.path.isdir(src):
                    count += _copy_tree(src, os.path.join(STORE, "addon_data", addon_id))
        elif category in FILES:
            src = os.path.join(USERDATA, FILES[category])
            if os.path.isfile(src):
                os.makedirs(os.path.join(STORE, "files"), exist_ok=True)
                shutil.copy2(src, os.path.join(STORE, "files", FILES[category]))
                count += 1
    log("Save Data gesichert: {0} Dateien ({1})".format(count, ", ".join(categories)))
    return count


def restore():
    """Gesicherte Daten zurückspielen. Rückgabe: Anzahl Dateien"""
    count = 0
    source = os.path.join(STORE, "addon_data")
    if os.path.isdir(source):
        for addon_id in os.listdir(source):
            count += _copy_tree(os.path.join(source, addon_id), os.path.join(ADDON_DATA, addon_id))
    files = os.path.join(STORE, "files")
    if os.path.isdir(files):
        for name in os.listdir(files):
            try:
                shutil.copy2(os.path.join(files, name), os.path.join(USERDATA, name))
                count += 1
            except OSError:
                pass
    log("Save Data zurückgespielt: {0} Dateien".format(count))
    return count


def stored_count():
    return sum(len(files) for _r, _d, files in os.walk(STORE)) if os.path.isdir(STORE) else 0


def clear():
    shutil.rmtree(STORE, ignore_errors=True)


def whitelist():
    """Addons, die bei einer Build-Installation komplett erhalten bleiben (mit ihren Daten)"""
    state = load_state()
    if not state.get("savedata", {}).get("whitelist"):
        return []
    return [a for a in state.get("whitelist", []) if os.path.isdir(os.path.join(ADDONS, a))]
