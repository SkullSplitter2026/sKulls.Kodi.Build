# -*- coding: utf-8 -*-
"""
Leistung & Speicher: Arbeitsspeicher und Speicherplatz des Geräts abfragen und daraus passende Einstellungen
vorschlagen - Puffergröße, Lesefaktor, Puffer-Modus, Bildgrößen und automatische Wartung.

Ab Kodi 20 stehen die Puffer-Werte in Kodis Einstellungen (filecache.*), bei Kodi 19 in der advancedsettings.xml
(<cache>). Die Bildgrößen (imageres, fanartres) stehen immer in der advancedsettings.xml und wirken erst nach einem
Neustart. Vor dem Übernehmen werden die bisherigen Werte im Zustand gesichert ("Zurücksetzen").
"""

import os
import re
import shutil
import struct
import xml.etree.ElementTree as ET

import xbmc

from resources.lib import maintenance
from resources.lib.common import (HOME, get_setting, jsonrpc, kodi_major, load_state, log, save_state,
                                  set_setting)
from resources.lib.texts import T

MB = 1024 * 1024
PROFILES = [("save", "Sparsam"), ("balanced", "Ausgewogen"), ("max", "Maximal")]
BUFFER_FACTOR = 3                                            # Kodi belegt etwa das Dreifache der Puffergröße
RAM_SHARE = {"save": 0.15, "balanced": 0.25, "max": 0.35}   # so viel vom RAM darf der Puffer (mal 3) belegen
MAX_BUFFER = {"save": 256, "balanced": 512, "max": 1024}     # MB bei 64-Bit-Kodi
MAX_BUFFER_32 = {"save": 192, "balanced": 256, "max": 384}   # MB bei 32-Bit-Kodi (kleiner Adressraum)
READFACTOR = {"save": 200, "balanced": 400, "max": 0}        # in Prozent, 0 = Adaptiv (ab Kodi 21)
LOW_RAM = 1536            # MB: schwaches Gerät
LOW_DISK = 4 * 1024       # MB frei: knapp
VERY_LOW_DISK = 1024      # MB frei: sehr knapp
DEFAULT_IMAGERES, DEFAULT_FANARTRES = 720, 1080
SMALL_IMAGERES, SMALL_FANARTRES = 540, 720

# Auswahl wie in Kodi 21 - gilt, wenn Kodi selbst keine Liste liefert (Kodi 19)
MEMORY_OPTIONS = [16, 20, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024]
READ_OPTIONS = [110, 125, 150, 175, 200, 250, 300, 400, 500, 700, 1000, 1500, 2000, 3000, 5000]
BUFFER_MODES = {0: "Alle Internet-Quellen", 1: "Alle Quellen, auch lokale Dateien", 2: "Nur Internet-Streams",
                3: "Kein Puffer", 4: "Alle Netzwerk-Quellen"}
BUFFER_MODE = 4           # Internet und Heimnetz (SMB, NFS) puffern, lokale Dateien nicht - Kodis Standard
MAINT_RANK = ["never", "monthly", "weekly", "3days", "daily", "start"]
PLATFORMS = [("Android", "System.Platform.Android"), ("Windows", "System.Platform.Windows"),
             ("tvOS", "System.Platform.TVOS"), ("iOS", "System.Platform.IOS"), ("macOS", "System.Platform.OSX"),
             ("Linux", "System.Platform.Linux")]
ADVANCED_KEYS = ["imageres", "fanartres"]
CACHE_KEYS = ("memorysize", "readfactor", "buffermode")


# ====================== Gerät abfragen ======================

def _mb(label):
    """'3962MB', '3,9 GB' -> MB"""
    label = label or ""
    numbers = re.findall(r"\d+(?:[.,]\d+)?", label)
    if not numbers:
        return 0
    value = float(numbers[0].replace(",", "."))
    return int(value * 1024) if "GB" in label.upper() else int(value)


def ram_mb():
    return _mb(xbmc.getInfoLabel("System.Memory(total)"))


def platform_name():
    for name, condition in PLATFORMS:
        if xbmc.getCondVisibility(condition):
            return name
    return ""


def device_info(cleanable=True):
    """RAM und Speicher in MB, Bitbreite, Kodi-Version. cleanable: Größe von Cache, Paketen und Vorschaubildern"""
    info = {"ram_total": ram_mb(), "ram_free": _mb(xbmc.getInfoLabel("System.Memory(free)")),
            "bits": struct.calcsize("P") * 8, "kodi": kodi_major(), "platform": platform_name(),
            "disk_total": 0, "disk_free": 0, "cleanable": 0}
    try:
        usage = shutil.disk_usage(HOME)
        info["disk_total"], info["disk_free"] = usage.total // MB, usage.free // MB
    except OSError:
        pass
    if cleanable:
        try:
            info["cleanable"] = (maintenance.cache_size() + maintenance.packages_size() +
                                 maintenance.thumbs_size()) // MB
        except OSError:
            pass
    return info


# ====================== Aktuelle Werte ======================

def kodi_options(setting_id, fallback):
    """Auswahl, die Kodi für eine Einstellung anbietet (Werte), sonst die Ersatzliste"""
    for section in ("services", "system"):
        result = jsonrpc("Settings.GetSettings", {"level": "expert",
                                                  "filter": {"section": section, "category": "filecache"}})
        for setting in (result or {}).get("settings", []):
            if setting.get("id") == setting_id and setting.get("options"):
                return [o["value"] for o in setting["options"]]
    return list(fallback)


def _advanced_root():
    try:
        return ET.parse(maintenance.ADVANCED).getroot()
    except (OSError, ET.ParseError):
        return None


def _advanced_int(root, path):
    if root is None:
        return None
    try:
        return int(float((root.findtext(path) or "").strip()))
    except ValueError:
        return None


def current_values():
    """Heutige Einstellungen. Bildgrößen None = Kodis Standard (keine Angabe in der advancedsettings.xml)"""
    root = _advanced_root()
    values = {}
    if kodi_major() >= 20:
        values["memorysize"] = get_setting("filecache.memorysize")
        values["readfactor"] = get_setting("filecache.readfactor")
        values["buffermode"] = get_setting("filecache.buffermode")
    else:
        size = _advanced_int(root, "cache/memorysize")
        factor = _advanced_int(root, "cache/readfactor")
        values["memorysize"] = 20 if size is None else size // MB
        values["readfactor"] = 400 if factor is None else factor * 100
        mode = _advanced_int(root, "cache/buffermode")
        values["buffermode"] = 0 if mode is None else mode
    values["imageres"] = _advanced_int(root, "imageres")
    values["fanartres"] = _advanced_int(root, "fanartres")
    state = load_state()
    values["maint_interval"] = state.get("maint_interval", "never")
    values["maint_thumbs"] = bool(state.get("maint_thumbs"))
    return values


# ====================== Vorschlag ======================

def _floor_option(value, options):
    """größte angebotene Stufe <= value (mindestens die kleinste)"""
    choices = sorted(o for o in options if o > 0)
    best = choices[0]
    for option in choices:
        if option <= value:
            best = option
    return best


def buffer_size(info, profile, options=MEMORY_OPTIONS):
    """(MB, Hinweis) - Puffer so, dass das Dreifache in den erlaubten Anteil des RAM passt"""
    ram = info.get("ram_total") or 0
    if ram <= 0:
        return 64, "unknown"
    limit = (MAX_BUFFER_32 if info.get("bits") == 32 else MAX_BUFFER)[profile]
    size = _floor_option(min(limit, ram * RAM_SHARE[profile] / BUFFER_FACTOR), options)
    note = ""
    free = info.get("ram_free") or 0
    if free and size * BUFFER_FACTOR > free * 0.8:
        smaller = _floor_option(free * 0.8 / BUFFER_FACTOR, options)
        if smaller < size:
            size, note = smaller, "low_free"
    return size, note


def _row(key, label, current, recommended, texts, reasons, restart=False):
    """texts: (aktuell, empfohlen) als fertige Anzeige, reasons: [(Text, [Werte])] - wird übersetzt"""
    return {"key": key, "label": T(label), "current": current, "recommended": recommended,
            "text": (texts[0], texts[1]), "reason": " ".join(T(text).format(*args) for text, args in reasons),
            "changed": current != recommended, "restart": restart}


def recommend(info, profile, current, memory_options=MEMORY_OPTIONS, read_options=READ_OPTIONS):
    """Zeilen für die Tabelle: key, label, current, recommended, text (aktuell, empfohlen), reason, changed, restart"""
    rows = []
    ram, free_disk, kodi = info.get("ram_total") or 0, info.get("disk_free") or 0, info.get("kodi") or 0
    restart = kodi < 20          # Kodi 19: Puffer steht in der advancedsettings.xml

    size, note = buffer_size(info, profile, memory_options)
    reasons = [("Der Puffer belegt etwa das Dreifache im Arbeitsspeicher: {0} MB von {1} MB.",
                [size * BUFFER_FACTOR, ram])]
    if info.get("bits") == 32:
        reasons.append(("32-Bit-Kodi kann nur begrenzt Speicher nutzen - deshalb höchstens {0} MB.",
                        [MAX_BUFFER_32[profile]]))
    if note == "unknown":
        reasons = [("Kodi meldet keinen Arbeitsspeicher - darum ein vorsichtiger Wert.", [])]
    if note == "low_free":
        reasons.append(("Gerade sind nur {0} MB frei - darum etwas kleiner.", [info.get("ram_free")]))
    if ram and ram < LOW_RAM and free_disk > 8 * 1024:
        reasons.append(("Alternative bei wenig RAM: Puffer auf dem Speicher (in Kodi: Puffergröße 0) - belastet "
                        "aber den Flash-Speicher.", []))
    cur = current.get("memorysize")
    rows.append(_row("memorysize", "Puffergröße", cur, size, (_size_text(cur), _size_text(size)), reasons,
                     restart))

    factor = READFACTOR[profile]
    if factor == 0 and 0 not in read_options:
        factor = 1000
    if kodi and kodi < 20:              # Kodi 19 kennt nur ganze Faktoren
        factor = max(100, factor // 100 * 100)
    elif factor:
        factor = _floor_option(factor, read_options)
    reasons = {"save": [("Langsameres Füllen schont schwache Geräte und das Netz.", [])],
               "balanced": [("Kodis Standard: lädt viermal so schnell, wie das Video abspielt.", [])],
               "max": [("Füllt den Puffer so schnell, wie die Verbindung es erlaubt.", [])]}[profile]
    cur = current.get("readfactor")
    rows.append(_row("readfactor", "Lesefaktor", cur, factor, (_factor_text(cur), _factor_text(factor)), reasons,
                     restart))

    cur = current.get("buffermode")
    rows.append(_row("buffermode", "Puffer-Modus", cur, BUFFER_MODE,
                     (T(BUFFER_MODES.get(cur, "?")), T(BUFFER_MODES[BUFFER_MODE])),
                     [("Internet und Heimnetz werden gepuffert, lokale Dateien brauchen keinen Puffer.", [])],
                     restart))

    small = profile == "save" or 0 < ram < LOW_RAM or 0 < free_disk < LOW_DISK
    for key, small_value, default, label in (
            ("imageres", SMALL_IMAGERES, DEFAULT_IMAGERES, "Größe der Vorschaubilder"),
            ("fanartres", SMALL_FANARTRES, DEFAULT_FANARTRES, "Größe der Fanarts")):
        cur = current.get(key)
        if small and (cur or default) > small_value:
            recommended = small_value
            reasons = [("Kleinere Bilder sparen Speicher und Arbeitsspeicher - auf dem Fernseher kaum sichtbar.", [])]
        else:
            recommended, reasons = cur, [("Passt.", [])]
        rows.append(_row(key, label, cur, recommended, (_res_text(cur, default), _res_text(recommended, default)),
                         reasons, True))

    cur = current.get("maint_interval", "never")
    interval = cur
    if (0 < free_disk < LOW_DISK or profile == "save") and _rank(cur) < _rank("weekly"):
        interval = "weekly"
    reasons = [("Wenig freier Speicher: Der Wizard räumt dann regelmäßig Cache und Pakete auf.", [])]         if interval != cur else [("Passt.", [])]
    rows.append(_row("maint_interval", "Automatische Wartung", cur, interval,
                     (T(INTERVAL_NAMES.get(cur, cur)), T(INTERVAL_NAMES.get(interval, interval))), reasons))

    cur = bool(current.get("maint_thumbs"))
    want = cur or 0 < free_disk < VERY_LOW_DISK
    reasons = [("Speicher ist sehr knapp - Vorschaubilder belegen oft am meisten Platz.", [])] if want != cur         else [("Passt.", [])]
    rows.append(_row("maint_thumbs", "Vorschaubilder bei der Wartung löschen", cur, want,
                     (T("an") if cur else T("aus"), T("an") if want else T("aus")), reasons))
    return rows


INTERVAL_NAMES = {"never": "Nie", "start": "Bei jedem Start", "daily": "Täglich", "3days": "Alle 3 Tage",
                  "weekly": "Wöchentlich", "monthly": "Monatlich"}


def _rank(interval):
    return MAINT_RANK.index(interval) if interval in MAINT_RANK else 0


def _size_text(value):
    if value is None:
        return "?"
    if value == 0:
        return T("Auf dem Speicher")
    return "1 GB" if value == 1024 else "{0} MB".format(value)


def _factor_text(value):
    if value is None:
        return "?"
    if value == 0:
        return T("Adaptiv")
    text = "{0:g}".format(value / 100.0).replace(".", ",")
    return text + "x"


def _res_text(value, default):
    return T("Standard ({0})").format(default) if value is None else str(value)


# ====================== Übernehmen / Zurücksetzen ======================

def _write_advanced(values):
    """values: {Pfad: Text oder None} - None entfernt den Eintrag. Pfad z.B. 'imageres' oder 'cache/memorysize'"""
    root = _advanced_root()
    if root is None:
        if all(v is None for v in values.values()):
            return
        root = ET.Element("advancedsettings", version="1.0")
    for path, value in values.items():
        parent = root
        parts = path.split("/")
        for part in parts[:-1]:
            node = parent.find(part)
            if node is None:
                if value is None:
                    parent = None
                    break
                node = ET.SubElement(parent, part)
            parent = node
        if parent is None:
            continue
        node = parent.find(parts[-1])
        if value is None:
            if node is not None:
                parent.remove(node)
        else:
            if node is None:
                node = ET.SubElement(parent, parts[-1])
            node.text = str(value)
    cache = root.find("cache")
    if cache is not None and not list(cache):
        root.remove(cache)
    if not list(root):
        try:
            os.remove(maintenance.ADVANCED)
        except OSError:
            pass
        return
    ET.ElementTree(root).write(maintenance.ADVANCED, encoding="utf-8", xml_declaration=True)


def _set(key, value):
    if key in CACHE_KEYS:
        if kodi_major() >= 20:
            set_setting("filecache." + key, int(value))
        elif key == "memorysize":
            _write_advanced({"cache/memorysize": int(value) * MB})
        elif key == "readfactor":
            _write_advanced({"cache/readfactor": max(1, int(value) // 100)})
        else:
            _write_advanced({"cache/buffermode": int(value)})
    elif key in ADVANCED_KEYS:
        _write_advanced({key: value})
    elif key in ("maint_interval", "maint_thumbs"):
        state = load_state()
        state[key] = value
        save_state(state)


def apply(rows, keys):
    """Empfohlene Werte der gewählten Zeilen übernehmen. Rückgabe: True, wenn ein Neustart nötig ist"""
    state = load_state()
    backup = state.get("tuning_backup") or {}
    restart = False
    old_kodi = kodi_major() < 20
    root = _advanced_root()
    for row in rows:
        if row["key"] not in keys or not row["changed"]:
            continue
        previous = row["current"]
        if old_kodi and row["key"] in CACHE_KEYS and _advanced_int(root, "cache/" + row["key"]) is None:
            previous = None                                # stand nicht in der Datei: beim Zurücksetzen entfernen
        backup.setdefault(row["key"], previous)            # ältesten Stand behalten
        _set(row["key"], row["recommended"])
        restart = restart or row["restart"]
        log("Leistung: {0} {1} -> {2}".format(row["key"], row["current"], row["recommended"]))
    state = load_state()
    state["tuning_backup"] = backup
    save_state(state)
    return restart


def has_backup():
    return bool(load_state().get("tuning_backup"))


def restore():
    """Werte von vor dem ersten Übernehmen zurückschreiben. Rückgabe: True, wenn ein Neustart nötig ist"""
    backup = load_state().get("tuning_backup") or {}
    restart = False
    old_kodi = kodi_major() < 20
    for key, value in backup.items():
        if value is None and key in CACHE_KEYS:
            if old_kodi:
                _write_advanced({"cache/" + key: None})
            continue
        _set(key, value)
        restart = restart or key in ADVANCED_KEYS or (old_kodi and key in CACHE_KEYS)
    state = load_state()
    state["tuning_backup"] = {}
    save_state(state)
    log("Leistung: Werte zurückgesetzt ({0})".format(", ".join(sorted(backup))))
    return restart


def gb(mb):
    """MB -> '2,0 GB' bzw. '512 MB'"""
    return ("{0:.1f} GB".format(mb / 1024.0) if mb >= 1024 else "{0} MB".format(int(mb))).replace(".", ",")
