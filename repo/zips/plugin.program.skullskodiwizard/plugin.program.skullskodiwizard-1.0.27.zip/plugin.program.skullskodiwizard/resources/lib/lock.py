# -*- coding: utf-8 -*-
"""
Passwortgeschützte Builds: entschlüsseln (der sKulls Forge verschlüsselt mit modules/build_lock.py - gleiches Verfahren).

Nur Bausteine, die jedes Python ab 3.8 mitbringt (also jedes Kodi ab 19, auf Windows, Android, macOS, Linux):
  Schlüssel  = PBKDF2-HMAC-SHA256(Passwort, Salz, Runden)
  Prüfwert   = HMAC-SHA256(Schlüssel, "skforge-lock-check")   -> falsches Passwort erkennen, ohne zu entschlüsseln
  Datenschl. = HMAC-SHA256(Schlüssel, "skforge-lock-enc")
  Datei      = Klartext XOR SHAKE-256(Datenschl. + Nonce + Blocknummer), Blöcke zu 1 MiB
  Echtheit   = SHA-256 des Klartexts (steht in der Build-Liste), zusätzlich SHA-256 der verschlüsselten Datei
"""

import hashlib
import hmac
import os

BLOCK = 1024 * 1024
CHECK_LABEL = b"skforge-lock-check"
ENC_LABEL = b"skforge-lock-enc"


class LockError(Exception):
    pass


def supported():
    return hasattr(hashlib, "shake_256") and hasattr(hashlib, "pbkdf2_hmac")


def derive(password, info):
    """Passwort -> Schlüssel (hex). Kann auf schwachen Geräten ein paar Sekunden dauern."""
    if not supported():
        raise LockError("Dieses Kodi kann geschützte Builds nicht öffnen (SHA-3 fehlt)")
    if info.get("v") != 1 or info.get("kdf") != "pbkdf2-sha256":
        raise LockError("Unbekanntes Schutzverfahren - bitte den Wizard aktualisieren")
    key = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(info["salt"]), int(info["iter"]), 32)
    return key.hex()


def check(key_hex, info):
    """Passt der Schlüssel zu diesem Build?"""
    try:
        expected = hmac.new(bytes.fromhex(key_hex), CHECK_LABEL, hashlib.sha256).hexdigest()
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(expected, info.get("check", ""))


def _xor_block(data, enc_key, nonce, index):
    stream = hashlib.shake_256(enc_key + nonce + index.to_bytes(8, "big")).digest(len(data))
    return (int.from_bytes(data, "big") ^ int.from_bytes(stream, "big")).to_bytes(len(data), "big")


def decrypt_file(src, dest, key_hex, info, progress=None):
    """Verschlüsselte Datei -> Klartext-ZIP. Prüft SHA-256 des Ergebnisses. progress(fertig, gesamt) -> False bricht ab."""
    if not check(key_hex, info):
        raise LockError("Falsches Passwort")
    enc_key = hmac.new(bytes.fromhex(key_hex), ENC_LABEL, hashlib.sha256).digest()
    nonce = bytes.fromhex(info["nonce"])
    total = os.path.getsize(src)
    digest = hashlib.sha256()
    tmp = dest + ".part"
    index = 0
    try:
        with open(src, "rb") as fin, open(tmp, "wb") as fout:
            while True:
                block = fin.read(BLOCK)
                if not block:
                    break
                plain = _xor_block(block, enc_key, nonce, index)
                digest.update(plain)
                fout.write(plain)
                index += 1
                if progress and progress(min(total, index * BLOCK), total) is False:
                    raise LockError("Abgebrochen")
        if digest.hexdigest() != info.get("plain_sha256"):
            raise LockError("Entschlüsselter Build ist beschädigt (Prüfsumme stimmt nicht)")
        os.replace(tmp, dest)
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
    return dest
