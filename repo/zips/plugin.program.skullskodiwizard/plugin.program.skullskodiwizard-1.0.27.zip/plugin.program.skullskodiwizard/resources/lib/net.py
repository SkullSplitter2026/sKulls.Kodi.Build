# -*- coding: utf-8 -*-
"""
Netzwerk: lädt die Build-Liste und die Builds von der Adresse, die der sKulls Forge beim Bauen einträgt
(z.B. GitHub Pages oder ein eigener Webserver). Downloads werden gegen Größe und SHA-256 aus der Build-Liste geprüft.

Abgebrochene Downloads (Abbrechen, WLAN weg, Kodi beendet) bleiben als .part liegen und werden beim nächsten Mal mit
einer Range-Anfrage fortgesetzt - aber nur, wenn es dieselbe Datei ist (gleiche Prüfsumme und Größe laut Build-Liste,
gemerkt in .part.json). Kann der Server nicht fortsetzen (Antwort 200 statt 206), wird neu geladen.
"""

import hashlib
import json
import os
import ssl
import urllib.error
import urllib.request

from resources.lib import config
from resources.lib.texts import T
from resources.lib.common import ADDON_ID, ADDON_VERSION, log

TIMEOUT = 30
CHUNK = 256 * 1024


class NetError(Exception):
    pass


def _context():
    try:
        import certifi  # script.module.certifi, falls vorhanden
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:  # noqa: BLE001
        return ssl.create_default_context()


def url_for(name):
    """Name aus der Build-Liste -> Adresse (absolute Adressen bleiben, wie sie sind)"""
    if name.startswith(("https://", "http://")):
        return name
    base = (config.get("server") or {}).get("base", "")
    return base.rstrip("/") + "/" + name.lstrip("/")


def _open(name, timeout=TIMEOUT, headers=None):
    url = url_for(name)
    if not url.startswith(("https://", "http://")):
        raise NetError(T("Keine Adresse für die Build-Liste eingetragen"))
    request = urllib.request.Request(url, headers=dict({"User-Agent": "{0}/{1} Kodi".format(ADDON_ID, ADDON_VERSION)},
                                                       **(headers or {})))
    try:
        if url.startswith("https://"):
            return urllib.request.urlopen(request, timeout=timeout, context=_context())
        return urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.HTTPError as e:
        raise NetError(T("Server-Fehler {0}").format(e.code))
    except Exception as e:  # noqa: BLE001
        raise NetError(str(e))


def fetch_json(name, limit=2 * 1024 * 1024):
    with _open(name) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise NetError("Antwort zu groß")
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError:
        raise NetError("Ungültige Antwort vom Server")


def _part_matches(tmp, sha256, size):
    """Gehört die angefangene Datei zu genau diesem Download?"""
    try:
        with open(tmp + ".json") as f:
            meta = json.load(f)
    except (OSError, ValueError):
        return False
    have = os.path.getsize(tmp) if os.path.isfile(tmp) else 0
    return bool(sha256) and meta.get("sha256") == sha256 and int(meta.get("size") or 0) == int(size or 0) and \
        0 < have < (int(size) if size else have + 1)


def _discard(tmp):
    for path in (tmp, tmp + ".json"):
        try:
            os.remove(path)
        except OSError:
            pass


def download(name, dest, sha256="", size=0, progress=None):
    """Lädt nach dest. progress(geladen, gesamt) -> False bricht ab. Prüft Größe und SHA-256.
    Ein abgebrochener Download wird beim nächsten Aufruf fortgesetzt (siehe oben)."""
    digest = hashlib.sha256()
    tmp = dest + ".part"
    folder = os.path.dirname(dest)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    offset = 0
    if _part_matches(tmp, sha256, size):
        offset = os.path.getsize(tmp)
    else:
        _discard(tmp)
    with open(tmp + ".json", "w") as f:
        json.dump({"sha256": sha256, "size": int(size or 0), "name": name}, f)
    response = _open(name, timeout=60, headers={"Range": "bytes={0}-".format(offset)} if offset else None)
    with response:
        if offset and getattr(response, "status", 200) != 206:
            log("Server kann nicht fortsetzen - lade {0} neu".format(name))
            offset = 0
        if offset:
            with open(tmp, "rb") as f:      # Prüfsumme über den schon geladenen Teil
                for chunk in iter(lambda: f.read(CHUNK), b""):
                    digest.update(chunk)
            log("Setze Download fort: {0} ab {1} Bytes".format(name, offset))
        loaded = offset
        length = int(response.headers.get("Content-Length") or 0)
        total = (offset + length) if length else int(size or 0)
        with open(tmp, "ab" if offset else "wb") as f:
            while True:
                chunk = response.read(CHUNK)
                if not chunk:
                    break
                f.write(chunk)
                digest.update(chunk)
                loaded += len(chunk)
                if progress and progress(loaded, total) is False:
                    raise NetError("Abgebrochen")        # .part bleibt - beim nächsten Mal geht es hier weiter
    if size and loaded != int(size):
        if loaded > int(size):
            _discard(tmp)
        raise NetError(T("Download unvollständig ({0} von {1} Bytes)").format(loaded, size))
    if sha256 and digest.hexdigest().lower() != sha256.lower():
        _discard(tmp)
        raise NetError("Prüfsumme stimmt nicht - Datei beschädigt oder verändert")
    os.replace(tmp, dest)
    _discard(tmp)
    log("Geladen: {0} ({1} Bytes, SHA-256 {2})".format(name, loaded, "geprüft" if sha256 else "ohne Prüfung"))
    return dest
