# -*- coding: utf-8 -*-
"""
Build-News als Laufschrift: den RSS-Feed des Wizards (im sKulls Forge erstellt, liegt neben builds.json) in Kodis
RssFeeds.xml eintragen - Satz 1, den zeigen die Skins - und die Laufschrift einschalten.

Eingetragen wird beim Start, wenn der Feed neu ist oder eine Build-Installation, ein Fresh Start oder ein Restore die
Einstellungen ersetzt hat. Hat der Nutzer ihn selbst entfernt, bleibt er weg - bis zur nächsten Installation.
Abschalten (Einstellungen im Wizard) schreibt den vorherigen Satz 1 zurück.
"""

import os
import re
from xml.sax.saxutils import escape

import xbmc

from resources.lib import config
from resources.lib.common import USERDATA, load_state, log, save_state, set_setting

RSS_FILE = os.path.join(USERDATA, "RssFeeds.xml")
SET1 = re.compile(r"<set\s+id=[\"']1[\"'][^>]*>.*?</set>", re.S)
EMPTY = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<rssfeeds>\n</rssfeeds>\n'


def feed():
    """{"url", "interval", "auto"} aus resources/wizard.json - None ohne Feed"""
    cfg = config.get("rss") or {}
    return cfg if cfg.get("url") else None


def _read():
    try:
        with open(RSS_FILE, "r", encoding="utf-8") as f:
            return f.read()
    except (OSError, ValueError):
        return ""


def _write(text):
    tmp = RSS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, RSS_FILE)


def _block(url, interval):
    return '<set id="1" rtl="false">\n        <feed updateinterval="{0}">{1}</feed>\n    </set>'.format(
        max(5, int(interval or 30)), escape(url))


def active():
    cfg = feed()
    return bool(cfg) and not load_state().get("rss_off") and escape(cfg["url"]) in _read()


def apply(force=False):
    """Feed eintragen. force: auch wenn er schon einmal eingetragen war (Schalter im Wizard)"""
    cfg = feed()
    if not cfg:
        return False
    state = load_state()
    if not force and (state.get("rss_off") or not cfg.get("auto") or state.get("rss_applied") == cfg["url"]):
        return False
    text = _read() or EMPTY
    block = _block(cfg["url"], cfg.get("interval"))
    m = SET1.search(text)
    if m:
        if escape(cfg["url"]) not in m.group(0):
            state["rss_previous"] = m.group(0)          # Satz 1 des Nutzers/Builds - für das Abschalten
        text = text[:m.start()] + block + text[m.end():]
    elif "</rssfeeds>" in text:
        text = text.replace("</rssfeeds>", "    " + block + "\n</rssfeeds>", 1)
    else:
        text = EMPTY.replace("</rssfeeds>", "    " + block + "\n</rssfeeds>")
    _write(text)
    set_setting("lookandfeel.enablerssfeeds", True)
    xbmc.executebuiltin("RefreshRSS")
    state["rss_applied"], state["rss_off"] = cfg["url"], False
    save_state(state)
    log("RSS-Laufschrift eingestellt: {0}".format(cfg["url"]))
    return True


def remove():
    """Abschalten: vorherigen Satz 1 zurück (gab es keinen, Laufschrift aus)"""
    cfg = feed()
    state = load_state()
    text = _read()
    m = SET1.search(text)
    if cfg and m and escape(cfg["url"]) in m.group(0):
        previous = state.get("rss_previous") or ""
        _write(text[:m.start()] + previous + text[m.end():])
        if not previous:
            set_setting("lookandfeel.enablerssfeeds", False)
        xbmc.executebuiltin("RefreshRSS")
    state["rss_off"], state["rss_applied"] = True, ""
    save_state(state)
    log("RSS-Laufschrift des Wizards abgeschaltet")


def reset():
    """Nach Build-Installation, Fresh Start oder Restore: beim nächsten Start neu eintragen (RssFeeds.xml ist ersetzt)"""
    state = load_state()
    if state.get("rss_applied"):
        state["rss_applied"] = ""
        save_state(state)
