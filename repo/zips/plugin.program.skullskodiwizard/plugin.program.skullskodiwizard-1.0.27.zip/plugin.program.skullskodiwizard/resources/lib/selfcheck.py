# -*- coding: utf-8 -*-
"""
Selbstprüfung: stimmen die Dateien des Wizards noch mit den Prüfsummen überein, die der sKulls Forge beim Bauen in
resources/checksums.json schreibt? Erkennt beschädigte (z.B. abgebrochenes Update, voller Speicher) oder veränderte
Dateien. Zusätzliche Dateien (z.B. __pycache__) werden nicht gemeldet.
"""

import hashlib
import json
import os
import time

from resources.lib.common import ADDON_PATH, load_state, log, log_error, save_state

LIST = os.path.join(ADDON_PATH, "resources", "checksums.json")


def _digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def verify():
    """[(Datei, "fehlt"|"verändert")] - None, wenn der Wizard keine Prüfsummen mitbringt"""
    try:
        with open(LIST, "r", encoding="utf-8") as f:
            files = json.load(f).get("files", {})
    except (OSError, ValueError, AttributeError):
        return None
    bad = []
    base = os.path.realpath(ADDON_PATH)
    for rel, digest in sorted(files.items()):
        path = os.path.realpath(os.path.join(ADDON_PATH, *rel.split("/")))
        if not path.startswith(base + os.sep):
            continue        # nur Dateien innerhalb des Wizards
        try:
            if _digest(path) != digest:
                bad.append((rel, "verändert"))
        except OSError:
            bad.append((rel, "fehlt"))
    return bad


def guard():
    """Beim Öffnen des Wizards: Dateien verändert? Dann fragen - True = weiter öffnen, False = abbrechen"""
    from resources.lib import dialogs
    from resources.lib.texts import T
    bad = verify()
    if not bad:
        return True
    log_error("Wizard verändert: {0}".format(", ".join(rel for rel, _w in bad[:10])))
    index = dialogs.select(T("Achtung: {0} Datei(en) des Wizards wurden verändert oder fehlen").format(len(bad)),
                           [(T("Abbrechen"), T("Wizard nicht öffnen")),
                            (T("Wizard reparieren"), T("Dateien neu vom Server laden")),
                            (T("Trotzdem weiter"), T("auf eigene Gefahr"))], search=False)
    if index == 1:
        return "repair"
    return index == 2


def run():
    """Prüfen und das Ergebnis merken (für die Einstellungen). Rückgabe wie verify()"""
    bad = verify()
    state = load_state()
    state["selfcheck"] = {"time": time.time(), "available": bad is not None, "bad": [list(b) for b in bad or []]}
    save_state(state)
    if bad:
        log_error("Selbstprüfung: {0} Datei(en) beschädigt oder verändert: {1}".format(
            len(bad), ", ".join(rel for rel, _w in bad[:10])))
    elif bad is not None:
        log("Selbstprüfung: alle Dateien in Ordnung")
    return bad
