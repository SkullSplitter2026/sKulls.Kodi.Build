# -*- coding: utf-8 -*-
"""Hintergrund-Dienst: erster Start, Updates, automatische Wartung"""
from resources.lib import service

service.run()
