# -*- coding: utf-8 -*-
"""Startet die Wizard-Zentrale (eigenes Vollbild-Fenster, unabhängig vom Skin)"""
from resources.lib import ui

ui.open_main()
