﻿# -*- coding: utf-8 -*-

from .common import *
config = traversing.get_config()


def main_menu():
	debug_MS("(navigator.main_menu) -------------------------------------------------- START = main_menu --------------------------------------------------")
	combo_pages, (score_live, score_next) = [], (0 for _ in range(2))
	add_views({'mode': 'list_favorites'}, create_entries({'Title': translation(30605), 'Image': f"{artpic}favourites.png"}))
	if nowlive or upcoming:
		for ii in range(1, 5, 1):
			pages_link = f"{config['HOME_STARTS']}page={str(ii)}&per_page=50"
			debug_MS(f"(navigator.main_menu[1]) OVERVIEW-PAGES XXX POS : {str(ii)} || LINK : {pages_link} XXX")
			combo_pages.append({'Count_1': int(ii), 'Link_1': pages_link})
		if combo_pages:
			complete = track_several(combo_pages, 'GET', 'JSON', WEB_HEADER)
			debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
			if complete:
				for item in sorted(json.loads(complete), key=lambda pn: int(pn.get('Position', 0))):
					if item not in ['', None] and item.get('Status', 'OOKAY') != 'ERROR' and item.get('data', '') and len(item['data']) > 0:
						for each in item.get('data', []):
							if each.get('currently_live', False) is True and not str(each.get('price_in_cents')).isdecimal() and len([mz for mz in each.get('monetizations', '')]) == 0:
								if str(each.get('content_start_date'))[:10].replace('.', '').replace('-', '').replace('/', '').isdecimal() and datetime.now() > convert_region(each['content_start_date']):
									score_live += 1
							elif each.get('currently_live', False) is False and not str(each.get('price_in_cents')).isdecimal() and len([mz for mz in each.get('monetizations', '')]) == 0:
								if str(each.get('content_start_date'))[:10].replace('.', '').replace('-', '').replace('/', '').isdecimal() and \
									datetime.now() < convert_region(each['content_start_date']) + timedelta(seconds=20):
									score_next += 1
	if nowlive and score_live > 0:
		fetch_uno = create_entries({'Title': translation(30701).format(score_live), 'Plot': translation(30702).format(score_live), 'Image': f"{artpic}livestream.png"})
		add_views({'mode': 'list_videos', 'Link': config['HOME_STARTS'], 'Limit': 50, 'Wanted': 4, 'Extras': 'playlive'}, fetch_uno)
	if upcoming and score_next > 0:
		fetch_due = create_entries({'Title': translation(30703).format(score_next), 'Plot': translation(30704).format(score_next), 'Image': f"{artpic}upcoming.png"})
		add_views({'mode': 'list_videos', 'Link': config['HOME_STARTS'], 'Limit': 50, 'Wanted': 4, 'Extras': 'playnext'}, fetch_due)
	if newest: add_views({'mode': 'list_videos', 'Link': config['HOME_ASSETS'], 'Limit': 20, 'Wanted': 1, 'Extras': 'playnext'}, create_entries({'Title': translation(30606)}))
	if topping: add_views({'mode': 'list_sports', 'Link': config['HOME_TOPS'], 'Limit': 10, 'Wanted': 1, 'Extras': 'channels', 'Name': 'Topprofile'}, create_entries({'Title': translation(30607)}))
	if preserve(MENUES_FILE) is not None:
		for elem in preserve(MENUES_FILE):
			fetch_tre = {'mode': 'list_categories', 'Slug': elem.get('Slug'), 'Code': elem.get('Code'), 'Sector': cleaning(elem.get('Title')), 'Limit': 50, 'Wanted': 8, 'Extras': 'tags', 'Title': cleaning(elem.get('Title'))}
			add_views(fetch_tre, create_entries(fetch_tre))
	if sporting: add_views({'mode': 'list_sports', 'Link': config['SPORT_TYPES'], 'Limit': 20, 'Wanted': 8, 'Extras': 'sports', 'Name': 'Sportarten'}, create_entries({'Title': translation(30608)}))
	if channeling: add_views({'mode': 'list_sports', 'Link': config['SPORT_PROFILE'], 'Limit': 50, 'Wanted': 20, 'Extras': 'channels', 'Name': 'Sportkanäle'}, create_entries({'Title': translation(30609)}))
	if teamsearch: add_views({'mode': 'search_euro', 'Extras': 'PROFILE'}, create_entries({'Title': translation(30610), 'Image': f"{artpic}basesearch.png"}))
	if videosearch: add_views({'mode': 'search_euro', 'Extras': 'VIDEOS'}, create_entries({'Title': translation(30611), 'Image': f"{artpic}basesearch.png"}))
	add_views({'mode': 'list_selection', 'Link': config['SPORT_TYPES'], 'Limit': 20, 'Wanted': 8}, create_entries({'Title': translation(30612), 'Image': f"{artpic}editmenu.png"}), False)
	if enable_tune:
		add_views({'mode': 'antuning'}, create_entries({'Title': translation(30613), 'Image': f"{artpic}settings.png"}), False)
		if enable_adaptive and plugin_operate('inputstream.adaptive'):
			add_views({'mode': 'ietuning'}, create_entries({'Title': translation(30614), 'Image': f"{artpic}settings.png"}), False)
	if not plugin_operate('inputstream.adaptive'):
		addon.setSetting('use_adaptive', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def list_selection(TARGET, PAGE, LIMIT, WANTED):
	debug_MS("(navigator.list_selection) -------------------------------------------------- START = list_selection --------------------------------------------------")
	PAGE, MAXIMUM = int(PAGE), int(PAGE)+int(WANTED)
	counter, (combo_sites, book_stores, book_names, book_entries, book_folders) = 0, ([] for _ in range(5))
	for ii in range(PAGE, MAXIMUM, 1):
		pages_link = f"{TARGET}page={str(ii)}&per_page={str(LIMIT)}"
		debug_MS(f"(navigator.list_selection[1]) SELECTION-PAGES XXX POS : {str(ii)} || LINK : {pages_link} XXX")
		combo_sites.append({'Count_1': int(ii), 'Link_1': pages_link})
	if combo_sites:
		package = track_several(combo_sites, 'GET', 'JSON', WEB_HEADER)
		if package:
			for editors in sorted(json.loads(package), key=lambda sk: int(sk.get('Position', 0))):
				if editors not in ['', None] and editors.get('Status', 'OOKAY') != 'ERROR' and editors.get('data', '') and len(editors['data']) > 0:
					for content in editors.get('data', []):
						if content.get('name', '') and content.get('id', '') and content.get('slug', ''):
							counter += 1
							book_names.append(translation(30711).format(counter, str(content['name'])))
							book_entries.append({'Number': counter, 'Title': content['name'], 'Code': content['id'], 'Slug': content['slug']})
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++")
			debug_MS(f"(navigator.list_selection[2]) XXXXX SPORT-MENÜ-EINTRÄGE AUF ANBIETER-LISTE : {book_entries} XXXXX")
			debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++")
	if book_names and book_entries:
		if preserve(MENUES_FILE) is not None:
			positions = preserve(MENUES_FILE)
			book_stores = [(int(nr.get('Number', 0)) - 1) for nr in positions]
			debug_MS(f"(navigator.list_selection[3]) ##### LESE GESPEICHERTE BENUTZER-MENÜ-EINTRÄGE : {[int(nb.get('Number', 0)) for nb in positions]} #####")
		indicator = dialog.multiselect(translation(30712), book_names, preselect=book_stores)
		if indicator is None:
			debug_MS("(navigator.list_selection[4]) <<<<< BENUTZER-MENÜ-EINTRÄGE NICHT VERÄNDERT - AKTION DURCH BENUTZER ABGEBROCHEN <<<<<")
			return
		book_folders = [book_entries[dm] for dm in indicator] if indicator else []
		if len(book_folders) == 0:
			debug_MS("(navigator.list_selection[4]) !!!!! BENUTZER-MENÜ-EINTRÄGE SIND LEER - LÖSCHE MENUES_FILE !!!!!")
			xbmcvfs.delete(MENUES_FILE)
		elif len(book_folders) >= 1:
			debug_MS(f"(navigator.list_selection[4]) ***** NEUE BENUTZER-MENÜ-EINTRÄGE ERFOLGREICH ERSTELLT : {book_folders} *****")
			preserve(MENUES_FILE, 'JSON', book_folders)
		xbmc.sleep(1000)
		xbmc.executebuiltin('Container.Refresh')
	else:
		failing(f"(navigator.list_selection) ##### Keine COMBI_SPORTS-List - Kein Eintrag unter: {TARGET} gefunden #####")
		return dialog.notification(translation(30521).format('PROVIDER'), translation(30522), icon, 12000)

def list_sports(TARGET, CODE, SECTOR, PAGE, LIMIT, WANTED, SCENE, SERIE):
	debug_MS("(navigator.list_sports) -------------------------------------------------- START = list_sports --------------------------------------------------")
	debug_MS(f"(navigator.list_sports) ### LINK = {TARGET} ### CODE = {CODE} ### GENRE = {SECTOR} ### PAGE = {PAGE} ### LIMIT = {LIMIT} ### maxPAGES = {WANTED} ### EXTRA = {SCENE} ### SERIE = {SERIE} ###")
	PAGE, MAXIMUM = int(PAGE), int(PAGE)+int(WANTED)
	unikat, item, (combo_pages, primodo) = set(), None, ([] for _ in range(2))
	for ii in range(PAGE, MAXIMUM, 1): # 1. Alle Sportarten / 2. Vereine und Events / 3. Suche Vereine und Events
		PAGE += 1
		pages_link = f"{TARGET}page={str(ii)}&per_page={str(LIMIT)}"
		debug_MS(f"(navigator.list_sports[1]) SPORT-PAGES XXX POS : {str(ii)} || LINK : {pages_link} XXX")
		combo_pages.append({'Count_1': int(ii), 'Link_1': pages_link})
	if combo_pages:
		complete = track_several(combo_pages, 'GET', 'JSON', WEB_HEADER)
		debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
		if complete:
			for item in sorted(json.loads(complete), key=lambda pn: int(pn.get('Position', 0))):
				if item not in ['', None] and item.get('Status', 'OOKAY') != 'ERROR' and item.get('data', '') and len(item['data']) > 0:
					number_uno, link_uno = item['Position'], item['Demand']
					for sports in item.get('data', []):
						debug_MS(f"(navigator.list_sports[2]) xxxxx CATS-02 : {sports} xxxxx")
						uuid = sports.get('id', None)
						if uuid is None or uuid in unikat:
							continue
						unikat.add(uuid)
						booklet, slug = cleaning(sports['name']), sports['slug']
						if slug == 'barmeniagothaer': continue # Werbepartner ausblenden
						branch = cleaning(sports['sport_type']['name']) if sports.get('sport_type', '') and sports['sport_type'].get('name', '') else 'sport'
						genre = SECTOR if branch == 'sport' and branch.lower() != SECTOR.lower() else branch.title()
						if SCENE == 'sports': genre = booklet
						newDEM, newLIMIT, newWANTED, newSCENE = slug, 50, 8, 'tags'
						descript = (cleaning(sports.get('description', ''), True) or "")
						img_cid = (sports.get('image_url', None) or sports.get('image_id', None))
						thumb = IMG_CATS.format(img_cid, '640x360') if img_cid else None # Categories = 640x360
						if SCENE in ['channels', 'teams']: # Direkt weiter zum Verein
							newDEM, newLIMIT, newWANTED, newSCENE = slug, 50, 8, 'profiles'
							descript = translation(30721).format(booklet, descript)
							thumb = IMG_CATS.format(img_cid, '480x480') if img_cid else None # Profiles = 480x480
						primodo.append({'Count_1': int(number_uno), 'Link_1': link_uno, 'Code': uuid, 'Name': booklet, 'Plot': descript, 'Slug': slug,
							'Link_2': newDEM, 'Limit_2': newLIMIT, 'Wanted_2': newWANTED, 'Scene_2': newSCENE, 'Genre': genre, 'Photo': thumb})
	if primodo:
		for posts in sorted(primodo, key=lambda asx: clear_umlaut(asx.get('Name', 'zorro')).lower()):
			operation = 'skipping' # Alle Sportarten oder Vereine und Events
			if SCENE in ['channels', 'teams']: # Nur Vereine und Events
				operation = 'adding'
				if preserve(FAVORIT_FILE) is not None:
					for article in preserve(FAVORIT_FILE):
						if article.get('Code') == posts.get('Code'): operation = 'skipping'
			fetch_uno = context = {'mode': 'list_categories', 'Slug': posts.get('Slug'), 'Code': posts.get('Code'), 'Sector': posts.get('Genre'), 'Limit': posts.get('Limit_2'), \
				'Wanted': posts.get('Wanted_2'), 'Extras': posts.get('Scene_2'), 'Title': posts.get('Name'), 'Plot': posts.get('Plot'), 'Genre': posts.get('Genre'), 'Image': posts.get('Photo')}
			debug_MS("-----------------------------------------------")
			debug_MS(f"(navigator.list_sports[3]) ### ACTION : {fetch_uno} || FAVORITES_HANDLE : {operation} ###")
			add_views(fetch_uno, create_entries(fetch_uno), True, context, operation, True)
		if item not in ['', None] and SCENE == 'teams' and item.get('meta', '') and str(item['meta'].get('total')).isdecimal() and int(item['meta']['total']) > int(PAGE)*int(LIMIT): # 8x50 (PAGES=8 / LIMIT=50)
			debug_MS(f"(navigator.list_sports[4]) NUMBERING ### totalRESULTS : {item['meta']['total']} || thisPAGE endet bei Eintrag : {str(int(PAGE-1)*int(LIMIT))} ###")
			debug_MS(f"(navigator.list_sports[4]) NEXTPAGES ### Zeige nächste Seiten von ... No.{PAGE} bis No.{int(PAGE)+8} ... ###")
			fetch_due = create_entries({'Title': translation(30722), 'Image': f"{artpic}nextpage.png"})
			add_views({'mode': 'list_sports', 'Link': TARGET, 'Page': PAGE, 'Limit': 50, 'Wanted': 8, 'Extras': SCENE, 'Name': SERIE}, fetch_due)
	else:
		failing(f'(navigator.list_sports) ##### NO SPORT_LIST - NO ENTRY FOR: "{TARGET}" FOUND #####')
		return dialog.notification(translation(30525), translation(30527).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def list_categories(TARGET, CODE, SECTOR, PAGE, LIMIT, WANTED, SCENE, SERIE):
	debug_MS("(navigator.list_categories) -------------------------------------------------- START = list_categories --------------------------------------------------")
	debug_MS(f"(navigator.list_categories) ### URL/SLUG = {TARGET} ### CODE = {CODE} ### GENRE = {SECTOR} ### PAGE = {PAGE} ### LIMIT = {LIMIT} ### maxPAGES = {WANTED} ### EXTRA = {SCENE} ### SERIE = {SERIE} ###")
	PAGE, LIMIT, MAXIMUM = int(PAGE), int(LIMIT), int(PAGE)+int(WANTED)
	members, combo_pages, combo_lives, combo_asset, combo_protop, combo_lasts = ([] for _ in range(6))
	unikat, (meter, found) = set(), (0 for _ in range(2))
	if SCENE == 'profiles': # Nur ein Verein
		overview = [config['TEAM_STARTS'].format(CODE), config['TEAM_ASSETS'].format(CODE), config['TEAM_TOPS'].format(CODE)]
	elif SCENE == 'tags': # Nur eine Sportart
		overview = [config['TAGS_STARTS'].format(CODE), config['TAGS_ASSETS'].format(CODE), config['TAGS_PROFILE'].format(CODE)]
	for choose in overview: # livenext: 4x50, assets: 8x50, top-assets: 8x50, profiles: 8x50
		HIGHEST = 5 if 'livestreams' in choose else MAXIMUM
		for ii in range(PAGE, HIGHEST, 1):
			meter += 1
			pages_link = f"{choose}page={str(ii)}&per_page={str(LIMIT)}"
			debug_MS(f"(navigator.list_categories[1]) CATEGORY-PAGES XXX POS = {meter} || LINK = {pages_link} XXX")
			combo_pages.append({'Count_1': int(meter), 'Link_1': pages_link})
	if combo_pages:
		complete = track_several(combo_pages, 'GET', 'JSON', WEB_HEADER)
		debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
		if complete:
			for item in sorted(json.loads(complete), key=lambda pn: int(pn.get('Position', 0))):
				if item not in ['', None] and item.get('Status', 'OOKAY') != 'ERROR' and item.get('data', '') and len(item['data']) > 0:
					number_uno, link_uno = item['Position'], item['Demand']
					if 'livestreams' in link_uno:
						pos_uno, orig_uno, all_live, count_uno, dead_live, free_live, pay_live, free_next, pay_next, LPID, LCAT = get_mumeros(item, 'livestreams', number_uno, link_uno)
						combo_lives.append([pos_uno, orig_uno, all_live, count_uno, dead_live, free_live, pay_live, free_next, pay_next, LPID, LCAT])
					if '/assets' in link_uno:
						pos_due, orig_due, all_ass, count_due, dumy_1, free_ass, pay_ass, dumy_2, dumy_3, APID, ACAT = get_mumeros(item, '/assets', number_uno, link_uno)
						combo_asset.append([pos_due, orig_due, all_ass, count_due, dumy_1, free_ass, pay_ass, dumy_2, dumy_3, APID, ACAT])
					if '/top-assets' in link_uno or '/profiles?' in link_uno:
						design = '/top-assets' if '/top-assets' in link_uno else '/profiles'
						pos_tre, orig_tre, all_top, count_tre, dumy_4, free_top, pay_top, dumy_5, dumy_6, TPID, TCAT = get_mumeros(item, design, number_uno, link_uno)
						combo_protop.append([pos_tre, orig_tre, all_top, count_tre, dumy_4, free_top, pay_top, dumy_5, dumy_6, TPID, TCAT])
	if combo_lives or combo_asset or combo_protop:
		score_live, score_next, score_asse, score_tops = (0 for _ in range(4))
		if combo_lives:
			live_all, one_count, live_dead, live_free, live_pay, next_free, next_pay = combo_lives[0][2], charge(3, combo_lives), \
				charge(4, combo_lives), charge(5, combo_lives), charge(6, combo_lives), charge(7, combo_lives), charge(8, combo_lives)
			score_live = (one_count - sum([live_dead, live_pay, next_free, next_pay])) if live_all > one_count else (live_free - live_dead)
			score_next = (one_count - sum([live_free, live_pay, next_pay])) if live_all > one_count else next_free
			if score_live >= 1: members += ['livestream']
			elif score_next >= 1: members += ['upcoming']
		if combo_asset:
			ass_all, ass_free, ass_pay = combo_asset[0][2], charge(5, combo_asset), charge(6, combo_asset)
			score_asse = (ass_all - ass_pay) if ass_all > sum([ass_free, ass_pay]) else ass_free
			if score_asse >= 1: members += ['latest']
		if combo_protop and SCENE == 'profiles':
			top_all, top_free, top_pay = combo_protop[0][2], charge(5, combo_protop), charge(6, combo_protop)
			score_tops = (top_all - top_pay) if top_all > sum([top_free, top_pay]) else top_free
			if score_tops >= 1: members += ['highlights']
		if combo_protop and SCENE == 'tags' and combo_protop[0][2] >= 1: members += ['sporttypes']
		for (aim_uno, aim_due, aim_tre) in zip_longest(combo_lives, combo_asset, combo_protop, fillvalue=['LIST_MISSING']):
			if (len(aim_uno) > 3 and 'page=1' in aim_uno[1]) or (len(aim_due) > 3 and 'page=1' in aim_due[1]) or (len(aim_tre) > 3 and 'page=1' in aim_tre[1]):
				debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++") # Liste1 = aim_uno[0]:aim_uno[9] || Liste2 = aim_due[0]:aim_due[9] || Liste3 = aim_tre[0]:aim_tre[9]
				debug_MS(f"(navigator.list_categories[2]) ### Anzahl = {len(aim_uno+aim_due+aim_tre)} || Eintrag : {str(aim_uno+aim_due+aim_tre)} || Members : {members} ###")
				'''
				Liste-1.1 = pos_uno, orig_uno, all_live, count_uno, dead_live, free_live, pay_live, free_next, pay_next, LPID, LCAT = aim_uno[0], aim_uno[1], aim_uno[2], aim_uno[3], aim_uno[4], aim_uno[5], aim_uno[6], aim_uno[7], aim_uno[8], aim_uno[9]
				Liste-2.1 = pos_due, orig_due, all_ass, count_due, dumy_1, free_ass, pay_ass, dumy_2, dumy_3, APID, ACAT = aim_due[0], aim_due[1], aim_due[2], aim_due[3], aim_due[4], aim_due[5], aim_due[6], aim_due[7], aim_due[8], aim_due[9]
				Liste-3.1 = pos_tre, orig_tre, all_top, count_tre, dumy_4, free_top, pay_top, dumy_5, dumy_6, TPID, TCAT = aim_tre[0], aim_tre[1], aim_tre[2], aim_tre[3], aim_tre[4], aim_tre[5], aim_tre[6], aim_tre[7], aim_tre[8], aim_tre[9]
				'''
				for records in members:
					categor = SERIE if SERIE != "" else aim_uno[9] if records in ['livestream', 'upcoming'] else aim_due[9] if records == 'latest' else aim_tre[9]
					totales = aim_uno[2] if records in ['livestream', 'upcoming'] else aim_due[2] if records == 'latest' else aim_tre[2]
					booklet = next((pt.get('title') for pt in config['mount'] if pt.get('turn') == records), 'UNKNOWN')
					suffix = score_live if records == 'livestream' else score_next if records == 'upcoming' else \
						score_asse if records == 'latest' else score_tops if records == 'highlights' else aim_tre[2] if records == 'sporttypes' else None
					if suffix is None: continue
					title_one, title_two = translation(30731).format(booklet+categor, suffix), booklet+categor
					thumb = next((f"{artpic}{pm.get('turn')}.png" for pm in config['mount'] if pm.get('turn') == records and xbmcvfs.exists(f"{artpic}{pm.get('turn')}.png")), icon)
					if records == 'livestream' and score_live >= 1:
						found += 1
						newDEM, newLIMIT, newWANTED, newSCENE, newPID, newCAT = f"{aim_uno[1].split('?')[0]}?", 50, 4, 'playlive', aim_uno[8], aim_uno[9]
						title_one = translation(30732).format(title_one)
						descript = translation(30733).format(suffix)
					elif records == 'upcoming' and score_next >= 1:
						found += 1
						newDEM, newLIMIT, newWANTED, newSCENE, newPID, newCAT = f"{aim_uno[1].split('?')[0]}?", 50, 4, 'playnext', aim_uno[8], aim_uno[9]
						title_one = translation(30734).format(title_one)
						descript = translation(30735).format(categor, suffix)
					elif records in ['latest', 'highlights'] and (score_asse >= 1 or score_tops >= 1):
						found += 1
						(NEW_URL, newPID, newCAT) = (aim_due[1], aim_due[8], aim_due[9]) if records == 'latest' else (aim_tre[1], aim_tre[8], aim_tre[9])
						newDEM, newLIMIT, newWANTED, newSCENE = f"{NEW_URL.split('?')[0]}?", 50, 8, 'tags'
						descript = translation(30736).format(categor, suffix) if records == 'latest' else translation(30737).format(categor, suffix)
					elif records == 'sporttypes':
						found += 1
						newDEM, newLIMIT, newWANTED, newSCENE, newPID, newCAT = f"{aim_tre[1].split('?')[0]}?", 50, 8, 'teams', aim_tre[8], aim_tre[9]
						descript = translation(30738).format(categor, suffix)
					debug_MS(f"(navigator.list_categories[2]) NUMBERING ### CATEGORY : {booklet+categor} ### TOTAL : {totales} ### FORFREE : {suffix} ###")
					combo_lasts.append({'Count_1': int(found), 'Code': newPID, 'Name': newCAT, 'Title_1': title_one, 'Title_2': title_two,
						'Plot': descript, 'Link_2': newDEM, 'Limit_2': newLIMIT, 'Wanted_2': newWANTED, 'Scene_2': newSCENE, 'Photo': thumb})
	if combo_lasts and found == 1:
		debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++")
		for posts in combo_lasts:
			add_views({'mode': 'blankFUNC'}, create_entries({'Title': translation(30739).format(posts.get('Title_2')), 'Genre': SECTOR, 'Image': posts.get('Photo')}), False)
			if 'livestreams' in posts.get('Link_2') or 'assets' in posts.get('Link_2'):
				debug_MS("(navigator.list_categories[3]) ----- NUR EIN EINTRAG GEFUNDEN - gehe direkt zu = list_videos -----")
				return list_videos(posts.get('Link_2'), SECTOR, 1, posts.get('Limit_2'), 0, 0, posts.get('Wanted_2'), posts.get('Scene_2'))
			else:
				debug_MS("(navigator.list_categories[3]) ----- NUR EIN EINTRAG GEFUNDEN - gehe direkt zu = list_sports -----")
				return list_sports(posts.get('Link_2'), posts.get('Code'), SECTOR, 1, posts.get('Limit_2'), posts.get('Wanted_2'), posts.get('Scene_2'), posts.get('Name'))
	elif combo_lasts and found >= 2:
		debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++")
		for posts in combo_lasts:
			action = {'Link': posts.get('Link_2'), 'Sector': SECTOR, 'Limit': posts.get('Limit_2'), 'Wanted': posts.get('Wanted_2'), 'Extras': posts.get('Scene_2')}
			fetch_items = create_entries({'Title': posts.get('Title_1'), 'Plot': posts.get('Plot'), 'Genre': SECTOR, 'Image': posts.get('Photo')})
			if 'livestreams' in posts.get('Link_2'): # Alle Ordner mit LiveNext-Videos
				add_views({**action, **{'mode': 'list_videos'}}, fetch_items)
			if 'assets' in posts.get('Link_2'): # Alle Ordner mit VOD-Videos
				add_views({**action, **{'mode': 'list_videos'}}, fetch_items)
			if '/profiles?' in posts.get('Link_2'): # Alle Sportarten oder Vereine und Events
				add_views({**action, **{'mode': 'list_sports', 'Code': posts.get('Code'), 'Name': posts.get('Name')}}, fetch_items)
			title_short = re.sub(r'\[.*?\]', '', posts.get('Title_1'))
			debug_MS(f"(navigator.list_categories[3]) ### NAME : {title_short} || LINK : {posts.get('Link_2')} || TYPE : {posts.get('Scene_2')} || PHOTO : {posts.get('Photo')} ###")
	else:
		failing(f'(navigator.list_categories) ##### NO CATEGORIES_LIST - NO ENTRY FOR: "{SERIE}" FOUND #####')
		return dialog.notification(translation(30525), translation(30527).format(SERIE), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_euro(SCENE):
	debug_MS("(navigator.search_euro) ------------------------------------------------ START = search_euro -----------------------------------------------")
	keyword = preserve(SEARCH_FILE, 'TEXT')
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30751).format(SCENE), type=xbmcgui.INPUT_ALPHANUM, autoclose=15000)
		if keyword: preserve(SEARCH_FILE, 'TEXT', keyword)
	if keyword and SCENE == 'PROFILE': return list_sports(config['SEARCH_PROFILE'].format(keyword), '', 'Sport', 1, 40, 10, 'teams', 'Profilsuche')
	elif keyword and SCENE == 'VIDEOS': return list_videos(config['SEARCH_VIDEO'].format(keyword), 'Sport', 1, 40, 0, 0, 5, 'playnext')
	return None

def list_videos(TARGET, SECTOR, PAGE, LIMIT, POS, KICKED, WANTED, SCENE):
	debug_MS("(navigator.list_videos) -------------------------------------------------- START = list_videos --------------------------------------------------")
	debug_MS(f"(navigator.list_videos) ### URL = {TARGET} ### GENRE = {SECTOR} ### PAGE = {PAGE} ### LIMIT = {LIMIT} ### POSITION = {POS} ### EXCLUDED = {KICKED} ### maxPAGES = {WANTED} ### SCENE = {SCENE} ###")
	counter_due, exclude_due, PAGE, MAXIMUM = int(POS), int(KICKED), int(PAGE), int(PAGE)+int(WANTED)
	tables, unikat, (counter_uno, exclude_uno, number_uno, found) = None, set(), (0 for _ in range(4))
	combo_pages, primodo, combo_links, secondo, sending = ([] for _ in range(5))
	for ii in range(PAGE, MAXIMUM, 1):
		PAGE += 1
		pages_link = f"{TARGET}page={str(ii)}&per_page={str(LIMIT)}"
		debug_MS(f"(navigator.list_videos[1]) VIDEO-PAGES XXX POS : {str(ii)} || LINK : {pages_link} XXX")
		combo_pages.append({'Count_1': int(ii), 'Link_1': pages_link})
	if combo_pages:
		complete = track_several(combo_pages, 'GET', 'JSON', WEB_HEADER)
		if complete:
			for tables in sorted(json.loads(complete), key=lambda pn: int(pn.get('Position', 0))):
				if tables not in ['', None] and tables.get('Status', 'OOKAY') != 'ERROR' and ((tables.get('data', '') and len(tables['data']) > 0) or (tables.get('assets', '') and len(tables['assets']) > 0)):
					number_first, link_first = tables['Position'], tables['Demand']
					results = tables['data'] if tables.get('data', '') and len(tables['data']) > 0 else tables['assets']
					for item in results:
						start_full, start_date, start_time, sortday, starting, airing, ends_date, tags, slug_uno, teas_uno, notiz = (None for _ in range(11))
						(genre, prefix_uno, desc_uno), (next_on, runs_on, living), branch = ("" for _ in range(3)), (False for _ in range(3)), 'sport'
						#log(f"(navigator.list_videos[2]) xxxxx ITEM-02 : {item} xxxxx")
						counter_uno, counter_due = counter_uno.__add__(1), counter_due.__add__(1)
						uuid_uno = item.get('id', None)
						if uuid_uno is None or uuid_uno in unikat:
							exclude_uno, exclude_due = exclude_uno.__add__(1), exclude_due.__add__(1)
							continue
						unikat.add(uuid_uno)
						title_uno = cleaning(item['name'])
						if str(item.get('content_start_date'))[:10].replace('.', '').replace('-', '').replace('/', '').isdecimal():
							local_start = convert_region(item['content_start_date']) # 2024-05-10T17:15:18.000000Z
							start_full = local_start.strftime('%a{0} %d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
							for tt in (('Mon', translation(32101)), ('Tue', translation(32102)), ('Wed', translation(32103)), ('Thu', translation(32104)), \
								('Fri', translation(32105)), ('Sat', translation(32106)), ('Sun', translation(32107))): start_full = start_full.replace(*tt)
							start_date = local_start.strftime('%d.%m.%Y')
							start_time = local_start.strftime('%H:%M')
							if datetime.now() < local_start - timedelta(minutes=15): next_on, runs_on = True, False # 19:44 < 20:00-15m = 19:45
							if datetime.now() > local_start - timedelta(minutes=15): next_on, runs_on = False, True # 19:46 > 20:00-15m = 19:45
							if datetime.now() > local_start + timedelta(hours=12): next_on, runs_on = False, False # 22:00 > 09:45+12h = 21:45
							sortday = local_start.strftime('%Y.%m.%dT%H:%M')
							starting = local_start.strftime('%Y-%m-%dT%H:%M') if KODI_BUILD >= 20 else local_start.strftime('%d.%m.%Y') # 2023-03-09T12:30:00 = NEWFORMAT // 09.03.2023 = OLDFORMAT
							airing = local_start.strftime('%d.%m.%Y') # FirstAired
						if str(item.get('content_end_date'))[:10].replace('.', '').replace('-', '').replace('/', '').isdecimal():
							local_ends = convert_region(item['content_end_date']) # 2024-05-10T20:00:18.000000Z
							ends_date = local_ends.strftime('%d.%m.%YT%H:%M')
							if datetime.now() > local_ends + timedelta(minutes=15): # 22:30 > 22:00+15m = 22:15
								next_on, runs_on = False, False
						else:
							if item.get('currently_live', '') is False and runs_on is True:
								runs_on = False
						img_cid = (item.get('image_url', None) or item.get('image_id', None))
						thumb_uno = IMG_VODS.format(img_cid) if img_cid else None
						if 'search/assets' in TARGET and (runs_on is True or next_on is True):
							exclude_uno, exclude_due = exclude_uno.__add__(1), exclude_due.__add__(1)
							continue # In der Suchfunktion die live+kommenden Spiele herausfiltern
						if str(item.get('price_in_cents')).isdecimal() or len([euro for euro in item.get('monetizations', '')]) > 0:
							exclude_uno, exclude_due = exclude_uno.__add__(1), exclude_due.__add__(1)
							continue
						if (item.get('currently_live', '') is True and SCENE in ['playnext', 'tags']) or (item.get('currently_live', '') is False and SCENE == 'playlive'):
							exclude_uno, exclude_due = exclude_uno.__add__(1), exclude_due.__add__(1)
							continue
						name_uno = f"{start_date} - {title_uno}" if start_date else title_uno
						if item.get('currently_live', '') is True and runs_on is True and start_time:
							name_uno, living = translation(30761).format(start_time, title_uno), True
						if item.get('display_tags', '') and len(item['display_tags']) > 0:
							tags = '[CR]'.join(sorted([og.get('name', '') for og in item.get('display_tags', [])][:3]))
						teas_uno = (item.get('description', None) or item.get('teaser', None))
						if teas_uno: desc_uno = cleaning(teas_uno, True).replace('\n', '[CR]')
						if item.get('profile', ''):
							short = item['profile']
							desc_uno = cleaning(short['description'], True).replace('\n', '[CR]') if teas_uno is None and short.get('description', '') else desc_uno
							slug_uno = short.get('slug', None)
							branch = cleaning(short['sport_type']['name']) if short.get('sport_type', '') and short['sport_type'].get('name', '') else 'sport'
						genre = SECTOR if branch == 'sport' and branch.lower() != SECTOR.lower() else branch.title()
						slug_due = item.get('slug', None)
						if (runs_on is True or next_on is True) and start_full and tags: # Datum, Uhrzeit und Tags
							notiz = translation(30762).format(title_uno, cleaning(tags), start_full)
						if notiz is None and (runs_on is True or next_on is True) and start_full and tags is None: # Datum, Uhrzeit KEINE Tags
							notiz = translation(30763).format(title_uno, start_full)
						if notiz is None and start_date and tags: # Einfaches Datum und Tags
							notiz = translation(30764).format(title_uno, cleaning(tags), start_date)
						if notiz is None and start_date and tags is None: # Einfaches Datum KEINE Tags
							notiz = translation(30765).format(title_uno, start_date)
						if notiz: prefix_uno = notiz
						number_uno += 1
						primodo.append({'Count_1': int(number_uno), 'Code_1': uuid_uno, 'Title': title_uno, 'Name': name_uno, 'Prefix': prefix_uno,
							'Teaser_1': desc_uno, 'Sorting': sortday, 'Date': starting, 'Aired': airing, 'Genre': genre, 'Thumb_1': thumb_uno, 'Livestream': living})
						combo_links.append({'Count_1': int(number_uno), 'Link_1': config['PLAY_MUXO'].format(uuid_uno)})
	if primodo:
		package = track_several(combo_links, 'GET', 'JSON', MUX_HEADER)
		debug_MS("═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═ ═")
		if package:
			for elem in json.loads(package):
				if elem not in ['', None] and elem.get('Status', 'OOKAY') != 'ERROR' and not elem.get('error', ''):
					number_due, link_due = elem['Position'], elem['Demand']
					(stream, norm, dura_due, thumb_due), desc_due = (None for _ in range(4)), ""
					#log(f"(navigator.list_videos[3]) xxxxx ELEM-03 : {str(elem)} xxxxx")
					uuid_due = (elem.get('uuid', '') or elem.get('id', ''))
					if elem.get('tracks', '') and 'sources' in str(elem['tracks']):
						for track in elem.get('tracks', []):
							if track.get('is_primary', True) is True:
								stream = next((src.get('hls').split('.m3u8')[0]+'.m3u8' for src in track.get('sources', {})), None)
								dura_due = next((int(src.get('duration')) for src in track.get('sources', {}) if str(src.get('duration')).isdecimal()), None)
						norm = elem.get('type', 'UNKNOWN')
					if dura_due in [0, None] and str(elem.get('duration_in_seconds')).isdecimal():
						dura_due = int(elem['duration_in_seconds'])
					if elem.get('images', '') and 'src' in str(elem['images']):
						thumb_due = elem['images'][-1]['src']
					teas_due = (elem.get('description', None) or elem.get('teaser', None))
					if teas_due: desc_due = cleaning(teas_due, True).replace('\n', '[CR]')
					elif teas_due is None and elem.get('home_team', '') and elem['home_team'].get('name', '') and elem.get('guest_team', '') and elem['guest_team'].get('name', ''):
						desc_due = f"{cleaning(elem['home_team']['name'])} vs. {cleaning(elem['guest_team']['name'])}"
					secondo.append({'Count_2': int(number_due), 'Code_2': uuid_due, 'Link': link_due, 'Teaser_2': desc_due,
						'Duration': dura_due, 'Thumb_2': thumb_due, 'Muxing': norm, 'Playing': stream})
				else:
					exclude_uno, exclude_due = exclude_uno.__add__(1), exclude_due.__add__(1)
		merging = [{**uno, **next(iter([due for due in secondo if due.get('Code_2') == uno.get('Code_1')]), {})} for uno in primodo] # Merge List1 and List2 (dictionaries) by specific value if value exists else only List1 !!!
		if '/playlists' in TARGET or 'search/assets' in TARGET:
			merging = sorted(merging, key=lambda asx: asx.get('Sorting', '2026.01.01T00:01')[:16], reverse=True)
		else: merging = sorted(merging, key=lambda asx: int(asx.get('Count_1', 0)))
		for riders in merging: # 0-11 = Liste1 || 12-19 = Liste2
			debug_MS(f"(navigator.list_videos[2]) ##### Anzahl = {len(riders)} || Eintrag : {riders} #####")
			if SCENE == 'tags' and riders.get('Playing') is None and str(riders.get('Duration')) == '0': continue
			found += 1
			name = riders.get('Name')
			description = riders['Teaser_2'] if riders.get('Teaser_2') and len(riders['Teaser_2']) > 60 else riders.get('Teaser_1')
			plot = riders.get('Prefix')+description
			photo = (riders.get('Thumb_2') or riders.get('Thumb_1'))
			debug_MS(f"(navigator.list_videos[2]) ##### POS : {riders.get('Count_1')} || NAME : {name} || MEDIA_IDD : {riders.get('Code_1')} || TYPE : {riders.get('Muxing')} || GENRE : {riders.get('Genre')} #####")
			debug_MS(f"(navigator.list_videos[2]) ##### STREAM : {riders.get('Playing')} || DURATION : {riders.get('Duration')} || THUMB : {photo} #####")
			debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
			fetch_items = {'Title': name,'Plot': plot, 'Duration': riders.get('Duration'), 'Date': riders.get('Date'), 'Aired': riders.get('Aired'), \
				'Genre': riders.get('Genre'), 'Mediatype': 'movie', 'Image': photo, 'Fanback': photo, 'Reference': 'Single'}
			add_views({'mode': 'play_video', 'Link': riders.get('Code_1')}, create_entries(fetch_items), False, higher=True)
			sending.append({'filtrate': riders.get('Code_1'), 'name': name, 'photo': photo, 'plot': plot, 'genre': riders.get('Genre'), \
				'coding': config['PLAY_MUXO'].format(riders.get('Code_1')), 'muxing': riders.get('Muxing'), 'living': riders.get('Livestream')})
		preserve(WORKS_FILE, 'JSON', sending)
		debug_MS(f"(navigator.list_videos[3]) NUMBERING ### current_RESULT : {counter_uno} || all_RESULT : {counter_due} ### current_EXCLUDED : {exclude_uno} || all_EXCLUDED : {exclude_due} ###")
	if found == 0:
		failing(f'(navigator.list_videos) ##### NO VIDEO_LIST - NO ENTRY FOR: "{TARGET}" FOUND #####')
		return dialog.notification(translation(30525), translation(30526), icon, 10000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, cacheToDisc=False)

def play_video(PLID):
	debug_MS("(navigator.play_video) -------------------------------------------------- START = play_video --------------------------------------------------")
	debug_MS(f"(navigator.play_video) ### SOURCE_CODE = {PLID} ###")
	checking, stream_works, (play_link, play_type, final_tests, final_works) = 0, 'HLS'if enable_adaptive else 'M3U8', (False for _ in range(4))
	for elem in preserve(WORKS_FILE):
		if elem['filtrate'] != '00' and elem['filtrate'] == PLID:
			clear_title, photo, plot, genre, play_link, play_type, now_live = re.sub(r'(\[/?B\])', '', elem['name']), elem['photo'], \
				' ' if elem['plot'] in ['', 'None', None] else elem['plot'], elem['genre'], elem['coding'], elem['muxing'], elem['living']
			debug_MS(f"(navigator.play_video[1]) ### WORKS_FILE-Line : {elem} ###")
	if play_link:
		debug_MS("~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~")
		verify = track_content(play_link, 'GET', 'TRACK', MUX_HEADER, False, timeout=20)
		if verify.status_code > 400 and 'error' in verify.text:
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
			status, error = verify.status_code, verify.json().get('error', 'UNKNOWN')
			failing(f"(navigator.play_video[2]) ERROR - PLAYER - ERROR ##### STATUS : {status} ===\n === FAILURE : {error} #####")
			return dialog.ok(addon_id, translation(30505).format(status, error))
		elif verify.status_code in [200, 201, 202, 300, 301, 302] and not 'error' in verify.text:
			status, result = verify.status_code, verify.json()
			if result.get('tracks', '') and 'sources' in str(result['tracks']):
				for track in result.get('tracks', []):
					if track.get('is_primary', True) is True:
						final_tests = next((src.get('hls') for src in track.get('sources', {})), None)
			debug_MS(f"(navigator.play_video[2]) === STATUS : {status} === PLAY_LINK : {final_tests} ===")
	if final_tests:
		while not final_works and checking < 2: # 2 x Pingtests for the STREAM-Request ::: to check the availability of the stream
			checking += 1
			try:
				scanning = urlopen(Request(final_tests, None, {**DEFAULT_HEADERS, **{'Cache-Control': 'no-cache', 'Accept': '*/*'}}), timeout=10)
				debug_MS("-----------------------------------------------")
				debug_MS(f"(navigator.play_video[3]) === CALL_{stream_works}_STREAM === RETRIES_no : {checking} === STATUS : {scanning.getcode()} || URL : {final_tests} ===")
			except (URLError, HTTPError) as exo:
				failing("-----------------------------------------------")
				failing(f"(navigator.play_video[3]) ERROR - {stream_works}_STREAM - ERROR ##### RETRIES_no : {checking} === URL : {final_tests} === FAILURE : {exo} #####")
				time.sleep(2)
			else: final_works = final_tests
		if final_works is False:
			xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
			failing("-----------------------------------------------")
			failing(f"(navigator.play_video[4]) ##### ABSPIELEN DES STREAMS NICHT MÖGLICH #####\n ##### QUERY : {final_tests} || STREAM_CODE : {PLID} #####\n ##### DIE VORHANDENEN STREAM-EINTRÄGE AUF DER WEBSEITE VON *Sporteurope.tv* SIND OFFLINE/DEFEKT !!! #####")
			return dialog.notification(translation(30521).format('URL-2'), translation(30528), icon, 10000)
	else:
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
		failing("-----------------------------------------------")
		failing(f"(navigator.play_video[3]) ##### ABSPIELEN DES STREAMS NICHT MÖGLICH #####\n ##### QUERY : {play_link} || STREAM_CODE : {PLID} #####\n ##### KEINEN STREAM-EINTRAG AUF DER WEBSEITE VON *Sporteurope.tv* GEFUNDEN !!! #####")
		return dialog.notification(translation(30521).format('URL-1'), translation(30529), icon, 10000)
	if final_works:
		LPM = xbmcgui.ListItem(clear_title, path=final_works, offscreen=True)
		if KODI_BUILD >= 20:
			LPM.getVideoInfoTag().setTitle(clear_title), LPM.getVideoInfoTag().setPlot(plot), LPM.getVideoInfoTag().setGenres([genre])
		else: LPM.setInfo('Video', {'Title': clear_title, 'Plot': plot, 'Genre': genre})
		LPM.setArt({'icon': icon, 'thumb': photo, 'poster': photo})
		if enable_adaptive and plugin_operate('inputstream.adaptive') and stream_works in ['HLS', 'M3U8']:
			IA_NAME = 'inputstream.adaptive'
			IA_VERSION = re.sub(r'(~[a-z]+(?:.[0-9]+)?|\+[a-z]+(?:.[0-9]+)?$|[.^]+)', '', xbmcaddon.Addon(IA_NAME).getAddonInfo('version'))[:4]
			LPM.setMimeType('application/x-mpegurl'); LPM.setContentLookup(False); LPM.setProperty('inputstream', IA_NAME)
			if KODI_BUILD in [19, 20]: LPM.setProperty(f"{IA_NAME}.manifest_type", 'hls') # DEPRECATED ON Kodi v21, because the manifest type is now auto-detected.
			PHRASE = 'stream' if KODI_BUILD == 19 else 'manifest' if KODI_BUILD in [20, 21] else 'common'
			LPM.setProperty(f"{IA_NAME}.{PHRASE}_headers", f"User-Agent={WEB_AGENT}") # 'stream_headers' ON KODI v19 // 'manifest_headers' ON KODI v20 and v21 // 'common_headers' ON KODI v22 and above
			if int(IA_VERSION) >= 2150 and stream_works == 'HLS':
				LPM.setProperty(f"{IA_NAME}.drm_legacy", 'org.w3.clearkey')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LPM)
		debug_MS("+++++++++++++++++++++++++++++++++++++++++++++++")
		log(f"(navigator.play_video) {stream_works}_stream : {final_works}")

def list_favorites():
	debug_MS("(navigator.list_favorites) -------------------------------------------------- START = list_favorites -----------------------------------------------")
	if preserve(FAVORIT_FILE) is not None: # Favoriten für Profile/Vereine
		for each in sorted(preserve(FAVORIT_FILE), key=lambda vox: (vox.get('Extras', 'Zorro'), clear_umlaut(vox.get('Title', 'zorro')).lower())):
			fetch_items = context = {'mode': 'list_categories', 'Slug': each.get('Slug'), 'Code': each.get('Code'), 'Section': each.get('Section', 'Sport'), 'Limit': each.get('Limit'), \
				'Wanted': each.get('Wanted'),'Extras': each.get('Extras'), 'Title': cleaning(each.get('Title')), 'Plot': cleaning(each.get('Plot')), 'Genre': each.get('Section', 'Sport'), 'Image': each.get('Image')}
			debug_MS(f"(navigator.list_favorites[1]) ### NAME : {cleaning(each.get('Title'))} || SLUG : {each.get('Slug')} || THUMB : {each.get('Image')} ###")
			add_views(fetch_items, create_entries(fetch_items), True, context, 'removing')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def favorit_construct(**kwargs):
	TOPS = []
	if preserve(FAVORIT_FILE) is not None:
		TOPS = preserve(FAVORIT_FILE)
	if kwargs['action'] == 'ADD':
		kwargs.pop('mode', None); kwargs.pop('action', None); kwargs.pop('Genre', None)
		TOPS.append({key: value for key, value in kwargs.items() if value not in ['', 'None', None]})
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.sleep(500)
		dialog.notification(translation(30530), translation(30531).format(kwargs['Title']), icon, 10000)
	elif kwargs['action'] == 'DEL':
		TOPS = [xs for xs in TOPS if xs.get('Code') != kwargs.get('Code')]
		preserve(FAVORIT_FILE, 'JSON', TOPS)
		xbmc.executebuiltin('Container.Refresh')
		xbmc.sleep(1000)
		dialog.notification(translation(30530), translation(30532).format(kwargs['Title']), icon, 10000)

def add_views(params, listitem, folder=True, context={}, handling='default', higher=False):
	uws, entries = build_mass(params), []
	listitem.setPath(uws)
	if enable_decrease and higher is True:
		entries.append([translation(30650), f"RunPlugin({build_mass({'mode': 'calling_main'})})"])
	if handling == 'adding' and context:
		entries.append([translation(30651), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'ADD'}})})"])
	if handling == 'removing' and context:
		entries.append([translation(30652), f"RunPlugin({build_mass({**context, **{'mode': 'favorit_construct', 'action': 'DEL'}})})"])
	if len(entries) > 0: listitem.addContextMenuItems(entries)
	return xbmcplugin.addDirectoryItem(ADDON_HANDLE, uws, listitem, folder)
