﻿# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcaddon


def translation(ident):
	return xbmcaddon.Addon().getLocalizedString(ident)

class Client(object):
	CONFIG_SPORTEUROPE = {
		'SPORT_TYPES': 'https://api.sporteurope.tv/api/frontend/public/menu/sport-types?',
		'SPORT_PROFILE': 'https://search.sporteurope.tv/api/v1/profiles/popular?',
		'HOME_STARTS': 'https://api.sporteurope.tv/api/web/public/next-livestreams?',
		'TAGS_STARTS': 'https://api.sporteurope.tv/api/web/public/tags/{}/next-livestreams?',
		'TEAM_STARTS': 'https://api.sporteurope.tv/api/web/public/profiles/{}/next-livestreams?',
		'HOME_TOPS': 'https://api.sporteurope.tv/api/web/public/top-profiles?',
		'TAGS_TOPS': 'https://api.sporteurope.tv/api/web/public/tags/{}/top-assets?',
		'TEAM_TOPS': 'https://api.sporteurope.tv/api/web/public/profiles/{}/top-assets?',
		'HOME_ASSETS': 'https://api.sporteurope.tv/api/frontend/public/playlists/97515a13-c5b4-4870-b8aa-ce1d963aae09?',
		'TAGS_ASSETS': 'https://api.sporteurope.tv/api/web/public/tags/{}/assets?',
		'TEAM_ASSETS': 'https://api.sporteurope.tv/api/web/public/profiles/{}/assets?',
		'TAGS_PROFILE': 'https://api.sporteurope.tv/api/web/public/tags/{}/profiles?',
		'SEARCH_PROFILE': 'https://search.sporteurope.tv/api/v1/search/profiles?q={}&',
		'SEARCH_VIDEO': 'https://search.sporteurope.tv/api/v1/search/assets?q={}&',
		'VIDEO_INFO': 'https://api.sporteurope.tv/api/web/public/assets/{}',
		'PLAY_MUXO': 'https://api.sporteurope.tv/api/web-player/personal/assets/{}',
		'mount': [
		{
			'title': translation(30621),
			'turn': 'livestream',
			'code': 11
		},
		{
			'title': translation(30622),
			'turn': 'upcoming',
			'code': 12
		},
		{
			'title': translation(30623),
			'turn': 'latest',
			'code': 13
		},
		{
			'title': translation(30624),
			'turn': 'highlights',
			'code': 14
		},
		{
			'title': translation(30625),
			'turn': 'sporttypes',
			'code': 15
		}],
	}

	def __init__(self, config):
		self._config = config

	def get_config(self):
		return self._config
