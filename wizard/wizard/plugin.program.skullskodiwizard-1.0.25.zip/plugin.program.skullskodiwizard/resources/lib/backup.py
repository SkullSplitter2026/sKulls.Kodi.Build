# -*- coding: utf-8 -*-
"""
Backup / Restore: Kodi-Einrichtung (ganz oder teilweise) als ZIP mit SHA-256 daneben sichern und zurückspielen.
Beim Zurückspielen wird die Prüfsumme kontrolliert und wie bei einer Build-Installation erst komplett entpackt.

Ein kompletter Build (auch ein geparkter) wird 1:1 gesichert und zurückgespielt - mit allen Anmeldungen, Passwörtern,
API-Keys und MAC-Adressen, dazu die Save Data und Einstellungen des Wizards (wizard/ in der ZIP). Kommt die Sicherung
von einem anderen System (z.B. PC -> Android), lädt der Wizard die Binär-Addons nach dem Neustart passend nach.
"""

import hashlib
import json
import os
import platform
import re
import shutil
import struct
import time
import zipfile

from resources.lib import builds, savedata
from resources.lib.common import (ADDON_DATA, ADDON_ID, ADDONS, DATA, HOME, STAGE, USERDATA, human_size, jsonrpc,
                                  load_state, log, save_state)
from resources.lib.texts import T

KINDS = {
    "full": "Kompletter Build",
    "full_nodata": "Kompletter Build ohne Addon-Daten",
    "addons": "Nur Addons (ohne Daten)",
    "addons_data": "Addons mit ihren Daten",
    "data": "Nur Daten (Einstellungen, Addon-Daten, Favoriten)",
    "addon_data": "Addon-Daten und Einstellungen",
    "gui": "Nur Oberfläche (GUI)",
    "favourites": "Favoriten und Quellen",
}
SKIP_DIRS = {"packages", "Thumbnails", "temp", "cache", ".sk_stage", ADDON_ID}
SKIP_FILES = ("kodi.log", "kodi.old.log")
FULL_KINDS = ("full", "park")       # komplette Einrichtung - nichts wird weggelassen außer Kodis Zwischenspeichern
# Addon-Caches kommen bei Komplett-Backups mit (manche Addons legen dort ihre Anmelde-Tokens ab)
FULL_SKIP = {"addons/packages", "addons/temp", "userdata/Thumbnails"}
META = "wizard"                      # Wizard-Teil eines Komplett-Backups: settings.json + savedata/
# gehören zu diesem Gerät bzw. zum Ablauf - werden beim Zurückspielen nicht aus dem Backup übernommen
LOCAL_KEYS = {"backup_folder", "parked", "auto_backups", "selfcheck", "binaries_pending", "binaries_tries", "local_gui",
              "enable_all_pending", "last_update_check", "last_maintenance", "last_autobackup", "notify_seen", "recent",
              "keep_disabled", "old_files", "replace_after_exit", "rss_applied", "rss_previous"}
NAME = re.compile(r"^kodi_(.+)_(\d{4}-\d{2}-\d{2})_(\d{2}-\d{2}(?:-\d{2})?)\.zip$")   # kodi_<art>_<datum>_<uhrzeit>.zip


def folder():
    path = load_state().get("backup_folder") or os.path.join(DATA, "backups")
    os.makedirs(path, exist_ok=True)
    return path


def _files(kind):
    if kind == "favourites":
        for name in ("favourites.xml", "sources.xml", "passwords.xml", "mediasources.xml"):
            path = os.path.join(USERDATA, name)
            if os.path.isfile(path):
                yield path
        return
    if kind == "gui":
        roots = [os.path.join(USERDATA, "guisettings.xml"), os.path.join(USERDATA, "keymaps")]
        roots += [os.path.join(ADDON_DATA, a) for a in os.listdir(ADDON_DATA) if a.startswith("skin.")]
    elif kind == "addon_data":
        roots = [ADDON_DATA]
    elif kind == "addons":
        roots = [ADDONS]
    elif kind == "addons_data":
        roots = [ADDONS, ADDON_DATA]
    elif kind == "data":
        roots = [USERDATA]
    else:
        roots = [ADDONS, USERDATA]
    full = kind in FULL_KINDS
    for root in roots:
        if os.path.isfile(root):
            yield root
            continue
        for current, dirs, files in os.walk(root):
            if full:
                dirs[:] = [d for d in dirs if not _full_skip(os.path.relpath(current, HOME).replace(os.sep, "/"), d)]
            else:
                dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            if kind == "full_nodata" and os.path.normcase(current) == os.path.normcase(USERDATA):
                dirs[:] = [d for d in dirs if d != "addon_data"]     # Build ohne Addon-Daten
            for name in files:
                if name not in SKIP_FILES and not name.endswith((".pyo", ".pyc")):
                    yield os.path.join(current, name)


def _full_skip(parent, name):
    rel = name if parent == "." else parent + "/" + name
    if rel in FULL_SKIP or name in ("temp", ".sk_stage"):
        return True
    return name == ADDON_ID and parent in ("addons", "userdata/addon_data")    # Wizard selbst: eigener Teil (META)


def system_id():
    """System, CPU und Bitbreite dieses Kodi - Binär-Addons (PVR, Inputstream …) passen nur auf genau das"""
    import xbmc
    name = next((n for n in ("Android", "Windows", "OSX", "IOS", "TVOS", "Linux")
                 if xbmc.getCondVisibility("System.Platform." + n)), "unknown")
    return "{0}-{1}-{2}".format(name.lower(), platform.machine().lower(), struct.calcsize("P") * 8)


def _write_meta(z):
    """Save Data und Einstellungen des Wizards ins Komplett-Backup (ohne gerätebezogene Werte)"""
    state = load_state()
    off = (jsonrpc("Addons.GetAddons", {"enabled": False}) or {}).get("addons") or []
    info = {"format": 1, "wizard": ADDON_ID, "system": system_id(), "created": time.strftime("%Y-%m-%d %H:%M"),
            "binaries": builds.binary_addons(), "state": {k: v for k, v in state.items() if k not in LOCAL_KEYS},
            "disabled": sorted(a["addonid"] for a in off if a.get("addonid") and a["addonid"] != ADDON_ID)}
    z.writestr(META + "/settings.json", json.dumps(info, indent=1))
    count = 0
    for current, _dirs, files in os.walk(savedata.STORE):
        for name in files:
            path = os.path.join(current, name)
            z.write(path, META + "/savedata/" + os.path.relpath(path, savedata.STORE).replace(os.sep, "/"))
            count += 1
    return count


def create(kind="full", ui=None, name=""):
    stamp = time.strftime("%Y-%m-%d_%H-%M")
    target = os.path.join(folder(), "kodi_{0}_{1}.zip".format(kind, stamp))
    second = int(time.strftime("%S"))
    for offset in range(60):        # weiteres Backup derselben Art in derselben Minute: Sekunden anhängen
        if not os.path.exists(target):
            break
        target = os.path.join(folder(), "kodi_{0}_{1}-{2:02d}.zip".format(kind, stamp, (second + offset) % 60))
    if ui:
        ui.step("Dateien sammeln")
    files = list(_files(kind))
    digest = hashlib.sha256()
    if ui:
        ui.step(T("Packen ({0} Dateien)").format(len(files)))
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        for index, path in enumerate(files):
            try:
                z.write(path, os.path.relpath(path, HOME).replace(os.sep, "/"))
            except (OSError, ValueError):
                pass
            if ui and index % 25 == 0 and ui.update(index * 100 // max(1, len(files)), T("{0} von {1} Dateien").format(
                    index, len(files))) is False:
                z.close()
                os.remove(target)
                raise builds.BuildError("Abgebrochen")
        if kind in FULL_KINDS:
            files.extend([None] * _write_meta(z))
    if ui:
        ui.step("Prüfsumme berechnen")
    if name.strip():
        set_name(target, name)
    with open(target, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    with open(target + ".sha256", "w") as f:
        f.write(digest.hexdigest() + "  " + os.path.basename(target) + "\n")
    log("Backup erstellt: {0} ({1} Dateien)".format(target, len(files)))
    return target


AUTO_KINDS = ["full", "full_nodata", "addons_data", "data", "addon_data"]
LABELS = dict(KINDS, park="Geparkter Build")


def set_name(path, name):
    """Eigener Name eines Backups (liegt neben der ZIP, die Datei selbst behält ihren Namen)"""
    with open(path + ".name", "w", encoding="utf-8") as f:
        f.write(name.strip()[:80])


def get_name(path):
    try:
        with open(path + ".name", "r", encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""   # für die Backup-Liste (geparkt = Komplett-Backup vor einem Wechsel)


def park(current, ui=None):
    """Den installierten Build vor einem Wechsel als Komplett-Backup parken (eins je Build)"""
    path = create("park", ui)
    state = load_state()
    parked = state.setdefault("parked", {})
    old = parked.get(current["id"], {}).get("path")
    if old and old != path and os.path.isfile(old):
        delete(old)
    parked[current["id"]] = {"path": path, "name": current.get("name", current["id"]),
                             "version": current.get("version", ""), "date": time.strftime("%d.%m.%Y %H:%M"),
                             "size": os.path.getsize(path)}
    save_state(state)
    log("Build geparkt: {0} {1} -> {2}".format(current.get("name"), current.get("version"), path))
    return path


def parked(build_id):
    """Geparkter Stand eines Builds - None, wenn keiner da ist (oder die Datei gelöscht wurde)"""
    entry = load_state().get("parked", {}).get(build_id)
    return entry if entry and os.path.isfile(entry.get("path", "")) else None


def auto_backup():
    """Geplantes Backup (Dienst): erstellen und ältere automatische Backups über der eingestellten Anzahl löschen"""
    state = load_state()
    kind = state.get("autobackup_kind") if state.get("autobackup_kind") in KINDS else "addons_data"
    path = create(kind)
    keep = max(1, int(state.get("autobackup_keep") or 3))
    state = load_state()
    autos = [p for p in state.get("auto_backups", []) if os.path.isfile(p)] + [path]
    while len(autos) > keep:
        delete(autos.pop(0))
    state["auto_backups"] = autos
    state["last_autobackup"] = time.time()
    save_state(state)
    log("Automatisches Backup: {0} ({1} aufbewahrt)".format(os.path.basename(path), len(autos)))
    return path


def entries():
    """[(Pfad, Anzeige, Größe)] neueste zuerst"""
    result = []
    base = folder()
    for name in os.listdir(base):
        if name.endswith(".zip"):
            path = os.path.join(base, name)
            m = NAME.match(name)       # die Art kann selbst „_“ enthalten (addon_data)
            if m and m.group(1) in LABELS:
                label = "{0} {1} · {2}".format(m.group(2), m.group(3).replace("-", ":"), T(LABELS[m.group(1)]))
                if get_name(path):
                    label = "{0} · {1}".format(get_name(path), label)
            else:
                label = name
            result.append((path, label, os.path.getsize(path)))
    return sorted(result, key=lambda e: os.path.getmtime(e[0]), reverse=True)


def verify(path):
    sidecar = path + ".sha256"
    if not os.path.isfile(sidecar):
        return None   # ältere Sicherung ohne Prüfsumme
    with open(sidecar) as f:
        expected = f.read().split()[0].lower()
    digest = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest() == expected


def restore(path, ui, fresh=False):
    """fresh=True (kompletter Build): vorher aufräumen, sonst werden nur die Dateien aus dem Backup ersetzt"""
    ui.step("Prüfsumme kontrollieren")
    if verify(path) is False:
        raise builds.BuildError("Das Backup ist beschädigt (Prüfsumme stimmt nicht)")
    ui.step("ZIP und Speicherplatz prüfen")
    builds.check_zip(path)
    ui.step("Entpacken")
    count = builds.extract_to_stage(path, ui)
    meta = _take_meta()
    builds.last_plan.update(binaries=_foreign_binaries(meta), skipped=[])
    released = builds.release_open_files()
    try:
        if fresh:
            ui.step("Aufräumen")
            builds.wipe(keep_addon_data=os.path.basename(path).startswith("kodi_full_nodata_"))
        ui.step("Dateien übernehmen")
        errors = builds.move_stage()
    except Exception:
        builds.enable_again(released)
        raise
    if meta is not None:
        _apply_meta(meta, builds.last_plan["binaries"])
    from resources.lib import rss
    rss.reset()
    if released or _has_addons(path):     # Kodi legt Addons deaktiviert an - beim nächsten Start einschalten
        state = load_state()
        state["enable_all_pending"] = True
        save_state(state)
    log("Backup zurückgespielt: {0} ({1} Dateien, {2} Fehler)".format(path, count, errors))
    return count, errors


def _take_meta():
    """Wizard-Teil eines Komplett-Backups aus dem Zwischenordner holen, bevor die Dateien an ihren Platz kommen"""
    src = os.path.join(STAGE, META)
    if not os.path.isdir(src):
        return None
    keep = os.path.join(DATA, "restore_meta")
    shutil.rmtree(keep, ignore_errors=True)
    shutil.move(src, keep)
    try:
        with open(os.path.join(keep, "settings.json"), "r", encoding="utf-8") as f:
            info = json.load(f)
    except (OSError, ValueError):
        info = {}
    info = info if isinstance(info, dict) else {}
    info["_dir"] = keep
    return info


def _foreign_binaries(meta):
    """Backup von einem anderen System: dessen Binär-Addons passen hier nicht - aus dem Zwischenordner nehmen (ihre
    Einstellungen bleiben) und nach dem Neustart passend zu diesem Gerät laden"""
    if not meta or not meta.get("system") or meta["system"] == system_id():
        return []
    moved = []
    for addon_id in meta.get("binaries") or []:
        folder_path = os.path.join(STAGE, "addons", str(addon_id))
        if builds.ADDON_ID_TEXT.match(str(addon_id)) and os.path.isdir(folder_path):
            shutil.rmtree(folder_path, ignore_errors=True)
            moved.append(addon_id)
    if moved:
        log("Backup von {0} (hier {1}) - nach dem Neustart nachinstallieren: {2}".format(
            meta["system"], system_id(), ", ".join(moved)))
    return moved


def _apply_meta(meta, binaries):
    """Wizard-Einstellungen aus dem Backup übernehmen (gerätebezogene bleiben), fehlende Save Data ergänzen"""
    state = load_state()
    stored = meta.get("state") if meta.get("wizard") == ADDON_ID else None
    for key, value in (stored if isinstance(stored, dict) else {}).items():
        if key not in LOCAL_KEYS:
            state[key] = value
    if binaries:
        state["binaries_pending"] = sorted(set(state.get("binaries_pending") or []) | set(binaries))
        state["binaries_tries"] = 0
    state["keep_disabled"] = [a for a in meta.get("disabled") or [] if builds.ADDON_ID_TEXT.match(str(a))]
    save_state(state)
    src = os.path.join(meta["_dir"], "savedata")
    copied = 0
    for current, _dirs, files in os.walk(src):
        for name in files:
            path = os.path.join(current, name)
            target = os.path.join(savedata.STORE, os.path.relpath(path, src))
            if not os.path.exists(target):          # was hier schon gesichert ist, ist neuer
                os.makedirs(os.path.dirname(target), exist_ok=True)
                shutil.copy2(path, target)
                copied += 1
    shutil.rmtree(meta["_dir"], ignore_errors=True)
    log("Wizard-Einstellungen aus dem Backup übernommen, Save Data ergänzt: {0} Datei(en)".format(copied))


def _has_addons(path):
    try:
        with zipfile.ZipFile(path) as z:
            return any(n.replace("\\", "/").split("/", 1)[0] == "addons" for n in z.namelist())
    except (OSError, zipfile.BadZipFile):
        return False


def delete(path):
    for p in (path, path + ".sha256", path + ".name"):
        try:
            os.remove(p)
        except OSError:
            pass


def describe(path):
    return "{0} · {1}".format(os.path.basename(path), human_size(os.path.getsize(path)))
