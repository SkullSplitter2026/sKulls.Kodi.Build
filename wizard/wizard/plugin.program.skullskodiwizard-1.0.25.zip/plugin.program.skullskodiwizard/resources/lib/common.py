# -*- coding: utf-8 -*-
"""
Gemeinsame Helfer des Wizards: Pfade, Zustand (state.json), Protokoll, Texte, Kodi-JSON-RPC.
Läuft ab Kodi 19 (Python 3.8) - daher keine neueren Sprachmittel verwenden.
"""

import json
import os
import re
import time

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_VERSION = ADDON.getAddonInfo("version")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))


def translate(path):
    return xbmcvfs.translatePath(path)


HOME = translate("special://home/")
USERDATA = translate("special://userdata/")
ADDONS = os.path.join(HOME, "addons")
PACKAGES = os.path.join(ADDONS, "packages")
ADDON_DATA = os.path.join(USERDATA, "addon_data")
DATA = os.path.join(ADDON_DATA, ADDON_ID)
TEMP = translate("special://temp/")
LOGPATH = translate("special://logpath/")
DATABASE = os.path.join(USERDATA, "Database")
THUMBNAILS = os.path.join(USERDATA, "Thumbnails")
STAGE = os.path.join(HOME, ".sk_stage")          # hier wird ein Build erst vollständig entpackt
WIZARD_LOG = os.path.join(DATA, "wizard.log")

# Wartung / Update-Prüfung: Schlüssel -> (Sekunden, Text-Schlüssel)
INTERVALS = [("never", 0), ("start", -1), ("daily", 86400), ("3days", 3 * 86400), ("weekly", 7 * 86400),
             ("monthly", 30 * 86400)]

if not os.path.isdir(DATA):
    try:
        os.makedirs(DATA)
    except OSError:
        pass


# ----- Protokoll -----
def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{0}] {1}".format(ADDON_ID, message), level)
    try:
        if os.path.isfile(WIZARD_LOG) and os.path.getsize(WIZARD_LOG) > 512 * 1024:
            os.replace(WIZARD_LOG, WIZARD_LOG + ".old")
        with open(WIZARD_LOG, "a", encoding="utf-8") as f:
            f.write("{0}  {1}\n".format(time.strftime("%Y-%m-%d %H:%M:%S"), message))
    except OSError:
        pass


def log_error(message):
    log(message, xbmc.LOGERROR)


# ----- Zustand des Wizards (installierter Build, Einstellungen, Zeitpunkte) -----
STATE_FILE = os.path.join(DATA, "state.json")
DEFAULT_STATE = {
    "build": None,                 # {"id", "name", "version"} des installierten Builds
    "first_run_done": False,
    "update_interval": "daily",    # Suche nach Build-/Wizard-Updates
    "maint_interval": "weekly",    # automatische Wartung
    "maint_cache": True, "maint_packages": True, "maint_thumbs": False,
    "notifications": True,
    "backup_before_install": False,
    "backup_folder": "",
    "savedata": {"addons": True, "favourites": True, "sources": False, "profiles": False,
                 "advancedsettings": True, "whitelist": True},
    "whitelist": [],
    "last_update_check": 0, "last_maintenance": 0, "notify_seen": 0,
    "enable_all_pending": False,
    "autobackup_interval": "never", "autobackup_kind": "addons_data", "autobackup_keep": 3, "last_autobackup": 0,
    "auto_backups": [],
    "recent": [],                  # Schnellzugriff: zuletzt benutzte Wartungsaktionen
    "pin_hash": "", "pin_salt": "",
    "splash": True,
    "setup_done": False,
    "layout": "",                  # Ansicht (leer = Vorgabe aus dem Forge)
    "parked": {},                  # Build-Kennung -> geparktes Komplett-Backup
    "selfcheck": {},
    "binaries_pending": [],        # Binär-Addons, die nach dem Neustart passend zum Gerät geladen werden
    "binaries_tries": 0,
    "local_gui": "",               # GUI-Paket neben einer Build-Datei (alte Builds: <Name>_guisettings.zip)
    "keep_disabled": [],           # aus einem Komplett-Backup: nach dem Einschalten wieder aus
    "old_files": [],               # beim Ersetzen beiseite gelegt (gesperrt) - beim nächsten Start löschen
    "replace_after_exit": [],      # Windows: [bereitgelegt, Ziel] - ersetzt, sobald Kodi beendet ist
    "rss_off": False,              # Build-News-Laufschrift im Wizard abgeschaltet
    "rss_applied": "",             # zuletzt eingetragener Feed (leer = beim nächsten Start eintragen)
    "rss_previous": "",            # Satz 1 aus RssFeeds.xml vor dem Eintragen (für das Abschalten)
}


def load_state():
    state = json.loads(json.dumps(DEFAULT_STATE))
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            stored = json.load(f)
        for key, value in stored.items():
            if isinstance(value, dict) and isinstance(state.get(key), dict):
                state[key].update(value)
            else:
                state[key] = value
    except (OSError, ValueError):
        pass
    return state


def save_state(state):
    tmp = STATE_FILE + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=1)
        os.replace(tmp, STATE_FILE)
    except OSError as e:
        log_error("state.json nicht gespeichert: {0}".format(e))


def interval_due(state, key_interval, key_last):
    """True, wenn die Aufgabe laut Intervall jetzt fällig ist ("start" = bei jedem Start)"""
    seconds = dict(INTERVALS).get(state.get(key_interval, "never"), 0)
    if seconds == 0:
        return False
    if seconds < 0:
        return False   # "bei jedem Start" erledigt der Dienst direkt beim Start
    return time.time() - float(state.get(key_last) or 0) >= seconds


# ----- Hilfen -----
def version_key(version):
    main = re.split(r"[+~-]", str(version or "0"))[0]
    return tuple(int(x) for x in re.findall(r"\d+", main)) or (0,)


def human_size(size):
    size = float(size or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return ("{0:.0f} {1}" if unit in ("B", "KB") else "{0:.1f} {1}").format(size, unit).replace(".", ",")
        size /= 1024.0


def folder_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total


def kodi_major():
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
    except ValueError:
        return 0


def jsonrpc(method, params=None):
    request = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        request["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result")
    except (ValueError, TypeError):
        return None


def get_setting(setting_id):
    result = jsonrpc("Settings.GetSettingValue", {"setting": setting_id})
    return result.get("value") if isinstance(result, dict) else None


def set_setting(setting_id, value):
    return jsonrpc("Settings.SetSettingValue", {"setting": setting_id, "value": value})


AFTER_EXIT = os.path.join(DATA, "after_exit")     # Windows: Dateien, die Kodi bis zum Beenden offen hält


def _replace_after_exit():
    """Windows: Dateien, die Kodi offen hält (z.B. Textures.xbt des aktiven Skins), ersetzt ein PowerShell-Auftrag,
    sobald Kodi beendet ist. Was dabei nicht klappt, holt der Wizard beim nächsten Start nach (finish_after_exit)."""
    jobs = load_state().get("replace_after_exit") or []
    if os.name != "nt" or not jobs:
        return
    import subprocess

    def quote(path):
        return "'" + path.replace("'", "''") + "'"
    lines = ["$p = {0}".format(os.getpid()),
             "for ($i = 0; $i -lt 120 -and (Get-Process -Id $p -ErrorAction SilentlyContinue); $i++) "
             "{ Start-Sleep -Milliseconds 500 }"]
    for src, dst in jobs:
        lines.append("Move-Item -LiteralPath {0} -Destination {1} -Force -ErrorAction SilentlyContinue".format(
            quote(src), quote(dst)))
    lines.append("Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force -ErrorAction SilentlyContinue")
    script = os.path.join(DATA, "after_exit.ps1")
    try:
        with open(script, "w", encoding="utf-8-sig") as f:
            f.write("\r\n".join(lines) + "\r\n")
        command = ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-WindowStyle",
                   "Hidden", "-File", script]
        no_window, breakaway = 0x08000000, 0x01000000
        try:
            subprocess.Popen(command, creationflags=no_window | breakaway, close_fds=True)
        except OSError:
            subprocess.Popen(command, creationflags=no_window, close_fds=True)
        log("Nach dem Beenden ersetzen: {0} Datei(en)".format(len(jobs)))
    except Exception as e:  # noqa: BLE001
        log_error("Ersetzen nach dem Beenden nicht gestartet: {0}".format(e))


def kill_kodi():
    """Kodi sofort beenden, ohne dass es beim Beenden Einstellungen überschreibt (z.B. guisettings.xml)"""
    _replace_after_exit()
    log("Kodi wird beendet")
    xbmc.sleep(300)
    os._exit(1)


def is_android():
    return xbmc.getCondVisibility("System.Platform.Android")
