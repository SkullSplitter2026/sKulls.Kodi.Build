# -*- coding: utf-8 -*-
"""
Hilfe-Einblendung: Info-Taste (oder langes Drücken von OK / Kontextmenü) auf einer Kachel oder Zeile zeigt
eine ausführliche Erklärung. Texte je Schlüssel (Property "key" der Einträge in ui.py) auf Deutsch und Englisch;
für Builds und unbekannte Einträge entsteht der Text aus Name, Zusatz und Beschreibung.
"""

from resources.lib import texts

HELP = {
    # ----- Builds und GUI -----
    "check_updates": ("Fragt beim Server nach, ob es neue Builds oder neue Versionen gibt. Das passiert auch "
                      "automatisch beim Start (Einstellungen → Auf Updates prüfen).",
                      "Asks the server whether there are new builds or new versions. This also happens "
                      "automatically on start (Settings → Check for updates)."),
    "local_build": ("Installiert einen Build aus einer ZIP-Datei auf diesem Gerät, einem USB-Stick oder im "
                    "Netzwerk - praktisch ohne Internet. Die Datei muss ein Build dieses Wizards sein.",
                    "Installs a build from a ZIP file on this device, a USB stick or the network - handy "
                    "without internet. The file must be a build of this wizard."),
    "gui_fix": ("Spielt nur die Oberflächen-Einstellungen des Builds neu ein (Skin, Menüs, Ansichten), ohne Addons "
                "zu ändern. Hilft, wenn das Menü nach einem Update durcheinander ist. Kodi startet danach neu.",
                "Re-applies only the interface settings of the build (skin, menus, views) without changing "
                "add-ons. Helps when the menu is messed up after an update. Kodi restarts afterwards."),
    "info_save": ("Speichert die Infos zum installierten Build als Textdatei, z.B. für den Support.",
                  "Saves the information about the installed build as a text file, e.g. for support."),
    "retry": ("Lädt die Build-Liste erneut vom Server.", "Loads the build list from the server again."),
    "whats_new": ("Zeigt die Neuigkeiten des Wizards und der Builds.", "Shows the news of the wizard and builds."),
    # ----- Wartung: Cleaning -----
    "clean_all": ("Leert Cache, Paket-Reste und alte Absturzberichte in einem Schritt. Einstellungen und Addons "
                  "bleiben, wie sie sind.",
                  "Clears cache, package leftovers and old crash reports in one step. Settings and add-ons "
                  "stay as they are."),
    "clean_cache": ("Löscht zwischengespeicherte Dateien von Kodi und den Addons. Die Addons legen sie bei Bedarf "
                    "neu an - der erste Start einzelner Addons kann danach etwas länger dauern.",
                    "Deletes cached files of Kodi and the add-ons. The add-ons recreate them when needed - the first "
                    "start of some add-ons may take a little longer afterwards."),
    "clean_packages": ("Kodi hebt die ZIP-Dateien installierter Addons auf (addons/packages). Sie werden nicht mehr "
                       "gebraucht und können weg.",
                       "Kodi keeps the ZIP files of installed add-ons (addons/packages). They are no longer "
                       "needed and can go."),
    "clean_thumbs": ("Löscht alle Vorschaubilder (Poster, Logos, Hintergründe). Kodi lädt sie beim Durchblättern "
                     "neu - spart viel Platz, Listen sind danach eine Weile langsamer. Kodi startet neu.",
                     "Deletes all thumbnails (posters, logos, backgrounds). Kodi reloads them while browsing - saves "
                     "a lot of space, lists are slower for a while afterwards. Kodi restarts."),
    "clean_db": ("Entfernt Datenbanken älterer Kodi-Versionen, die nach einem Kodi-Update liegen geblieben sind.",
                 "Removes databases of older Kodi versions left behind after a Kodi update."),
    "clean_crash": ("Löscht Absturzberichte und alte Logs. Vorher bei Problemen gern das Log speichern "
                    "(Logging → Log speichern).",
                    "Deletes crash reports and old logs. If you have problems, save the log first "
                    "(Logging → Save log)."),
    "clean_assistant": ("Zeigt die größten Addon-Daten und Caches einzeln - du entscheidest, was geleert wird.",
                        "Shows the largest add-on data and caches one by one - you decide what gets cleared."),
    # ----- Wartung: Addon-Tools -----
    "addon_remove": ("Deinstalliert ausgewählte Addons samt ihren Einstellungen.",
                     "Uninstalls selected add-ons including their settings."),
    "addon_data": ("Löscht die Einstellungen einzelner Addons - das Addon startet danach wie neu installiert.",
                   "Deletes the settings of individual add-ons - the add-on then starts as if freshly installed."),
    "addon_toggle": ("Schaltet Addons ein oder aus, ohne sie zu deinstallieren. Ausgeschaltete Addons starten "
                     "nicht und laufen nicht im Hintergrund.",
                     "Turns add-ons on or off without uninstalling them. Disabled add-ons do not start and do "
                     "not run in the background."),
    "addon_updateall": ("Lädt die Addon-Listen aller Repositories neu und installiert jedes verfügbare Update.",
                        "Reloads the add-on lists of all repositories and installs every available update."),
    "addon_updateresult": ("Zeigt, welche Addons bei der letzten Aktualisierung neu kamen und welche "
                           "fehlgeschlagen sind.",
                           "Shows which add-ons were updated last time and which failed."),
    "addon_update": ("Lässt Kodi alle Repositories sofort neu prüfen, statt bis zur nächsten automatischen "
                     "Prüfung zu warten.",
                     "Makes Kodi check all repositories right away instead of waiting for the next automatic "
                     "check."),
    "addon_repos": ("Prüft, ob die Adressen aller installierten Repositories erreichbar sind. Ein nicht "
                    "erreichbares Repository liefert keine Updates.",
                    "Checks whether the addresses of all installed repositories are reachable. An unreachable "
                    "repository delivers no updates."),
    "addon_deps": ("Findet fehlende oder ausgeschaltete Module, die andere Addons brauchen, und repariert sie.",
                   "Finds missing or disabled modules other add-ons need and repairs them."),
    "addon_mode": ("Legt fest, ob Kodi Addon-Updates automatisch installiert, nur meldet oder gar nicht prüft.",
                   "Sets whether Kodi installs add-on updates automatically, only notifies or does not check."),
    # ----- Wartung: Logging -----
    "log_show": ("Zeigt Kodis Protokoll dieser Sitzung. Bei Problemen stehen dort die Fehlermeldungen.",
                 "Shows Kodi's log of this session. If there are problems, the error messages are there."),
    "log_errors": ("Zeigt nur die Zeilen mit Fehlern und Warnungen aus dem Log.",
                   "Shows only the lines with errors and warnings from the log."),
    "log_filter": ("Durchsucht das Log nach einem Begriff, nach einem Addon oder nur nach Fehlern - hilft, die "
                   "wichtigen Zeilen in einem langen Log zu finden.",
                   "Searches the log for a term, an add-on or only errors - helps to find the important lines "
                   "in a long log."),
    "log_export": ("Speichert das Log als Datei auf einem USB-Stick, im Netzwerk oder auf dem Gerät - z.B. um es "
                   "dem Support zu schicken. Passwörter und Zugangsdaten werden auf Wunsch unkenntlich gemacht.",
                   "Saves the log as a file on a USB stick, the network or the device - e.g. to send it to "
                   "support. Passwords and credentials are masked if you like."),
    "log_debug": ("Schreibt viel mehr ins Log - nur zur Fehlersuche einschalten und danach wieder aus.",
                  "Writes much more into the log - only turn on for troubleshooting and off again afterwards."),
    "log_old": ("Das Log der vorigen Sitzung - wichtig nach einem Absturz, weil das neue Log den Fehler nicht "
                "mehr enthält.",
                "The log of the previous session - important after a crash because the new log no longer "
                "contains the error."),
    "log_wizard": ("Was der Wizard getan hat: Installationen, Updates, Wartung.",
                   "What the wizard did: installations, updates, maintenance."),
    # ----- Wartung: System Tweaks -----
    "tweak_device": ("Zeigt Arbeitsspeicher und Speicherplatz und schlägt passende Einstellungen vor (Puffer, "
                     "Bildgrößen, automatische Wartung).",
                     "Shows memory and storage and suggests suitable settings (buffer, image sizes, automatic "
                     "maintenance)."),
    "tweak_advanced": ("advancedsettings.xml enthält Einstellungen, die es in Kodis Menüs nicht gibt (z.B. Puffer "
                       "für Streams). Anzeigen, Vorlage eintragen oder löschen.",
                       "advancedsettings.xml contains settings that do not exist in Kodi's menus (e.g. buffer for "
                       "streams). Show, insert a template or delete."),
    "tweak_unknown": ("Erlaubt das Installieren von Addons aus ZIP-Dateien und Fremd-Repositories. Nur einschalten, "
                      "wenn du der Quelle vertraust.",
                      "Allows installing add-ons from ZIP files and third-party repositories. Only turn on if you "
                      "trust the source."),
    "tweak_network": ("Zeitlimits und Wiederholungen für Verbindungen - hilft bei langsamem oder wackeligem Netz.",
                      "Timeouts and retries for connections - helps with slow or unstable networks."),
    "tweak_refresh": ("Passt die Bildwiederholrate des Fernsehers an das Video an. Gegen Ruckeln bei Filmen, "
                      "kann aber kurz schwarzes Bild beim Start geben.",
                      "Matches the TV's refresh rate to the video. Against judder in films, but may cause a short "
                      "black screen on start."),
    "tweak_speed": ("Misst die Geschwindigkeit der Internetverbindung.", "Measures the speed of the internet "
                                                                         "connection."),
    # ----- Wartung: Misc -----
    "misc_reload": ("Lädt die Oberfläche neu, ohne Kodi zu beenden - z.B. nach Skin-Änderungen.",
                    "Reloads the interface without quitting Kodi - e.g. after skin changes."),
    "misc_quit": ("Beendet Kodi sofort.", "Quits Kodi immediately."),
    "misc_sources": ("Findet Einträge in sources.xml, deren Adresse nicht mehr erreichbar ist.",
                     "Finds entries in sources.xml whose address is no longer reachable."),
    "misc_skin": ("Wechselt zurück zum Standard-Skin Estuary, z.B. wenn ein Skin nicht mehr startet.",
                  "Switches back to the default skin Estuary, e.g. when a skin no longer starts."),
    "misc_addondb": ("Baut Kodis Addon-Datenbank neu auf - hilft, wenn Addons fehlen oder doppelt erscheinen.",
                     "Rebuilds Kodi's add-on database - helps when add-ons are missing or appear twice."),
    "misc_fresh": ("Setzt Kodi auf den Auslieferungszustand zurück: alle Addons und Einstellungen werden "
                   "gelöscht. Der Wizard und Save Data bleiben. Vorher am besten ein Backup machen.",
                   "Resets Kodi to factory state: all add-ons and settings are deleted. The wizard and Save Data "
                   "stay. Best make a backup first."),
    # ----- Backup und Save Data -----
    "backup_folder": ("Ordner, in dem Backups landen - z.B. ein USB-Stick oder eine Netzwerkfreigabe, damit sie "
                      "einen Neuaufbau des Geräts überstehen.",
                      "Folder where backups go - e.g. a USB stick or a network share so they survive a rebuild "
                      "of the device."),
    "backup_auto": ("Sichert automatisch in festen Abständen.", "Backs up automatically at fixed intervals."),
    "restore_file": ("Spielt ein Backup aus einer Datei zurück. Vorhandene Einstellungen werden ersetzt.",
                     "Restores a backup from a file. Existing settings are replaced."),
    "save_now": ("Sichert die gewählten Einstellungen (Addon-Zugänge, Favoriten, Quellen …), damit sie eine "
                 "Build-Installation oder einen Fresh Start überstehen.",
                 "Saves the chosen settings (add-on logins, favourites, sources …) so they survive a build "
                 "installation or a fresh start."),
    "save_restore": ("Spielt die mit Save Data gesicherten Einstellungen zurück.",
                     "Restores the settings saved with Save Data."),
    "save_clear": ("Löscht die mit Save Data gesicherten Einstellungen.", "Deletes the settings saved with Save Data."),
    "save_whitelist": ("Addons auf dieser Liste bleiben bei Build-Installation und Fresh Start erhalten.",
                       "Add-ons on this list are kept on build installation and fresh start."),
    # ----- Einstellungen -----
    "layout": ("Kacheln groß, klein oder als Liste - Links/Rechts wechselt.", "Large tiles, small tiles or a "
                                                                              "list - left/right switches."),
    "pin_set": ("Eine PIN schützt gefährliche Aktionen wie Fresh Start und Build-Installation.",
                "A PIN protects dangerous actions such as fresh start and build installation."),
    "rss": ("Laufschrift mit Neuigkeiten des Anbieters im Wizard ein- oder ausschalten.",
            "Turns the ticker with news from the provider on or off in the wizard."),
    "selfcheck_run": ("Prüft, ob die Dateien des Wizards unverändert und vollständig sind.",
                      "Checks whether the wizard's files are unchanged and complete."),
    "selfcheck_repair": ("Lädt beschädigte oder fehlende Dateien des Wizards neu.",
                         "Reloads damaged or missing files of the wizard."),
    "setup_assistant": ("Führt Schritt für Schritt durch die wichtigsten Einstellungen.",
                        "Guides you step by step through the most important settings."),
    "menu_builds": ("Alle Builds dieses Wizards. OK auf einem Build zeigt Details und installiert ihn.",
                    "All builds of this wizard. OK on a build shows details and installs it."),
    "menu_info": ("Was ist installiert: Build, Version, Addons, Speicherplatz.",
                  "What is installed: build, version, add-ons, storage."),
    "menu_gui": ("Oberflächen-Einstellungen des Builds neu einspielen.", "Re-apply the build's interface settings."),
    "menu_addons": ("Addons, die der Anbieter einzeln empfiehlt - mit einem Klick installieren.",
                    "Add-ons the provider recommends individually - install with one click."),
    "menu_maint": ("Aufräumen, Addon-Werkzeuge, Logs, System-Einstellungen und mehr.",
                   "Clean-up, add-on tools, logs, system settings and more."),
    "menu_backup": ("Sichern und Zurückspielen - auf USB-Stick, Netzwerk oder dem Gerät.",
                    "Back up and restore - to USB stick, network or the device."),
    "menu_save": ("Was bei einer Build-Installation erhalten bleibt (Zugänge, Favoriten, Quellen).",
                  "What is kept on a build installation (logins, favourites, sources)."),
    "menu_settings": ("Einstellungen des Wizards: Ansicht, Updates, PIN, automatische Wartung.",
                      "Wizard settings: view, updates, PIN, automatic maintenance."),
    "menu_contact": ("So erreichst du den Anbieter.", "How to reach the provider."),
}
PREFIX_HELP = {
    "autobackup_": ("Einstellungen für das automatische Backup: wie oft, was gesichert wird und wie viele Backups "
                    "bleiben. Links/Rechts ändert den Wert.",
                    "Settings for the automatic backup: how often, what is saved and how many backups are kept. "
                    "Left/right changes the value."),
    "backup_": ("Erstellt ein Backup des gewählten Bereichs.", "Creates a backup of the chosen area."),
}
GENERIC = ("OK öffnet den Eintrag, Zurück führt ins Menü. Info zeigt diese Hilfe.",
           "OK opens the entry, Back returns to the menu. Info shows this help.")


def _pick(pair):
    return pair[0] if texts.GERMAN else pair[1]


def text_for(key, label="", label2="", detail=""):
    """Hilfetext zu einem Eintrag: fester Text, sonst aus den Angaben des Eintrags"""
    parts = []
    if key in HELP:
        parts.append(_pick(HELP[key]))
    else:
        prefix = next((p for p in PREFIX_HELP if key.startswith(p)), "")
        if prefix:
            parts.append(_pick(PREFIX_HELP[prefix]))
    if detail and detail not in parts:
        parts.append(detail)
    if label2 and not parts:
        parts.append(label2)
    parts.append("[I]" + _pick(GENERIC) + "[/I]")
    return "[CR][CR]".join(p for p in parts if p)
