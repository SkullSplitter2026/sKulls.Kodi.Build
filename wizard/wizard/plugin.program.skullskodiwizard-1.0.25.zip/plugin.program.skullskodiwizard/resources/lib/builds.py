# -*- coding: utf-8 -*-
"""
Build-Liste laden und Builds sicher installieren.

Ablauf einer Installation - erst prüfen, dann löschen:
  1. herunterladen, Größe und SHA-256 prüfen    2. ZIP testen und freien Speicher prüfen
  3. Save Data sichern (optional Backup)          4. komplett in einen Zwischenordner entpacken
  5. erst jetzt aufräumen                         6. Dateien an ihren Platz verschieben
  7. Save Data zurückspielen, Build merken        8. Kodi beenden (sonst überschreibt es die neuen Einstellungen)
Scheitert Schritt 1-4, bleibt die bisherige Einrichtung unangetastet.
"""

import glob
import json
import os
import re
import shutil
import sqlite3
import time
import zipfile
from urllib.parse import quote

from resources.lib import config, lock, net, savedata
from resources.lib.texts import T
from resources.lib.common import (ADDON_DATA, ADDON_ID, ADDONS, AFTER_EXIT, DATA, HOME, LOGPATH, PACKAGES, STAGE, TEMP,
                                  USERDATA, human_size, jsonrpc, kodi_major, load_state, log, save_state, version_key)

LIST_NAME = "builds.json"
MARKER = os.path.join(USERDATA, ".skbuild.json")   # liegt in Builds, die mit dem sKulls Forge erstellt wurden
KEEP_DB_PREFIXES = ("Addons", "Textures")          # von Kodi geöffnet - nie ersetzen
# Binär-Addons (PVR, Inputstream …) gibt es je System und CPU in eigener Fassung - sie stehen nicht im Build, sondern
# in dieser Liste (auch alte Wizards schreiben sie so) bzw. in der Build-Liste und werden nach dem Neustart geladen
OLD_BINARIES = "userdata/build_binaries.txt"
ADDON_ID_TEXT = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.-]*$")
LIBRARY_ATTR = re.compile(r"\blibrary_[a-z0-9_]+\s*=", re.I)     # library_windows=, library_android= …
last_plan = {"binaries": [], "skipped": []}         # für die Meldung nach der Installation
_cache = {}


class BuildError(Exception):
    pass


# ----- Build-Liste -----
def load_list(refresh=False):
    if refresh or "list" not in _cache:
        data = net.fetch_json(LIST_NAME)
        if not isinstance(data, dict) or not isinstance(data.get("builds"), list):
            raise BuildError("Build-Liste hat ein unbekanntes Format")
        _cache["list"] = data
    return _cache["list"]


def builds(refresh=False):
    return [b for b in load_list(refresh).get("builds", []) if isinstance(b, dict) and b.get("id")]


def find(build_id):
    return next((b for b in builds() if b.get("id") == build_id), None)


def installed():
    return load_state().get("build")


def detect_installed():
    """Beim ersten Start: ist schon ein Build aus der Liste installiert? (Kennung aus dem Build selbst)"""
    state = load_state()
    if state.get("build"):
        return state["build"]
    try:
        with open(MARKER, "r", encoding="utf-8") as f:
            marker = json.load(f)
    except (OSError, ValueError):
        return None
    known = find(marker.get("id")) if marker.get("id") else None
    if known is None:
        return None
    state["build"] = {"id": known["id"], "name": known.get("name", known["id"]),
                      "version": marker.get("version") or known.get("version", "")}
    save_state(state)
    log("Installierter Build erkannt: {0} {1}".format(state["build"]["name"], state["build"]["version"]))
    return state["build"]


def update_available():
    current = installed()
    if not current:
        return None
    build = find(current.get("id"))
    if build and version_key(build.get("version")) > version_key(current.get("version")):
        return build
    return None


def kodi_mismatch(build):
    wanted = str(build.get("kodi", "")).split(".")[0]
    return bool(wanted.isdigit() and int(wanted) != kodi_major())


# ----- Installation -----
def _zip_prefix(names):
    """Manche Builds haben einen Oberordner (z.B. 'Kodi/addons/...') - der wird abgeschnitten"""
    tops = {n.split("/", 1)[0] for n in names if "/" in n}
    if len(tops) == 1:
        top = tops.pop()
        if top not in ("addons", "userdata", "media") and any(n.startswith(top + "/addons/") or
                                                              n.startswith(top + "/userdata/") for n in names):
            return top + "/"
    return ""


def _skip(rel, skip_ids=()):
    parts = rel.split("/")
    if parts[0] == "addons" and len(parts) > 1 and (parts[1] in (ADDON_ID, "packages") or parts[1] in skip_ids):
        return True
    if parts[:2] == ["userdata", "addon_data"] and len(parts) > 2 and (parts[2] == ADDON_ID or parts[2] in skip_ids):
        return True
    if rel == OLD_BINARIES:
        return True
    if parts[:2] == ["userdata", "Database"] and len(parts) > 2 and parts[2].startswith(KEEP_DB_PREFIXES):
        return True
    return parts[-1] in ("kodi.log", "kodi.old.log") or rel.endswith(".pyo")


SERVICE_POINT = re.compile(r"""point\s*=\s*["']xbmc\.service["']""")


def _addons_matching(pattern, root):
    found = []
    for name in sorted(os.listdir(root)) if os.path.isdir(root) else []:
        try:
            with open(os.path.join(root, name, "addon.xml"), "r", encoding="utf-8", errors="replace") as f:
                if pattern.search(f.read()):
                    found.append(name)
        except OSError:
            pass
    return found


def binary_addons(root=ADDONS):
    """Installierte Binär-Addons (addon.xml mit library_<system>=)"""
    return _addons_matching(LIBRARY_ATTR, root)


def service_addons(root=ADDONS):
    """Python-Dienste (xbmc.service) - halten oft eigene Datenbanken in addon_data offen (z.B. Anmeldungen)"""
    return [a for a in _addons_matching(SERVICE_POINT, root) if a != ADDON_ID]


PVR_DBS = ("TV", "Epg")           # hält Kodis PVR-Manager offen, solange PVR-Clients laufen


def _locked_pvr_dbs():
    """Windows: PVR-Datenbanken, die Kodi noch offen hat (Umbenennen klappt dann nicht) - andere Systeme sperren nicht"""
    if os.name != "nt":
        return []
    folder = os.path.join(USERDATA, "Database")
    locked = []
    for name in os.listdir(folder) if os.path.isdir(folder) else []:
        if name.startswith(PVR_DBS) and name.endswith(".db"):
            path = os.path.join(folder, name)
            try:
                os.rename(path, path + ".sk")
                os.rename(path + ".sk", path)
            except OSError:
                locked.append(name)
    return locked


def release_open_files(wait=10):
    """Vor dem Ersetzen: eingeschaltete Binär-Addons und Dienste ausschalten. Kodi entlädt sie (Windows sperrt geladene
    DLLs), schließt die PVR-Datenbanken (Sender, Gruppen, Reihenfolge) und beendet die Dienste, die so ihre Datenbanken
    schließen - sonst ließen sich diese Dateien nicht ersetzen. Nach dem Neustart schaltet der Wizard alles wieder ein
    (enable_all_pending); bei einem Fehler sofort (enable_again)."""
    released = []
    protected = protected_addons()
    for addon_id in [a for a in binary_addons() + service_addons() if a not in protected]:
        details = jsonrpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]}) or {}
        if (details.get("addon") or {}).get("enabled", True):
            jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": False})
            released.append(addon_id)
    for _ in range(wait * 2 if released else 0):
        if not _locked_pvr_dbs():
            break
        time.sleep(0.5)
    if released:
        log("Für das Ersetzen ausgeschaltet: {0}".format(", ".join(released)))
    return released


def enable_again(addon_ids):
    for addon_id in addon_ids:
        jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})


def _safe_target(root, rel):
    target = os.path.normpath(os.path.join(root, rel))
    if not target.startswith(os.path.normpath(root) + os.sep):
        raise BuildError(T("Unsicherer Pfad in der ZIP: {0}").format(rel))
    return target


def parse_ids(text):
    seen = []
    for item in re.split(r"[,;\s]+", text or ""):
        if item and ADDON_ID_TEXT.match(item) and item not in seen:
            seen.append(item)
    return seen


def other_wizard(addon_id):
    """Ein anderer (alter) Wizard im Build - den ersetzt dieser Wizard, er wird nicht mit installiert"""
    low = addon_id.lower()
    return low != ADDON_ID.lower() and low.startswith("plugin.program.") and "wizard" in low


def zip_plan(zip_path):
    """(Binär-Addons laut build_binaries.txt, mitgelieferte andere Wizards) einer Build-ZIP"""
    binaries, wizards = [], set()
    with zipfile.ZipFile(zip_path) as z:
        names = {n.replace("\\", "/"): n for n in z.namelist()}
        prefix = _zip_prefix(list(names))
        for name in names:
            rel = name[len(prefix):] if name.startswith(prefix) else name
            parts = rel.split("/")
            if len(parts) > 2 and parts[0] == "addons" and other_wizard(parts[1]):
                wizards.add(parts[1])
        if prefix + OLD_BINARIES in names:
            binaries = parse_ids(z.read(names[prefix + OLD_BINARIES]).decode("utf-8", "replace"))
    return binaries, sorted(wizards)


def extract_to_stage(zip_path, ui=None, base=0, span=100, skip_ids=()):
    shutil.rmtree(STAGE, ignore_errors=True)
    os.makedirs(STAGE)
    keep = set(skip_ids) | installed_protected()       # Wizard und Repository bleiben, wie sie sind
    with zipfile.ZipFile(zip_path) as z:
        infos = [i for i in z.infolist() if not i.is_dir()]
        prefix = _zip_prefix([i.filename for i in infos])
        total = sum(i.file_size for i in infos) or 1
        done = 0
        count = 0
        for info in infos:
            rel = info.filename[len(prefix):] if info.filename.startswith(prefix) else info.filename
            rel = rel.replace("\\", "/").lstrip("/")
            if not rel or _skip(rel, keep):
                continue
            target = _safe_target(STAGE, rel)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(info) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
            count += 1
            done += info.file_size
            if ui and count % 25 == 0:
                if ui.update(base + span * done // total, rel) is False:
                    raise BuildError("Abgebrochen")
    return count


def check_zip(zip_path):
    try:
        with zipfile.ZipFile(zip_path) as z:
            bad = z.testzip()
            size = sum(i.file_size for i in z.infolist())
    except zipfile.BadZipFile:
        raise BuildError("Die Datei ist keine gültige ZIP")
    if bad:
        raise BuildError(T("ZIP beschädigt: {0}").format(bad))
    free = shutil.disk_usage(HOME).free
    if free < size * 1.15 + 50 * 1024 * 1024:
        raise BuildError(T("Zu wenig Speicher: {0} nötig, {1} frei").format(human_size(size * 1.15), human_size(free)))
    return size


def protected_addons():
    """Bleiben immer erhalten - egal was passiert (Build-Installation, Fresh Start, Restore, Wartung): der Wizard und
    sein Repository (im sKulls Forge eingetragen, sonst das Repository, aus dem der Wizard installiert wurde). Sie werden
    nie gelöscht, nie durch Dateien aus einem Build oder Backup ersetzt und nie ausgeschaltet."""
    keep = {ADDON_ID}
    repo_id = (config.get("repo") or {}).get("id")
    if repo_id:
        keep.add(repo_id)
    origin = origin_repo()
    if origin:
        keep.add(origin)
    return keep


def is_protected(addon_id, protected=None):
    return addon_id in (protected if protected is not None else protected_addons())


def installed_protected():
    """Geschützte Addons, die installiert sind - deren Dateien kommen nie aus einem Build oder Backup (ältere Fassung).
    Fehlt das Repository noch, darf es aus dem Build kommen."""
    return {a for a in protected_addons() if os.path.isdir(os.path.join(ADDONS, a))}


def origin_repo(addon_id=ADDON_ID):
    """Aus Kodis Addon-Datenbank (nur lesen): aus welchem Repository kam das Addon? „“ = unbekannt / ZIP"""
    def number(path):
        digits = "".join(c for c in os.path.basename(path) if c.isdigit())
        return int(digits or 0)
    for db in sorted(glob.glob(os.path.join(USERDATA, "Database", "Addons*.db")), key=number, reverse=True):
        try:
            # nur lesen; Pfad für die URI maskieren (Leerzeichen z.B. in „Application Support“ unter macOS)
            uri = "file:{0}?mode=ro".format(quote(db.replace("\\", "/"), safe="/:"))
            con = sqlite3.connect(uri, uri=True, timeout=2)
            try:
                row = con.execute("SELECT origin FROM installed WHERE addonID = ?", (addon_id,)).fetchone()
            finally:
                con.close()
        except sqlite3.Error:
            continue
        origin = (row[0] if row else "") or ""
        return origin if origin.startswith("repository.") else ""
    return ""


def wipe(keep_addons=(), keep_addon_data=False):
    """Alles in Kodis Datenordner löschen - bis auf Wizard und Repository, die Whitelist und die offenen
    Datenbanken"""
    keep = {"packages"} | set(keep_addons) | protected_addons()
    errors = 0
    in_use = _in_use_names()
    for name in os.listdir(HOME):
        path = os.path.join(HOME, name)
        if name in ("addons", "userdata", "temp", ".sk_stage") or name.lower() in in_use:
            continue
        errors += _remove(path)
    for name in os.listdir(ADDONS):
        if name not in keep:
            errors += _remove(os.path.join(ADDONS, name))
    for name in os.listdir(USERDATA):
        path = os.path.join(USERDATA, name)
        if name == "addon_data":
            if keep_addon_data:      # Backup ohne Addon-Daten: vorhandene Einstellungen und Anmeldungen behalten
                continue
            for addon in os.listdir(path):
                if addon not in keep:
                    errors += _remove(os.path.join(path, addon))
        elif name == "Database":
            for db in os.listdir(path):
                if not db.startswith(KEEP_DB_PREFIXES):
                    errors += _remove(os.path.join(path, db))
        else:
            errors += _remove(path)
    shutil.rmtree(PACKAGES, ignore_errors=True)
    return errors


def _in_use_names():
    """Was Kodi gerade selbst benutzt und direkt im Datenordner liegen kann: der Temp-Ordner (unter Windows „cache“)
    und das Log (unter Windows im Datenordner) - nicht löschen, das schlägt sonst fehl oder stört Kodi"""
    names = {"kodi.log", "kodi.old.log"}
    for folder in (TEMP, LOGPATH):
        folder = os.path.normpath(folder)
        if os.path.dirname(folder) == os.path.normpath(HOME):
            names.add(os.path.basename(folder).lower())
    return names


def _remove(path):
    try:
        if os.path.isdir(path) and not os.path.islink(path):
            shutil.rmtree(path)
        else:
            os.remove(path)
        return 0
    except OSError:
        return 1   # z.B. von Kodi geöffnete Dateien unter Windows


SQLITE_SIDE = ("-wal", "-shm", "-journal")


def _move(src, dst):
    try:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        os.replace(src, dst)
        return None
    except OSError as e:
        return e


def move_stage(retry=10):
    """Zwischenordner an seinen Platz. Gesperrte Dateien (Windows: von Kodi offen): einige Sekunden nachfassen, dann die
    alte Datei beiseite legen (*.sk_old, wird beim nächsten Start gelöscht). Rückgabe: Anzahl nicht ersetzter Dateien"""
    pairs = []
    for root, _dirs, files in os.walk(STAGE):
        for name in files:
            src = os.path.join(root, name)
            pairs.append((src, os.path.join(HOME, os.path.relpath(src, STAGE))))
    targets = set(dst for _src, dst in pairs)
    failed = [(src, dst) for src, dst in pairs if _move(src, dst)]
    deadline = time.time() + (retry if failed else 0)
    while failed and time.time() < deadline:
        time.sleep(1)
        failed = [(src, dst) for src, dst in failed if _move(src, dst)]
    errors, olds, later = 0, [], []
    for src, dst in failed:
        old = dst + ".sk_old"
        try:
            if os.path.exists(old):
                os.remove(old)
            os.rename(dst, old)
        except OSError as e:
            error = e
        else:
            error = _move(src, dst)
            if error is None:
                olds.append(old)
                continue
            try:
                os.rename(old, dst)
            except OSError:
                pass
        if os.name == "nt":      # Windows: bereitlegen, ersetzt wird, sobald Kodi beendet ist (common.kill_kodi)
            held = os.path.join(AFTER_EXIT, os.path.relpath(src, STAGE))
            if _move(src, held) is None:
                later.append([held, dst])
                continue
        errors += 1
        if errors <= 10:
            log("Nicht ersetzt: {0} ({1})".format(os.path.relpath(src, STAGE), error))
    # SQLite: eine neue Datenbank darf nie mit alten Begleitdateien (-wal …) zusammenkommen
    for dst in targets:
        for side in SQLITE_SIDE:
            if dst.endswith(".db") and dst + side not in targets and os.path.exists(dst + side):
                try:
                    os.remove(dst + side)
                except OSError:
                    log("Alte Begleitdatei nicht gelöscht: {0}".format(dst + side))
    if later:
        state = load_state()
        state["replace_after_exit"] = (state.get("replace_after_exit") or []) + later
        save_state(state)
        log("Von Kodi offen - wird ersetzt, sobald Kodi beendet ist: {0}".format(
            ", ".join(os.path.relpath(dst, HOME) for _held, dst in later[:10])))
    if olds:
        state = load_state()
        state["old_files"] = sorted(set(state.get("old_files") or []) | set(olds))
        save_state(state)
        log("Ersetzt, alte Fassung beiseite gelegt (wird beim nächsten Start gelöscht): {0}".format(len(olds)))
    shutil.rmtree(STAGE, ignore_errors=True)
    return errors


def _download(name, sha256, size, ui, step_text):
    dest = os.path.join(DATA, "download", os.path.basename(name.split("?")[0]) or "build.zip")

    def progress(loaded, total):
        if ui:
            percent = loaded * 100 // total if total else 0
            return ui.update(percent, "{0} / {1}".format(human_size(loaded), human_size(total or loaded)))
        return True
    if ui:
        ui.step(step_text)
    return net.download(name, dest, sha256=sha256, size=size, progress=progress)


def _install_zip(zip_path, ui, fresh, binaries=()):
    """Gemeinsamer Teil jeder Build-Installation: prüfen, sichern, entpacken, aufräumen, übernehmen.
    binaries: Binär-Addons aus der Build-Liste - zusammen mit build_binaries.txt nach dem Neustart nachinstallieren"""
    state = load_state()
    listed, wizards = zip_plan(zip_path)
    pending = [a for a in parse_ids(",".join(list(binaries) + listed)) if a not in wizards and a != ADDON_ID]
    last_plan["binaries"], last_plan["skipped"] = pending, wizards
    if wizards:
        log("Nicht übernommen (ersetzt durch diesen Wizard): {0}".format(", ".join(wizards)))
    try:
        ui.step("ZIP und Speicherplatz prüfen")
        check_zip(zip_path)
        ui.step("Save Data sichern")
        savedata.save(state)
        if state.get("backup_before_install"):
            ui.step("Sicherung des bisherigen Stands")
            from resources.lib import backup
            backup.create("full", ui=ui)
        ui.step("Entpacken")
        count = extract_to_stage(zip_path, ui, skip_ids=wizards)
        released = release_open_files()
        try:
            if fresh:
                ui.step("Aufräumen")
                wipe(savedata.whitelist())
            ui.step("Dateien übernehmen")
            errors = move_stage()
        except Exception:
            enable_again(released)
            raise
        ui.step("Save Data zurückspielen")
        savedata.restore()
        state = load_state()
        state["binaries_pending"], state["binaries_tries"] = pending, 0
        save_state(state)
        if pending:
            log("Nach dem Neustart nachinstallieren: {0}".format(", ".join(pending)))
    finally:
        shutil.rmtree(STAGE, ignore_errors=True)
    return count, errors


def after_install_text():
    """Abschlussmeldung einer Build-Installation"""
    lines = []
    if last_plan["binaries"]:
        lines.append(T("Nach dem Neustart lädt der Wizard {0} Addon(s) passend zu diesem Gerät: {1}").format(
            len(last_plan["binaries"]), ", ".join(last_plan["binaries"])))
    if last_plan["skipped"]:
        lines.append(T("Nicht übernommen (ersetzt durch diesen Wizard): {0}").format(", ".join(last_plan["skipped"])))
    lines.append(T("Kodi wird jetzt beendet."))
    return "\n".join(lines)


YESNO_WINDOW = 10100
ADDON_NEEDED = 24076          # Kodis Überschrift „Ein Addon wird benötigt“ (InstallAddon-Rückfrage)


def _confirm_install_prompt(addon_id, monitor=None, seconds=15):
    """Kodis eigene Rückfrage zu unserem InstallAddon bestätigen - nur diese (Überschrift „Ein Addon wird benötigt“)
    und nur kurz nach dem Aufruf. Zugestimmt hat der Nutzer schon beim Installieren des Builds."""
    import xbmc
    heading = xbmc.getLocalizedString(ADDON_NEEDED)
    for _ in range(seconds * 2):
        if addon_version(addon_id) is not None:
            return False
        if xbmc.getCondVisibility("Window.IsActive({0})".format(YESNO_WINDOW)) and heading and \
                xbmc.getInfoLabel("Control.GetLabel(1)") == heading:
            xbmc.executebuiltin("SendClick({0},11)".format(YESNO_WINDOW))      # 11 = Ja
            return True
        if monitor is not None:
            if monitor.waitForAbort(0.5):
                return False
        else:
            xbmc.sleep(500)
    return False


def install_pending_binaries(monitor=None, wait=90):
    """Nach dem Neustart: Binär-Addons aus den Repositories laden - Kodi wählt die Fassung für dieses System
    (Windows, Android, macOS, Linux …) und diese CPU. Drei Versuche (je ein Kodi-Start), dann Hinweis."""
    import xbmc
    from resources.lib import dialogs
    from resources.lib.common import jsonrpc
    state = load_state()
    pending = [a for a in state.get("binaries_pending") or [] if ADDON_ID_TEXT.match(a)]
    if not pending:
        return [], []
    missing = [a for a in pending if addon_version(a) is None]
    if missing and state.get("notifications", True):
        dialogs.notify(T("Lade passend zu diesem Gerät: {0}").format(", ".join(missing)), seconds=8)
    for addon_id in missing:
        log("Installiere {0} aus den Repositories".format(addon_id))
        # nicht warten: Kodi 19-21 fragt trotz „,true“ nach - die Rückfrage bestätigen wir unten selbst
        xbmc.executebuiltin("InstallAddon({0},true)".format(addon_id))
        if _confirm_install_prompt(addon_id, monitor):
            log("Kodis Rückfrage für {0} bestätigt".format(addon_id))
        waited = 0
        while addon_version(addon_id) is None and waited < wait:
            if monitor is not None:
                if monitor.waitForAbort(1):
                    return [], pending
            else:
                xbmc.sleep(1000)
            waited += 1
    done = [a for a in pending if addon_version(a) is not None]
    for addon_id in done:
        jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
    failed = [a for a in pending if a not in done]
    state = load_state()
    tries = int(state.get("binaries_tries", 0)) + 1
    if failed and tries < 3:
        state["binaries_pending"], state["binaries_tries"] = failed, tries
    else:
        state["binaries_pending"], state["binaries_tries"] = [], 0
    save_state(state)
    log("Nachinstalliert: {0} | fehlt noch: {1} (Versuch {2})".format(", ".join(done) or "-",
                                                                     ", ".join(failed) or "-", tries))
    if failed and tries >= 3:
        dialogs.notify(T("Nicht installiert: {0} - bitte über Addons > Aus Repository installieren").format(
            ", ".join(failed)), seconds=12)
    elif done and state.get("notifications", True):
        dialogs.notify(T("Installiert: {0}").format(", ".join(done)), seconds=6)
    return done, failed


def remember(info):
    """Installierten Build merken (nach Installation oder Build-Wechsel)"""
    _remember(info)


def _remember(info):
    state = load_state()
    info = dict(info, installed=time.strftime("%Y-%m-%d %H:%M"))
    state["build"] = info
    state["enable_all_pending"] = True
    state["first_run_done"] = True
    state["rss_applied"] = ""           # der Build bringt seine eigene RssFeeds.xml - Feed neu eintragen
    save_state(state)


def install(build, ui, fresh=True, key=None):
    """Build vom Server installieren. ui: Fortschrittsfenster (step/update/canceled). key: Schlüssel eines
    passwortgeschützten Builds (lock.derive). Wirft BuildError."""
    if not build.get("sha256"):
        raise BuildError("Für diesen Build fehlt die Prüfsumme - Installation aus Sicherheitsgründen abgelehnt")
    zip_path = _download(build["zip"], build["sha256"], build.get("size", 0), ui, "Herunterladen")
    plain = zip_path
    try:
        if build.get("locked"):
            if not key:
                raise BuildError("Für diesen Build ist ein Passwort nötig")
            ui.step("Entschlüsseln")
            plain = zip_path + ".zip"
            try:
                lock.decrypt_file(zip_path, plain, key, build.get("lock") or {},
                                  progress=lambda done, total: ui.update(done * 100 // max(1, total),
                                                                         human_size(done)))
            except lock.LockError as e:
                raise BuildError(T(str(e)))
        count, errors = _install_zip(plain, ui, fresh, build.get("binaries") or [])
    finally:
        for path in {zip_path, plain}:
            try:
                os.remove(path)
            except OSError:
                pass
    _remember({"id": build["id"], "name": build.get("name", build["id"]), "version": build.get("version", "")})
    _set_local_gui("")
    _write_marker(build)
    log("Build installiert: {0} {1} ({2} Dateien, {3} Fehler)".format(build.get("name"), build.get("version"),
                                                                     count, errors))
    return count, errors


def is_build_zip(zip_path):
    """Enthält die ZIP eine Kodi-Einrichtung (addons/ oder userdata/, auch unter einem Oberordner)?"""
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = [n.replace("\\", "/") for n in z.namelist()]
    except (OSError, zipfile.BadZipFile):
        return False
    prefix = _zip_prefix(names)
    return any(n[len(prefix):].startswith(("addons/", "userdata/")) for n in names)


def local_lock(path):
    """Build aus Datei: None = ungeschützte ZIP, sonst {"id", "name", "version", "lock"} eines geschützten Builds
    (.skz). Die Schutzangaben stehen in <Datei>.json daneben (legt der sKulls Forge an) oder in der Build-Liste."""
    if zipfile.is_zipfile(path):
        return None
    for side in (path + ".json", os.path.splitext(path)[0] + ".skz.json"):
        try:
            with open(side, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and isinstance(data.get("lock"), dict):
                data.setdefault("id", "local")
                data.setdefault("name", os.path.splitext(os.path.basename(path))[0])
                return data
        except (OSError, ValueError):
            continue
    try:
        for build in builds():
            if build.get("locked") and os.path.basename(build.get("zip", "")) == os.path.basename(path):
                return {"id": build["id"], "name": build.get("name", build["id"]), "version": build.get("version", ""),
                        "lock": build.get("lock") or {}}
    except Exception:  # noqa: BLE001 - Build-Liste nicht erreichbar
        pass
    if path.lower().endswith(".skz"):
        raise BuildError("Geschützter Build ohne Schutzangaben - die Datei {0}.json gehört daneben".format(
            os.path.basename(path)))
    raise BuildError("Die Datei ist weder eine ZIP noch ein geschützter Build")


def decrypt_local(path, info, key, ui):
    """Geschützten Build entschlüsseln (in den Download-Ordner des Wizards). Rückgabe: Pfad der Klartext-ZIP"""
    from resources.lib import lock
    dest = os.path.join(DATA, "download", "local_build.zip")
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    ui.step("Entschlüsseln")
    lock.decrypt_file(path, dest, key, info["lock"],
                      lambda done, total: ui.update(done * 100 // max(1, total), "") is not False)
    return dest


def install_local(zip_path, ui, fresh=True, name=None):
    """Build aus einer lokalen ZIP installieren (USB-Stick, Netzwerk, Download-Ordner) - ohne Server.
    Die Datei wird nicht gelöscht."""
    if not is_build_zip(zip_path):
        raise BuildError("Die ZIP enthält keinen Kodi-Build (addons/ oder userdata/ fehlen)")
    count, errors = _install_zip(zip_path, ui, fresh)
    gui = os.path.splitext(zip_path)[0] + "_guisettings.zip"      # alte Builds: GUI-Paket liegt daneben
    _set_local_gui(gui if os.path.isfile(gui) else "")
    marker = {}
    try:
        with open(MARKER, "r", encoding="utf-8") as f:
            marker = json.load(f)
    except (OSError, ValueError):
        pass
    name = name or os.path.splitext(os.path.basename(zip_path))[0]
    known = None
    try:
        known = find(marker.get("id")) if marker.get("id") else None
    except Exception:  # noqa: BLE001 - Build-Liste nicht erreichbar: dann eben ohne Namen aus der Liste
        known = None
    _remember({"id": marker.get("id") or "local", "name": (known or {}).get("name") or marker.get("name") or name,
               "version": marker.get("version", "")})
    _write_marker({"id": marker.get("id") or "local", "version": marker.get("version", "")})
    log("Build aus Datei installiert: {0} ({1} Dateien, {2} Fehler)".format(zip_path, count, errors))
    return count, errors


def _set_local_gui(path):
    state = load_state()
    state["local_gui"] = path
    save_state(state)


def local_gui():
    """GUI-Paket neben der zuletzt installierten Build-Datei (oder "")"""
    path = load_state().get("local_gui") or ""
    return path if path and os.path.isfile(path) else ""


def read_marker():
    """Inhaltsliste des installierten Builds (vom sKulls Forge in den Build gelegt) - {} wenn keine da ist"""
    try:
        with open(MARKER, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_marker(build):
    """Kennung, Version und Installationsdatum ergänzen - die Inhaltsliste aus dem Build bleibt erhalten"""
    marker = read_marker()
    marker.update({"id": build["id"], "version": build.get("version", ""), "wizard": ADDON_ID,
                   "installed": time.strftime("%Y-%m-%d %H:%M")})
    try:
        with open(MARKER, "w", encoding="utf-8") as f:
            json.dump(marker, f, ensure_ascii=False, indent=1)
    except OSError:
        pass


def addon_version(addon_id):
    """Version eines installierten Addons aus seiner addon.xml - None, wenn es nicht installiert ist"""
    try:
        with open(os.path.join(ADDONS, addon_id, "addon.xml"), "rb") as f:
            head = f.read(4096).decode("utf-8", "replace")
    except OSError:
        return None
    import re
    m = re.search(r"<addon\b[^>]*\bversion=\"([^\"]+)\"", head)
    return m.group(1) if m else ""


def install_repo_update(info, ui=None):
    """Repository des Wizards aus der Build-Liste (mit Prüfsumme) installieren bzw. aktualisieren"""
    repo_id = info.get("id", "")
    if not info.get("sha256") or not repo_id.startswith("repository."):
        raise BuildError("Repository-Update ohne Prüfsumme abgelehnt")
    dest = os.path.join(DATA, "download", "repository.zip")
    if ui:
        ui.step("Herunterladen")
    net.download(info["zip"], dest, sha256=info["sha256"], size=info.get("size", 0))
    try:
        if ui:
            ui.step("Installieren")
        with zipfile.ZipFile(dest) as z:
            for member in z.infolist():
                rel = member.filename.replace("\\", "/")
                if member.is_dir() or not rel.startswith(repo_id + "/"):
                    continue
                target = _safe_target(ADDONS, rel)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(member) as src, open(target, "wb") as dst:
                    shutil.copyfileobj(src, dst)
    finally:
        try:
            os.remove(dest)
        except OSError:
            pass
    import xbmc
    from resources.lib.common import jsonrpc
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.sleep(1500)
    jsonrpc("Addons.SetAddonEnabled", {"addonid": repo_id, "enabled": True})
    log("Repository {0} auf {1} gebracht".format(repo_id, info.get("version")))


def build_info():
    """Alles für die Seite Build-Info: Angaben zum Build, Addons laut Build und wie sie jetzt installiert sind"""
    from resources.lib.common import jsonrpc
    marker = read_marker()
    current = installed() or {}
    result = jsonrpc("Addons.GetAddons", {"properties": ["name", "version", "enabled", "path"]}) or {}
    now = {a["addonid"]: a for a in result.get("addons", []) if a.get("addonid")}
    rows = []
    listed = set()
    for a in marker.get("addons", []):
        listed.add(a["id"])
        have = now.get(a["id"])
        if have is None:
            state = "missing"
        elif version_key(have.get("version")) > version_key(a.get("version")):
            state = "updated"
        elif not have.get("enabled", True):
            state = "disabled"
        else:
            state = "ok"
        rows.append(dict(a, now=(have or {}).get("version", ""), state=state))
    extra = [{"id": aid, "name": a.get("name") or aid, "version": a.get("version", "")} for aid, a in now.items()
             if aid not in listed and aid != ADDON_ID and (a.get("path") or "").startswith(ADDONS)]
    return {"marker": marker, "build": current, "rows": rows,
            "extra": sorted(extra, key=lambda a: a["name"].lower())}


STATE_TEXT = {"ok": "", "updated": "aktualisiert", "missing": "fehlt", "disabled": "aus"}


def build_info_text(info):
    """Build-Info als Textdatei"""
    m, b = info["marker"], info["build"]
    lines = [T("Build: {0}").format(m.get("name") or b.get("name") or "-"),
             T("Version: {0}").format(m.get("version") or b.get("version") or "-"),
             T("Erstellt: {0}").format(m.get("built") or "-"),
             T("Installiert: {0}").format(m.get("installed") or b.get("installed") or "-"),
             T("Für Kodi: {0}").format(m.get("kodi") or "-") + "   " + T("Kodi jetzt: {0}").format(kodi_major()),
             T("Skin: {0}").format(m.get("skin") or "-"),
             T("Wizard: {0}").format(ADDON_ID), "",
             T("Addons im Build ({0}):").format(len(info["rows"]))]
    for r in info["rows"]:
        extra = T(STATE_TEXT[r["state"]]) if STATE_TEXT[r["state"]] else ""
        if r["state"] == "updated":
            extra += " " + r["now"]
        lines.append("  {0}  ·  {1}  ·  {2}{3}".format(r["name"], r["id"], r.get("version", ""),
                                                      "  ·  " + extra if extra else ""))
    if info["extra"]:
        lines += ["", T("Zusätzlich installiert ({0}):").format(len(info["extra"]))]
        lines += ["  {0}  ·  {1}  ·  {2}".format(a["name"], a["id"], a["version"]) for a in info["extra"]]
    return "\n".join(lines) + "\n"


def gui_fix(build, ui):
    """Nur die Oberfläche neu einspielen (Skin-Einstellungen, Menüs, Widgets) - Addons und Daten bleiben"""
    gui = (build or {}).get("gui") or {}
    downloaded = bool(gui.get("zip") and gui.get("sha256"))
    if downloaded:
        zip_path = _download(gui["zip"], gui["sha256"], gui.get("size", 0), ui, "GUI-Paket herunterladen")
    elif local_gui():
        zip_path = local_gui()
    else:
        raise BuildError("Für diesen Build gibt es kein GUI-Paket")
    try:
        ui.step("ZIP prüfen")
        check_zip(zip_path)
        ui.step("Aktuelle Oberfläche sichern")
        _backup_gui()
        ui.step("Entpacken")
        _extract_gui(zip_path)
        ui.step("Oberfläche einspielen")
        move_stage()
    finally:
        shutil.rmtree(STAGE, ignore_errors=True)
        if downloaded:
            try:
                os.remove(zip_path)
            except OSError:
                pass
    log("GUI-Fix angewendet: {0}".format(build.get("name")))


def _extract_gui(zip_path):
    """GUI-Paket in den Zwischenordner - nur userdata. Alte Wizards legen guisettings.xml, addon_data/… ohne
    „userdata/“ ab, das wird ergänzt"""
    shutil.rmtree(STAGE, ignore_errors=True)
    os.makedirs(STAGE)
    count = 0
    with zipfile.ZipFile(zip_path) as z:
        infos = [i for i in z.infolist() if not i.is_dir()]
        names = [i.filename.replace("\\", "/") for i in infos]
        prefix = _zip_prefix(names)
        has_userdata = any(n[len(prefix):].startswith("userdata/") for n in names)
        for info, name in zip(infos, names):
            rel = (name[len(prefix):] if name.startswith(prefix) else name).lstrip("/")
            if not has_userdata:
                rel = "userdata/" + rel
            if not rel.startswith("userdata/") or _skip(rel):
                continue
            target = _safe_target(STAGE, rel)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(info) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
            count += 1
    if not count:
        raise BuildError("Im GUI-Paket stehen keine Kodi-Einstellungen")
    return count


def apply_theme(build, theme, ui):
    if not theme.get("sha256"):
        raise BuildError("Für dieses Theme fehlt die Prüfsumme")
    zip_path = _download(theme["zip"], theme["sha256"], theme.get("size", 0), ui, "Theme herunterladen")
    try:
        ui.step("Entpacken")
        check_zip(zip_path)
        extract_to_stage(zip_path, ui)
        ui.step("Theme einspielen")
        move_stage()
    finally:
        shutil.rmtree(STAGE, ignore_errors=True)
        try:
            os.remove(zip_path)
        except OSError:
            pass
    log("Theme angewendet: {0}".format(theme.get("name")))


def _backup_gui():
    target = os.path.join(DATA, "gui_backup.zip")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as z:
        for name in ("guisettings.xml", "favourites.xml"):
            path = os.path.join(USERDATA, name)
            if os.path.isfile(path):
                z.write(path, "userdata/" + name)
        for addon in os.listdir(ADDON_DATA):
            if addon.startswith(("skin.", "script.skinshortcuts", "plugin.program.autowidget")):
                folder = os.path.join(ADDON_DATA, addon)
                for root, _d, files in os.walk(folder):
                    for name in files:
                        path = os.path.join(root, name)
                        z.write(path, os.path.relpath(path, HOME).replace(os.sep, "/"))
    return target


def enable_all_addons():
    """Nach einer Installation: Addons des Builds einschalten (Kodi ab 19 legt neue Addons deaktiviert an)"""
    from resources.lib.common import jsonrpc
    result = jsonrpc("Addons.GetAddons", {"enabled": False}) or {}
    disabled = []
    try:
        with open(MARKER, "r", encoding="utf-8") as f:
            disabled = json.load(f).get("disabled", [])
    except (OSError, ValueError):
        pass
    state = load_state()
    protected = protected_addons()      # Wizard und Repository bleiben immer eingeschaltet
    keep_off = [a for a in state.get("keep_disabled") or [] if a not in protected]     # aus einem Komplett-Backup
    count = 0
    for addon in result.get("addons", []):
        addon_id = addon.get("addonid")
        if addon_id and addon_id not in disabled and addon_id not in keep_off and \
                os.path.isdir(os.path.join(ADDONS, addon_id)):
            jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
            count += 1
    for addon_id in keep_off:
        if os.path.isdir(os.path.join(ADDONS, addon_id)):
            jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": False})
    if keep_off:
        state = load_state()
        state["keep_disabled"] = []
        save_state(state)
    log("Addons eingeschaltet: {0}{1}".format(count, " (aus wie im Backup: {0})".format(len(keep_off)) if keep_off
                                               else ""))
    return count


def install_wizard_update(info, ui=None):
    """Neue Wizard-Version aus der Build-Liste (mit Prüfsumme) einspielen"""
    if not info.get("sha256"):
        raise BuildError("Wizard-Update ohne Prüfsumme abgelehnt")
    dest = os.path.join(DATA, "download", "wizard.zip")
    net.download(info["zip"], dest, sha256=info["sha256"], size=info.get("size", 0))
    with zipfile.ZipFile(dest) as z:
        for member in z.infolist():
            rel = member.filename.replace("\\", "/")
            if member.is_dir() or not rel.startswith(ADDON_ID + "/"):
                continue
            target = _safe_target(ADDONS, rel)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with z.open(member) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
    os.remove(dest)
    log("Wizard aktualisiert auf {0}".format(info.get("version")))


def finish_after_exit():
    """Beim Start: prüfen, ob die Dateien ersetzt wurden, die Kodi bis zum Beenden offen hatte - sonst jetzt versuchen"""
    state = load_state()
    jobs = state.get("replace_after_exit") or []
    if not jobs:
        return 0
    left = [(held, dst) for held, dst in jobs if os.path.exists(held)]
    failed = [dst for held, dst in left if _move(held, dst)]
    state = load_state()
    state["replace_after_exit"] = []
    save_state(state)
    shutil.rmtree(AFTER_EXIT, ignore_errors=True)
    log("Nach dem Beenden ersetzt: {0} von {1}{2}".format(
        len(jobs) - len(failed), len(jobs), " - nicht ersetzt: " + ", ".join(failed) if failed else ""))
    return len(failed)


def cleanup_leftovers():
    """Reste eines abgebrochenen Vorgangs entfernen - und beiseite gelegte alte Dateien (*.sk_old)"""
    shutil.rmtree(STAGE, ignore_errors=True)
    state = load_state()
    if state.get("old_files"):
        keep = []
        for path in state["old_files"]:
            try:
                if path.endswith(".sk_old") and os.path.exists(path):
                    os.remove(path)
            except OSError:
                keep.append(path)
        state["old_files"] = keep
        save_state(state)
    shutil.rmtree(os.path.join(DATA, "download"), ignore_errors=True)
