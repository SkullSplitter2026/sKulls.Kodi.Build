# -*- coding: utf-8 -*-
"""
Netzwerk: lädt die Build-Liste und die Builds von der Adresse, die der sKulls Forge beim Bauen einträgt
(z.B. GitHub Pages oder ein eigener Webserver). Downloads werden gegen Größe und SHA-256 aus der Build-Liste geprüft.
"""

import hashlib
import json
import os
import ssl
import urllib.error
import urllib.request

from resources.lib import config
from resources.lib.texts import T
from resources.lib.common import ADDON_ID, ADDON_VERSION, log

TIMEOUT = 30
CHUNK = 256 * 1024


class NetError(Exception):
    pass


def _context():
    try:
        import certifi  # script.module.certifi, falls vorhanden
        return ssl.create_default_context(cafile=certifi.where())
    except Exception:  # noqa: BLE001
        return ssl.create_default_context()


def url_for(name):
    """Name aus der Build-Liste -> Adresse (absolute Adressen bleiben, wie sie sind)"""
    if name.startswith(("https://", "http://")):
        return name
    base = (config.get("server") or {}).get("base", "")
    return base.rstrip("/") + "/" + name.lstrip("/")


def _open(name, timeout=TIMEOUT):
    url = url_for(name)
    if not url.startswith(("https://", "http://")):
        raise NetError(T("Keine Adresse für die Build-Liste eingetragen"))
    request = urllib.request.Request(url, headers={"User-Agent": "{0}/{1} Kodi".format(ADDON_ID, ADDON_VERSION)})
    try:
        if url.startswith("https://"):
            return urllib.request.urlopen(request, timeout=timeout, context=_context())
        return urllib.request.urlopen(request, timeout=timeout)
    except urllib.error.HTTPError as e:
        raise NetError(T("Server-Fehler {0}").format(e.code))
    except Exception as e:  # noqa: BLE001
        raise NetError(str(e))


def fetch_json(name, limit=2 * 1024 * 1024):
    with _open(name) as response:
        data = response.read(limit + 1)
    if len(data) > limit:
        raise NetError("Antwort zu groß")
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError:
        raise NetError("Ungültige Antwort vom Server")


def download(name, dest, sha256="", size=0, progress=None):
    """Lädt nach dest. progress(geladen, gesamt) -> False bricht ab. Prüft Größe und SHA-256."""
    digest = hashlib.sha256()
    loaded = 0
    tmp = dest + ".part"
    folder = os.path.dirname(dest)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    with _open(name, timeout=60) as response, open(tmp, "wb") as f:
        total = int(response.headers.get("Content-Length") or size or 0)
        while True:
            chunk = response.read(CHUNK)
            if not chunk:
                break
            f.write(chunk)
            digest.update(chunk)
            loaded += len(chunk)
            if progress and progress(loaded, total) is False:
                f.close()
                os.remove(tmp)
                raise NetError("Abgebrochen")
    if size and loaded != int(size):
        os.remove(tmp)
        raise NetError(T("Download unvollständig ({0} von {1} Bytes)").format(loaded, size))
    if sha256 and digest.hexdigest().lower() != sha256.lower():
        os.remove(tmp)
        raise NetError("Prüfsumme stimmt nicht - Datei beschädigt oder verändert")
    os.replace(tmp, dest)
    log("Geladen: {0} ({1} Bytes, SHA-256 {2})".format(name, loaded, "geprüft" if sha256 else "ohne Prüfung"))
    return dest
