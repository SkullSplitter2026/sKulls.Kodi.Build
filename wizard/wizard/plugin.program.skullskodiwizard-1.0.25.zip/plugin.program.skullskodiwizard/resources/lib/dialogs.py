# -*- coding: utf-8 -*-
"""
Eigene, skin-unabhängige Dialoge (Fenster aus resources/skins/Default/1080i): Bestätigen, Text, Auswahl,
Fortschritt. Nur die Bildschirmtastatur und der Dateiauswahl-Dialog kommen vom Skin.
"""

import threading

import xbmc
import xbmcgui

from resources.lib import config
from resources.lib.common import ADDON_PATH
from resources.lib.texts import T

COLORS = config.get("colors") or {}

ACTION_BACK = (9, 10, 92)       # Zurück, Vorheriges Menü, Navigation zurück
SKIN = ("Default", "1080i")
BAR_WIDTH = 1100                # Fortschrittsbalken in sk_progress.xml (Bild 30 auf Bild 31)


class _Base(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args)
        self.props = kwargs.get("props", {})

    def onInit(self):
        for key, value in self.props.items():
            self.setProperty(key, value)


class ConfirmDialog(_Base):
    result = False

    def onInit(self):
        super().onInit()
        # gefährliche Aktion: „Nein“ vorauswählen, damit ein versehentliches OK nichts löscht
        self.setFocusId(12 if self.props.get("danger") and not self.props.get("single") else 11)

    def onClick(self, control_id):
        self.result = control_id == 11
        self.close()

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.result = False
            self.close()


def confirm(heading, text, yes="Ja", no="Nein", danger=False):
    dialog = ConfirmDialog("sk_confirm.xml", ADDON_PATH, *SKIN,
                           props={"heading": T(heading), "text": T(text), "yes": T(yes), "no": T(no),
                                  "danger": "true" if danger else ""})
    dialog.doModal()
    result = dialog.result
    del dialog
    return result


def ok(heading, text, button="OK"):
    dialog = ConfirmDialog("sk_confirm.xml", ADDON_PATH, *SKIN,
                           props={"heading": T(heading), "text": T(text), "yes": T(button), "single": "true"})
    dialog.doModal()
    del dialog


class TextDialog(_Base):
    def onInit(self):
        super().onInit()
        self.getControl(20).setText(self.props.get("content", ""))
        self.setFocusId(21)                  # Bildlaufleiste - gibt es nur bei langem Text
        xbmc.sleep(100)
        if self.getFocusId() != 21:
            self.setFocusId(11)

    def onClick(self, control_id):
        if control_id == 11:
            self.close()

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.close()


def text(heading, content):
    dialog = TextDialog("sk_text.xml", ADDON_PATH, *SKIN, props={"heading": T(heading), "content": content,
                                                                 "close": T("Schließen")})
    dialog.doModal()
    del dialog


SEARCH_FROM = 9      # ab so vielen Einträgen gibt es oben „Suchen …“


class SelectDialog(_Base):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.items = kwargs.get("items", [])
        self.multi = kwargs.get("multi", False)
        self.chosen = set(kwargs.get("preselect", []))
        self.result = None
        self.search = kwargs.get("search", len(self.items) >= SEARCH_FROM)
        self.filter = ""
        self.shown = []          # Position in der Liste -> Index in self.items (None = Suchzeile)

    def onInit(self):
        super().onInit()
        self.setProperty("multi", "true" if self.multi else "")
        self._fill()
        self.setFocusId(20)

    def _fill(self):
        control = self.getControl(20)
        control.reset()
        self.shown = []
        if self.search:
            item = xbmcgui.ListItem(T("Suchen ..."), self.filter or "")
            item.setProperty("search", "true")
            control.addItem(item)
            self.shown.append(None)
        needle = self.filter.lower()
        for index, (label, label2) in enumerate(self.items):
            if needle and needle not in (label + " " + label2).lower():
                continue
            item = xbmcgui.ListItem(label, label2)
            item.setProperty("selected", "true" if index in self.chosen else "")
            control.addItem(item)
            self.shown.append(index)
        if self.search and len(self.shown) > 1:
            control.selectItem(1)

    def onClick(self, control_id):
        if control_id == 20:
            position = self.getControl(20).getSelectedPosition()
            index = self.shown[position] if 0 <= position < len(self.shown) else None
            if index is None:      # Suchzeile
                text = keyboard("Suchen", self.filter)
                if text is not None:
                    self.filter = text.strip()
                    self._fill()
                self.setFocusId(20)
                return
            if not self.multi:
                self.result = index
                self.close()
                return
            item = self.getControl(20).getSelectedItem()
            if index in self.chosen:
                self.chosen.discard(index)
                item.setProperty("selected", "")
            else:
                self.chosen.add(index)
                item.setProperty("selected", "true")
        elif control_id == 11:
            self.result = sorted(self.chosen)
            self.close()
        elif control_id == 12:
            self.close()

    def onAction(self, action):
        if action.getId() in ACTION_BACK:
            self.close()


def select(heading, items, multi=False, preselect=(), search=None):
    """items: [(Text, Zusatz)] -> Index (einfach) bzw. Liste von Indizes (mehrfach), None bei Abbruch.
    Lange Listen bekommen oben „Suchen …“ (search=None: automatisch ab SEARCH_FROM Einträgen)."""
    extra = {} if search is None else {"search": search}
    dialog = SelectDialog("sk_select.xml", ADDON_PATH, *SKIN, items=items, multi=multi, preselect=preselect,
                          props={"heading": T(heading), "ok": T("Übernehmen"), "cancel": T("Abbrechen")}, **extra)
    dialog.doModal()
    result = dialog.result
    del dialog
    return result


class ProgressDialog(_Base):
    """Fortschritt mit Schrittliste. Die Arbeit läuft in einem eigenen Thread, das Fenster bleibt bedienbar."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.steps = []
        self.canceled = False
        self.ready = threading.Event()

    def onInit(self):
        super().onInit()
        self.setFocusId(11)
        self.ready.set()

    def onClick(self, control_id):
        if control_id == 11:
            if self.getProperty("finished"):
                self.close()
            else:
                self.canceled = True
                self.setProperty("line", T("Wird abgebrochen ..."))

    def onAction(self, action):
        if action.getId() in ACTION_BACK and self.getProperty("finished"):
            self.close()

    # ---- vom Arbeits-Thread aufgerufen ----
    def step(self, name):
        self.steps.append(T(name))
        self._render()
        self.update(0, "")

    def _render(self):
        lines = []
        for index, name in enumerate(self.steps):
            current = index == len(self.steps) - 1 and not self.getProperty("finished")
            color = COLORS.get("accent2" if current else "dim", "FFFFFFFF")
            lines.append("[COLOR {0}]{1}  {2}[/COLOR]".format(color, ">" if current else "+", name))
        self.setProperty("steps", "[CR]".join(lines))

    def update(self, percent, line=""):
        try:
            percent = max(0, min(100, int(percent)))
            self.getControl(30).setWidth(max(1, BAR_WIDTH * percent // 100))
            self.setProperty("percent", str(percent) if percent else "")
        except (RuntimeError, TypeError, ValueError):
            pass
        if line is not None:
            self.setProperty("line", line)
        return not self.canceled

    def finish(self, heading, message):
        self.setProperty("finished", "true")
        self._render()
        message = T(message)
        lines = message.split("\n")
        if len(lines) > 1 or len(message) > 90:
            # Lange Meldungen ins Textfeld (bricht um), darunter die erledigten Schritte kompakt - unten nur die
            # letzte Zeile
            done = "[COLOR {0}]+  {1}[/COLOR]".format(COLORS.get("dim", "FFFFFFFF"), "  ·  ".join(self.steps))
            self.setProperty("steps", "[CR]".join(lines[:-1] or lines) + "[CR][CR]" + done)
            message = lines[-1] if len(lines) > 1 else ""
        self.setProperty("heading", T(heading))
        self.setProperty("line", message)
        self.setProperty("button", T("OK"))
        self.update(100, None)


def run(heading, work, done="Fertig"):
    """work(progress) läuft im Hintergrund. Rückgabe (Ergebnis, Fehler). Fenster schließt nach OK."""
    props = {"heading": T(heading), "button": T("Abbrechen")}
    dialog = ProgressDialog("sk_progress.xml", ADDON_PATH, *SKIN, props=props)
    outcome = {"result": None, "error": None}

    def worker():
        dialog.ready.wait(10)
        try:
            outcome["result"] = work(dialog)
            if isinstance(outcome["result"], str):
                dialog.finish(done, outcome["result"])
            else:
                dialog.finish(done, "")
        except Exception as e:  # noqa: BLE001
            outcome["error"] = str(e)
            dialog.finish("Fehler", str(e))
    thread = threading.Thread(target=worker)
    thread.start()
    dialog.doModal()
    dialog.canceled = True
    thread.join(timeout=600)
    return outcome["result"], outcome["error"]


class DeviceDialog(_Base):
    """Leistung & Speicher: Balken für RAM und Speicher, Profil (30), Vorschlagstabelle (40), Knöpfe 51-53"""
    BAR_WIDTH = 735
    BARS = {101: (180, 214), 102: (180, 214), 111: (1005, 214), 113: (1005, 214), 112: (1005, 214)}

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.info = kwargs["info"]
        self.current = kwargs["current"]
        self.memory_options = kwargs["memory_options"]
        self.read_options = kwargs["read_options"]
        self.profile = "balanced"
        self.rows = []
        self.off = set()          # abgewählte Zeilen

    def onInit(self):
        from resources.lib import tuning
        super().onInit()
        profiles = self.getControl(30)
        profiles.reset()
        for key, label in tuning.PROFILES:
            item = xbmcgui.ListItem(T(label))
            item.setProperty("key", key)
            profiles.addItem(item)
        profiles.selectItem([k for k, _l in tuning.PROFILES].index(self.profile))
        self._render_disk()
        self._refresh()
        self.setFocusId(30)

    # ---- Anzeige ----
    def _segment(self, control_id, start, width):
        """Abschnitt eines Balkens: start und width als Anteil 0..1"""
        x, y = self.BARS[control_id]
        start = max(0.0, min(1.0, start))
        width = max(0.0, min(1.0 - start, width))
        control = self.getControl(control_id)
        control.setPosition(x + int(self.BAR_WIDTH * start), y)
        control.setWidth(max(1, int(self.BAR_WIDTH * width)))

    def _color(self, key, text):
        return "[COLOR {0}]{1}[/COLOR]".format(COLORS.get(key, "FFFFFFFF"), text)

    def _render_ram(self):
        from resources.lib import tuning
        total, free = self.info.get("ram_total") or 0, self.info.get("ram_free") or 0
        buffer_row = next((r for r in self.rows if r["key"] == "memorysize"), None)
        need = (buffer_row["recommended"] or 0) * tuning.BUFFER_FACTOR if buffer_row else 0
        self.setProperty("ram_value", tuning.gb(total) if total else "?")
        if not total:
            self._segment(101, 0, 0)
            self._segment(102, 0, 0)
            self.setProperty("ram_legend", T("Kodi meldet keinen Arbeitsspeicher"))
            self.setProperty("ram_legend2", "")
            return
        used = max(0, total - free) if free else 0
        self._segment(101, 0, used / float(total))
        self._segment(102, used / float(total), need / float(total))
        self.setProperty("ram_legend", T("Belegt {0}  ·  Frei {1}").format(tuning.gb(used), tuning.gb(free))
                         if free else T("Freier Arbeitsspeicher unbekannt"))
        self.setProperty("ram_legend2", self._color("accent", T("Puffer-Vorschlag braucht etwa {0}").format(
            tuning.gb(need))))

    def _render_disk(self):
        from resources.lib import tuning
        total, free = self.info.get("disk_total") or 0, self.info.get("disk_free") or 0
        clean = self.info.get("cleanable") or 0
        if not total:
            for control_id in (111, 112, 113):
                self._segment(control_id, 0, 0)
            self.setProperty("disk_value", "?")
            self.setProperty("disk_legend", T("Speicherplatz nicht lesbar"))
            return
        used = total - free
        for control_id in (111, 113):
            self._segment(control_id, 0, used / float(total))
        self._segment(112, 0, clean / float(total))
        self.setProperty("disk_low", "true" if free < tuning.LOW_DISK else "")
        self.setProperty("disk_value", T("Frei: {0}").format(tuning.gb(free)))
        self.setProperty("disk_legend", T("Belegt {0}  ·  Gesamt {1}").format(tuning.gb(used), tuning.gb(total)))
        self.setProperty("disk_legend2", self._color("accent2", T("Aufräumbar (Cache, Pakete, Vorschaubilder): {0}")
                                                     .format(tuning.gb(clean))))

    def _refresh(self, position=None):
        from resources.lib import tuning
        self.rows = tuning.recommend(self.info, self.profile, self.current, self.memory_options, self.read_options)
        control = self.getControl(40)
        control.reset()
        for row in self.rows:
            item = xbmcgui.ListItem(row["label"])
            item.setProperty("current", row["text"][0])
            item.setProperty("recommended", row["text"][1] if row["changed"] else T("passt"))
            item.setProperty("changed", "true" if row["changed"] else "")
            item.setProperty("on", "" if row["key"] in self.off else "true")
            control.addItem(item)
        if position is not None:
            control.selectItem(position)
        self.setProperty("has_backup", "true" if tuning.has_backup() else "")
        self._render_ram()
        self._show_reason()

    def _show_reason(self):
        position = self.getControl(40).getSelectedPosition()
        if 0 <= position < len(self.rows):
            self.setProperty("reason", self.rows[position]["reason"])

    # ---- Bedienung ----
    def onAction(self, action):
        action_id = action.getId()
        if action_id in ACTION_BACK:
            self.close()
            return
        focus = self.getFocusId()
        if focus == 30 and action_id in (1, 2):
            key = self.getControl(30).getSelectedItem().getProperty("key")
            if key != self.profile:
                self.profile = key
                self._refresh()
        elif focus == 40 and action_id in (3, 4):
            self._show_reason()

    def onClick(self, control_id):
        from resources.lib import tuning
        if control_id == 30:
            self.setFocusId(40)
        elif control_id == 40:
            position = self.getControl(40).getSelectedPosition()
            row = self.rows[position]
            if row["changed"]:
                self.off.symmetric_difference_update([row["key"]])
                self.getControl(40).getSelectedItem().setProperty("on", "" if row["key"] in self.off else "true")
        elif control_id == 51:
            keys = [r["key"] for r in self.rows if r["changed"] and r["key"] not in self.off]
            if not keys:
                notify("Nichts zu ändern")
                return
            restart = tuning.apply(self.rows, keys)
            self.current = tuning.current_values()
            self._refresh(self.getControl(40).getSelectedPosition())
            ok("Leistung & Speicher", T("{0} Einstellungen übernommen.").format(len(keys)) +
               ("[CR][CR]" + T("Einige Werte gelten erst nach einem Neustart von Kodi.") if restart else ""))
            self.setFocusId(53)
        elif control_id == 52:
            if confirm("Zurücksetzen", "Die Werte von vor dem ersten Übernehmen wiederherstellen?"):
                restart = tuning.restore()
                self.current = tuning.current_values()
                self._refresh()
                if restart:
                    ok("Zurücksetzen", "Einige Werte gelten erst nach einem Neustart von Kodi.")
                self.setFocusId(51)
        elif control_id == 53:
            self.close()


def device():
    """Leistung & Speicher anzeigen - die Abfrage (Ordnergrößen) läuft hinter der Warte-Anzeige"""
    from resources.lib import tuning
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        info = tuning.device_info()
        current = tuning.current_values()
        memory_options = tuning.kodi_options("filecache.memorysize", tuning.MEMORY_OPTIONS)
        read_options = tuning.kodi_options("filecache.readfactor", tuning.READ_OPTIONS)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    device_line = [info.get("platform") or "", "{0}-Bit".format(info.get("bits")),
                   "Kodi {0}".format(info.get("kodi"))]
    dialog = DeviceDialog("sk_device.xml", ADDON_PATH, *SKIN, info=info, current=current,
                          memory_options=memory_options, read_options=read_options,
                          props={"heading": T("Leistung & Speicher"), "device": "  ·  ".join(p for p in device_line if p),
                                 "ram_title": T("Arbeitsspeicher"), "disk_title": T("Speicher"),
                                 "profile_label": T("Profil"), "profile_hint": T("Links/Rechts: Profil wechseln"),
                                 "col_setting": T("Einstellung"), "col_current": T("Aktuell"),
                                 "col_recommended": T("Vorschlag"), "apply": T("Übernehmen"),
                                 "reset": T("Zurücksetzen"), "close": T("Schließen")})
    dialog.doModal()
    del dialog


def notify(message, seconds=5):
    from resources.lib.common import ADDON_NAME
    xbmcgui.Dialog().notification(ADDON_NAME, T(message), xbmcgui.NOTIFICATION_INFO, seconds * 1000)


class GalleryDialog(_Base):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.images = kwargs.get("images", [])
        self.index = 0

    def onInit(self):
        super().onInit()
        self._show()

    def _show(self):
        self.getControl(10).setImage(self.images[self.index], True)
        self.setProperty("counter", "{0} / {1}".format(self.index + 1, len(self.images)))

    def onAction(self, action):
        action_id = action.getId()
        if action_id in ACTION_BACK:
            self.close()
        elif action_id in (1, 3) and len(self.images) > 1:          # links / hoch
            self.index = (self.index - 1) % len(self.images)
            self._show()
        elif action_id in (2, 4, 7) and len(self.images) > 1:       # rechts / runter / OK
            self.index = (self.index + 1) % len(self.images)
            self._show()


def gallery(heading, images):
    """Bildergalerie (Adressen oder Pfade): Links/Rechts blättern, Zurück schließt"""
    if not images:
        return
    dialog = GalleryDialog("sk_gallery.xml", ADDON_PATH, *SKIN, images=list(images),
                           props={"heading": T(heading), "hint": T("Links/Rechts: blättern  ·  Zurück: schließen")})
    dialog.doModal()
    del dialog


def pin(heading="PIN eingeben"):
    """Ziffern-Eingabe (verdeckt) - Fernbedienungs-freundlich. None bei Abbruch"""
    value = xbmcgui.Dialog().numeric(0, T(heading), "", True)
    return value or None


class Splash(xbmcgui.WindowXMLDialog):
    pass


def splash(seconds=0.9):
    """Kurzes Startbild mit Logo (sk_splash.xml)"""
    window = Splash("sk_splash.xml", ADDON_PATH, *SKIN)
    window.show()
    xbmc.sleep(int(seconds * 1000))
    window.close()
    del window


def keyboard(heading, default="", hidden=False):
    kb = xbmc.Keyboard(default, T(heading), hidden)
    kb.doModal()
    return kb.getText() if kb.isConfirmed() else None
