# -*- coding: utf-8 -*-
"""
Wartung: Cleaning Tools, Addon-Tools, Logging-Tools, System Tweaks, Misc Maintenance.
Hier stehen nur die eigentlichen Arbeiten - Abfragen und Anzeige erledigt ui.py.
"""

import glob
import os
import re
import shutil
import time
import urllib.request
import xml.etree.ElementTree as ET

import xbmc

from resources.lib import net, savedata
from resources.lib.common import (ADDON_DATA, ADDON_ID, ADDONS, DATABASE, HOME, LOGPATH, PACKAGES, TEMP, THUMBNAILS,
                                  USERDATA, WIZARD_LOG, folder_size, translate, get_setting, jsonrpc, load_state,
                                  log, save_state, set_setting)

# ====================== Cleaning Tools ======================

def _cache_dirs():
    dirs = [os.path.join(HOME, "cache"), os.path.join(TEMP, "archive_cache")]
    if os.path.isdir(ADDON_DATA):
        for addon in os.listdir(ADDON_DATA):
            for name in ("cache", "Cache", "temp"):
                path = os.path.join(ADDON_DATA, addon, name)
                if os.path.isdir(path):
                    dirs.append(path)
    dirs = [os.path.normpath(d) for d in dirs if os.path.isdir(d)]
    # Unter Windows ist special://temp der Ordner cache - Unterordner nicht doppelt zählen bzw. leeren
    return [d for d in dirs if not any(d != other and d.startswith(other + os.sep) for other in dirs)]


def _clear_dir(path):
    removed = 0
    try:
        names = os.listdir(path)
    except OSError:   # schon gelöscht oder gesperrt
        return 0
    for name in names:
        item = os.path.join(path, name)
        try:
            size = folder_size(item) if os.path.isdir(item) else os.path.getsize(item)
            if os.path.isdir(item):
                shutil.rmtree(item)
            else:
                os.remove(item)
            removed += size
        except OSError:
            pass
    return removed


def cache_size():
    return sum(folder_size(d) for d in _cache_dirs())


def clear_cache():
    return sum(_clear_dir(d) for d in _cache_dirs())


def packages_size():
    return folder_size(PACKAGES) if os.path.isdir(PACKAGES) else 0


def clear_packages():
    return _clear_dir(PACKAGES) if os.path.isdir(PACKAGES) else 0


def thumbs_size():
    size = folder_size(THUMBNAILS) if os.path.isdir(THUMBNAILS) else 0
    return size + sum(os.path.getsize(p) for p in glob.glob(os.path.join(DATABASE, "Textures*.db")))


def clear_thumbs():
    """Vorschaubilder löschen - danach muss Kodi neu starten (Textures-Datenbank)"""
    removed = _clear_dir(THUMBNAILS) if os.path.isdir(THUMBNAILS) else 0
    for db in glob.glob(os.path.join(DATABASE, "Textures*.db")):
        try:
            removed += os.path.getsize(db)
            os.remove(db)
        except OSError:
            pass
    return removed


def old_databases():
    """Datenbanken älterer Kodi-Versionen (z.B. MyVideos116.db neben MyVideos121.db)"""
    newest = {}
    files = glob.glob(os.path.join(DATABASE, "*.db"))
    for path in files:
        match = re.match(r"([A-Za-z]+)(\d+)\.db$", os.path.basename(path))
        if match:
            name, number = match.group(1), int(match.group(2))
            newest[name] = max(newest.get(name, 0), number)
    old = []
    for path in files:
        match = re.match(r"([A-Za-z]+)(\d+)\.db$", os.path.basename(path))
        if match and int(match.group(2)) < newest[match.group(1)]:
            old.append(path)
    return old


def old_databases_size():
    return sum(os.path.getsize(p) for p in old_databases())


def clear_old_databases():
    removed = 0
    for path in old_databases():
        try:
            removed += os.path.getsize(path)
            os.remove(path)
        except OSError:
            pass
    return removed


def _crash_files():
    found = []
    for folder in (HOME, TEMP, LOGPATH):
        for pattern in ("kodi_crashlog*", "kodi_stacktrace*", "*.dmp", "xbmc_crashlog*"):
            found += glob.glob(os.path.join(folder, pattern))
    return sorted(set(found))


def crash_size():
    return sum(os.path.getsize(p) for p in _crash_files())


def clear_crash_logs():
    removed = 0
    for path in _crash_files():
        try:
            removed += os.path.getsize(path)
            os.remove(path)
        except OSError:
            pass
    return removed


def cleanup_parts():
    """Teile von „Alles aufräumen“: [(Schlüssel, Name, Größe, braucht Neustart)]"""
    return [("cache", "Cache", cache_size(), False), ("packages", "Alte Pakete", packages_size(), False),
            ("crash", "Absturzberichte", crash_size(), False),
            ("databases", "Alte Datenbanken", old_databases_size(), True),
            ("thumbs", "Vorschaubilder", thumbs_size(), True)]


def cleanup(keys):
    """Gewählte Teile aufräumen. Rückgabe: freigegebene Bytes"""
    actions = {"cache": clear_cache, "packages": clear_packages, "crash": clear_crash_logs,
               "databases": clear_old_databases, "thumbs": clear_thumbs}
    return sum(actions[k]() for k in keys if k in actions)


# Datenbanken: Bedeutung und Kodi-Versionen (für Tipps im Wizard)
DB_TEXT = {"MyVideos": "Videobibliothek (Filme, Serien, gesehen-Status)", "MyMusic": "Musikbibliothek",
           "Addons": "Addon-Verzeichnis (von Kodi geöffnet)", "Textures": "Verzeichnis der Vorschaubilder",
           "Epg": "TV-Programm (EPG)", "TV": "TV-Sender und Aufnahmen (PVR)", "ViewModes": "Ansichten je Ordner",
           "ADSP": "Audio-DSP (alte Kodi-Versionen)"}
DB_KODI = {"MyVideos": {116: "18", 119: "19", 121: "20", 131: "21"}, "MyMusic": {72: "18", 82: "19-20", 83: "21"},
           "Addons": {27: "18", 33: "19-21"}}


def database_report():
    """Alle Datenbanken: [(Pfad, Name, Größe, Status, Tipp)] - Status "alt" (sicher löschbar), "aktuell", "offen"
    (von Kodi geöffnet, nie löschen) oder „unbekannt“"""
    import glob as _glob
    old = set(old_databases())
    rows = []
    for path in sorted(_glob.glob(os.path.join(DATABASE, "*.db"))):
        name = os.path.basename(path)
        match = re.match(r"([A-Za-z]+)(\d+)\.db$", name)
        base, number = (match.group(1), int(match.group(2))) if match else (name[:-3], 0)
        meaning = DB_TEXT.get(base, "")
        kodi = DB_KODI.get(base, {}).get(number)
        if path in old:
            status = "alt"
        elif base in ("Addons", "Textures"):
            status = "offen"
        elif match:
            status = "aktuell"
        else:
            status = "unbekannt"
        rows.append((path, name, os.path.getsize(path), status, meaning, kodi))
    return rows


# advancedsettings.xml von Hand: häufige Einträge mit Tipps
# (Pfad, Name, Art, Tipp) - Art: "mb" (Eingabe in MB, gespeichert in Bytes), "int", "bool", "text"
ADVANCED_ENTRIES = [
    ("cache/memorysize", "Video-Puffer (MB)", "mb",
     "Wie viel RAM Kodi zum Vorpuffern von Streams nutzt. Kodi belegt etwa das Dreifache. Faustregel: höchstens ein "
     "Drittel des freien RAM - 1-GB-Geräte 50-100 MB, 2 GB 150-200 MB, 4 GB und mehr 300-500 MB."),
    ("cache/readfactor", "Lesefaktor (%)", "int",
     "Wie schnell der Puffer gefüllt wird, in Prozent der Videobitrate (400 = vierfach). Höher hilft bei "
     "schwankendem Internet, 0 = adaptiv (ab Kodi 21)."),
    ("cache/buffermode", "Puffer-Modus (0-4)", "int",
     "0 = alle Internet-Quellen, 1 = alles (auch lokal), 2 = nur Internet-Streams, 3 = kein Puffer, 4 = Internet und "
     "Heimnetz. Für Streams meist 1 oder 4."),
    ("network/curlclienttimeout", "Verbindungs-Timeout (s)", "int",
     "Sekunden bis eine Verbindung als gescheitert gilt. Bei langsamen Servern 20-30."),
    ("network/curllowspeedtime", "Langsam-Zeit (s)", "int",
     "So lange darf eine Übertragung stocken, bevor Kodi abbricht. 20-30 bei wackeligem WLAN."),
    ("network/curlretries", "Wiederholungen", "int", "Wie oft Kodi einen fehlgeschlagenen Abruf wiederholt (2-3)."),
    ("network/disablehttp2", "HTTP/2 ausschalten", "bool",
     "Hilft bei manchen Servern mit Abbrüchen oder Ladeproblemen. Sonst leer lassen."),
    ("video/playcountminimumpercent", "Gesehen ab (%)", "int",
     "Ab welchem Anteil ein Video als gesehen markiert wird (Kodi: 90)."),
    ("video/ignoresecondsatstart", "Fortsetzen erst ab (s)", "int",
     "Wird ein Video früher beendet, merkt Kodi sich keine Position (Kodi: 180)."),
    ("video/ignorepercentatend", "Ende ignorieren (%)", "int",
     "Die letzten Prozent zählen als „zu Ende gesehen“ (Kodi: 8)."),
    ("imageres", "Bildgröße Poster (Pixel)", "int",
     "Höchstauflösung für Poster und Vorschaubilder (Kodi: 720). 540 spart Speicher auf schwachen Geräten."),
    ("fanartres", "Bildgröße Fanart (Pixel)", "int",
     "Höchstauflösung für Hintergrundbilder (Kodi: 1080). 720 spart Speicher."),
]


def advanced_value(path):
    """Aktueller Wert eines Eintrags in advancedsettings.xml - None, wenn nicht gesetzt"""
    try:
        node = ET.parse(ADVANCED).getroot().find(path)
    except (OSError, ET.ParseError):
        return None
    return node.text.strip() if node is not None and node.text else None


def set_advanced_value(path, value):
    """Eintrag setzen (value None: entfernen). path z.B. "cache/memorysize" oder „imageres“"""
    try:
        tree = ET.parse(ADVANCED)
        root = tree.getroot()
    except (OSError, ET.ParseError):
        root = ET.Element("advancedsettings", version="1.0")
        tree = ET.ElementTree(root)
    parts = [p for p in path.strip("/").split("/") if p]
    if not parts or not all(re.match(r"^[A-Za-z][\w.\-]*$", p) for p in parts):
        raise ValueError("Ungültiger Pfad: {0}".format(path))
    parent = root
    for part in parts[:-1]:
        node = parent.find(part)
        if node is None:
            if value is None:
                return
            node = ET.SubElement(parent, part)
        parent = node
    child = parent.find(parts[-1])
    if value is None:
        if child is not None:
            parent.remove(child)
    else:
        if child is None:
            child = ET.SubElement(parent, parts[-1])
        child.text = str(value)
    tree.write(ADVANCED, encoding="utf-8", xml_declaration=True)


def total_cleanup(thumbs=True):
    removed = clear_cache() + clear_packages() + clear_crash_logs() + clear_old_databases()
    if thumbs:
        removed += clear_thumbs()
    return removed


def auto_maintenance():
    """Automatische Wartung laut Einstellungen (Dienst). Vorschaubilder nur, wenn eingeschaltet."""
    state = load_state()
    removed = 0
    if state.get("maint_cache"):
        removed += clear_cache()
    if state.get("maint_packages"):
        removed += clear_packages()
    removed += clear_crash_logs()
    if state.get("maint_thumbs"):
        removed += _clear_dir(THUMBNAILS) if os.path.isdir(THUMBNAILS) else 0
    state["last_maintenance"] = time.time()
    save_state(state)
    log("Automatische Wartung: {0} Bytes frei".format(removed))
    return removed


# ====================== Addon-Tools ======================

def user_addons(enabled=None):
    """Vom Nutzer installierte Addons (nicht Teil von Kodi): [{"id", "name", "version", "enabled"}]"""
    params = {"properties": ["name", "version", "enabled", "path"]}
    if enabled is not None:
        params["enabled"] = enabled
    result = jsonrpc("Addons.GetAddons", params) or {}
    addons = []
    for addon in result.get("addons", []):
        path = addon.get("path", "")
        if addon.get("addonid") == ADDON_ID or not path.startswith(ADDONS):
            continue
        addons.append({"id": addon["addonid"], "name": re.sub(r"\[/?[A-Z]+[^\]]*\]", "", addon.get("name", "")),
                       "version": addon.get("version", ""), "enabled": addon.get("enabled", True)})
    return sorted(addons, key=lambda a: a["name"].lower())


def _unprotected(addon_ids):
    """Wizard und sein Repository sind nie Ziel von Entfernen / Daten löschen / Ausschalten"""
    from resources.lib import builds
    protected = builds.protected_addons()
    return [a for a in addon_ids if a not in protected]


def remove_addons(addon_ids, with_data=True):
    removed = 0
    for addon_id in _unprotected(addon_ids):
        jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": False})
        shutil.rmtree(os.path.join(ADDONS, addon_id), ignore_errors=True)
        if with_data:
            shutil.rmtree(os.path.join(ADDON_DATA, addon_id), ignore_errors=True)
        removed += 1
    xbmc.executebuiltin("UpdateLocalAddons")
    return removed


def remove_addon_data(addon_ids):
    addon_ids = _unprotected(addon_ids)
    for addon_id in addon_ids:
        shutil.rmtree(os.path.join(ADDON_DATA, addon_id), ignore_errors=True)
    return len(addon_ids)


def set_enabled(addon_ids, enabled):
    addon_ids = addon_ids if enabled else _unprotected(addon_ids)
    for addon_id in addon_ids:
        jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": enabled})
    return len(addon_ids)


def force_updates():
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("UpdateLocalAddons")


RESTORE_AFTER = 15 * 60     # so lange gilt „automatisch installieren“ nach „Alle Addons aktualisieren“


def addon_versions():
    """{Addon-ID: Version} aller Addons im Benutzerordner"""
    return {a["id"]: a["version"] for a in user_addons()}


def update_all_once():
    """Einmal alle verfügbaren Updates installieren, auch wenn Kodi Updates sonst nur meldet. Der Dienst stellt die
    vorherige Einstellung danach wieder her (spätestens beim nächsten Start). Merkt sich die Versionen vorher für
    die Ergebnisliste (update_result)."""
    state = load_state()
    state["update_snapshot"] = {"time": time.time(), "versions": addon_versions()}
    save_state(state)
    previous = update_mode()
    if previous != 0:
        state = load_state()
        state["restore_update_mode"] = {"mode": previous, "until": time.time() + RESTORE_AFTER}
        save_state(state)
        set_update_mode(0)
    force_updates()
    return previous


def update_result():
    """Ergebnis seit „Alle Addons aktualisieren“: (aktualisiert [(Name, alt, neu)], neu [(Name, Version)],
    fehlgeschlagen [Addon-ID aus dem kodi.log], Zeitpunkt) - None, wenn noch nie ausgeführt"""
    snapshot = load_state().get("update_snapshot")
    if not snapshot:
        return None
    before = snapshot.get("versions") or {}
    now = {a["id"]: a for a in user_addons()}
    updated = [(a["name"], before[aid], a["version"]) for aid, a in now.items()
               if aid in before and a["version"] != before[aid]]
    added = [(a["name"], a["version"]) for aid, a in now.items() if aid not in before]
    failed = []
    stamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(float(snapshot.get("time", 0))))
    for line in read_log(log_file()).splitlines():
        if line[:19] >= stamp and "AddonInstallJob" in line and (" error " in line.lower() or "failed" in line.lower()):
            m = re.search(r"\[([\w.\-]+)\]", line)
            if m and m.group(1) not in failed:
                failed.append(m.group(1))
    return sorted(updated), sorted(added), failed, float(snapshot.get("time", 0))


def restore_update_mode(force=False):
    """Vom Dienst aufgerufen: Update-Einstellung nach „Alle Addons aktualisieren“ zurückstellen"""
    state = load_state()
    pending = state.get("restore_update_mode")
    if not pending or (not force and time.time() < float(pending.get("until", 0))):
        return False
    set_update_mode(int(pending.get("mode", 0)))
    state["restore_update_mode"] = None
    save_state(state)
    log("Update-Einstellung wiederhergestellt")
    return True


def origins():
    """{Addon-ID: Herkunfts-Repository} aus Kodis Addon-Datenbank (nur lesen) - „“ = ohne Repository (ZIP)"""
    import sqlite3
    from urllib.parse import quote
    def number(path):
        return int("".join(c for c in os.path.basename(path) if c.isdigit()) or 0)
    for db in sorted(glob.glob(os.path.join(DATABASE, "Addons*.db")), key=number, reverse=True):
        try:
            con = sqlite3.connect("file:{0}?mode=ro".format(quote(db.replace("\\", "/"), safe="/:")), uri=True,
                                  timeout=2)
            try:
                return {aid: origin or "" for aid, origin in con.execute("SELECT addonID, origin FROM installed")}
            finally:
                con.close()
        except Exception:  # noqa: BLE001
            continue
    return {}


ORIGIN_SYSTEM = "b6a50484-93a0-4afb-a01c-8d17e059feda"   # Kodis Kennung für mitgelieferte/System-Addons


def origin_text(addon_id, table):
    """Herkunft zum Anzeigen: Repository-ID, „Kodi“ (mitgeliefert) oder „“ (ohne Repository, z.B. aus einer ZIP)"""
    origin = table.get(addon_id, "")
    if origin == ORIGIN_SYSTEM:
        return "Kodi"
    return origin if origin.startswith("repository.") else ""


CORE_PREFIXES = ("xbmc.", "kodi.")     # gehören zu Kodi selbst


def dependency_report():
    """Fehlende und ausgeschaltete Abhängigkeiten aller eingeschalteten Addons:
    {"missing": {ID: [benötigt von ...]}, "disabled": {ID: [...]}} (optionale Abhängigkeiten zählen nicht)"""
    result = jsonrpc("Addons.GetAddons", {"properties": ["name", "enabled", "dependencies"]}) or {}
    addons = result.get("addons", [])
    enabled = {a["addonid"]: a.get("enabled", True) for a in addons}
    missing, disabled = {}, {}
    for addon in addons:
        if not addon.get("enabled", True):
            continue
        for dep in addon.get("dependencies") or []:
            dep_id = dep.get("addonid", "")
            if not dep_id or dep.get("optional") or dep_id.startswith(CORE_PREFIXES):
                continue
            name = re.sub(r"\[/?[A-Z]+[^\]]*\]", "", addon.get("name") or addon["addonid"])
            if dep_id not in enabled:
                missing.setdefault(dep_id, []).append(name)
            elif not enabled[dep_id]:
                disabled.setdefault(dep_id, []).append(name)
    return {"missing": missing, "disabled": disabled}


def repair_dependencies(report, progress=None):
    """Ausgeschaltete Abhängigkeiten einschalten, fehlende über Kodi installieren lassen (aus den Repositories).
    Rückgabe: (eingeschaltet, Installation angestoßen)"""
    switched = 0
    for dep_id in report.get("disabled", {}):
        if jsonrpc("Addons.SetAddonEnabled", {"addonid": dep_id, "enabled": True}) == "OK":
            switched += 1
    started = 0
    missing = sorted(report.get("missing", {}))
    for index, dep_id in enumerate(missing):
        if progress:
            progress(index * 100 // max(1, len(missing)), dep_id)
        xbmc.executebuiltin("InstallAddon({0})".format(dep_id), True)
        started += 1
    log("Abhängigkeiten: {0} eingeschaltet, {1} zur Installation".format(switched, started))
    return switched, started


def storage_report(limit=40):
    """Speicher-Assistent: [(Schlüssel, Anzeige, Größe gesamt, Größe Cache)] - Addon-Daten und Kodis Ordner"""
    rows = []
    if os.path.isdir(ADDON_DATA):
        for name in os.listdir(ADDON_DATA):
            path = os.path.join(ADDON_DATA, name)
            if not os.path.isdir(path) or name == ADDON_ID:
                continue
            total = folder_size(path)
            cache = sum(folder_size(sub) for sub in _cache_subdirs(path))
            if total:
                rows.append(("addon:" + name, name, total, cache))
    for key, label, path in (("thumbs", "Vorschaubilder", THUMBNAILS), ("packages", "Addon-Pakete", PACKAGES)):
        if os.path.isdir(path):
            rows.append((key, label, folder_size(path), folder_size(path)))
    return sorted(rows, key=lambda r: -r[2])[:limit]


def _cache_subdirs(path):
    """Cache-Ordner eines Addons - unter Windows/macOS sind „cache“ und „Cache“ derselbe Ordner"""
    found = {}
    for sub in ("cache", "Cache", "temp"):
        full = os.path.join(path, sub)
        if os.path.isdir(full):
            found.setdefault(os.path.normcase(os.path.realpath(full)), full)
    return list(found.values())


def clear_addon_cache(name):
    return sum(_clear_dir(sub) for sub in _cache_subdirs(os.path.join(ADDON_DATA, name)))


def clear_addon_data(name):
    path = os.path.join(ADDON_DATA, name)
    size = folder_size(path) if os.path.isdir(path) else 0
    shutil.rmtree(path, ignore_errors=True)
    return size


def _repo_urls(path):
    """Alle Adressen der Addon-Listen eines Repositorys (Kodi 19+: mehrere <dir> für verschiedene Kodi-Versionen)"""
    try:
        root = ET.parse(os.path.join(path, "addon.xml")).getroot()
    except (OSError, ET.ParseError):
        return [], ""
    urls = []
    for info in root.iter("info"):
        url = (info.text or "").strip()
        if url and url not in urls:
            urls.append(url)
    return urls, root.get("name") or os.path.basename(path)


def check_repositories(progress=None):
    """[(Name, erreichbare Adressen, alle Adressen, ID)] für alle installierten Repositories - auch die, die mit
    Kodi kommen (z.B. das offizielle). Läuft auf allen Systemen (Adressen aus den addon.xml, Pfade von Kodi)."""
    repos = (jsonrpc("Addons.GetAddons", {"type": "xbmc.addon.repository", "properties": ["path", "name", "enabled"]})
             or {}).get("addons", [])
    if not repos:   # sehr alte Kodi-Versionen ohne Typ-Filter: Ordner durchsuchen
        repos = [{"addonid": os.path.basename(p), "path": p} for p in sorted(glob.glob(os.path.join(ADDONS,
                                                                                                       "repository.*")))]
    results = []
    for index, repo in enumerate(sorted(repos, key=lambda r: r.get("addonid", ""))):
        urls, name = _repo_urls(repo.get("path") or os.path.join(ADDONS, repo.get("addonid", "")))
        if not urls:
            continue
        if progress:
            progress(index * 100 // max(1, len(repos)), name)
        ok = sum(1 for url in urls if _reachable(url))
        results.append((re.sub(r"\[/?[A-Z]+[^\]]*\]", "", repo.get("name") or name), ok, len(urls),
                        repo.get("addonid", "")))
    return results


def _reachable(url, timeout=8):
    """Antwortet die Adresse? Erst HEAD, sonst GET (nur der Anfang wird gelesen)"""
    headers = {"User-Agent": "Kodi"}
    try:
        request = urllib.request.Request(url, headers=headers, method="HEAD")
        with urllib.request.urlopen(request, timeout=timeout, context=net._context()) as response:
            return response.status < 400
    except Exception:  # noqa: BLE001 - manche Server kennen kein HEAD
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout,
                                        context=net._context()) as response:
                response.read(1024)
                return response.status < 400
        except Exception:  # noqa: BLE001
            return False


UPDATE_MODES = ["Automatisch installieren", "Nur benachrichtigen", "Nie prüfen"]


def update_mode():
    value = get_setting("general.addonupdates")
    return value if isinstance(value, int) and 0 <= value <= 2 else 0


def set_update_mode(value):
    set_setting("general.addonupdates", int(value))


# ====================== Logging-Tools ======================

def log_file(old=False):
    return os.path.join(LOGPATH, "kodi.old.log" if old else "kodi.log")


def read_log(path, limit=400 * 1024):
    try:
        with open(path, "rb") as f:
            f.seek(max(0, os.path.getsize(path) - limit))
            return f.read().decode("utf-8", "replace")
    except OSError:
        return ""


def wizard_log():
    return read_log(WIZARD_LOG)


def log_problems(text):
    lines = [l for l in text.splitlines() if " error " in l.lower() or " warning " in l.lower()]
    errors = sum(1 for l in lines if " error " in l.lower())
    return lines, errors, len(lines) - errors


LOG_FILTERS = [("errors", "Nur Fehler"), ("problems", "Fehler und Warnungen"), ("term", "Begriff suchen ..."),
               ("addon", "Nach Addon ...")]
ADDON_RE = re.compile(r"\b((?:plugin|script|service|repository|pvr|skin|inputstream|resource|metadata|weather|"
                      r"context|module|screensaver|audioencoder|audiodecoder|imagedecoder|game|vfs|visualization)"
                      r"\.[A-Za-z0-9_.\-]*[A-Za-z0-9])")
# Zugangsdaten im Log unkenntlich machen (für Export und Support)
SECRET_PATTERNS = [
    (re.compile(r"(?i)((?:pass(?:word|wd)?|pwd|token|api[_-]?key|apikey|secret|auth|session|mac|sn|serial)"
                r"[\"']?\s*[=:]\s*[\"']?)([^\s\"'&,;<>]+)"), r"\1***"),
    (re.compile(r"(?i)(\w+://)([^/\s:@]+):([^/\s@]+)@"), r"\1***:***@"),
    (re.compile(r"(?i)\b([0-9a-f]{2}[:-]){5}[0-9a-f]{2}\b"), "**:**:**:**:**:**"),
    (re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._\-]+"), r"\1***"),
]


def filter_log(text, mode, term=""):
    """Zeilen des Logs nach Art filtern: errors, problems (Fehler+Warnungen), term (Begriff), addon (Addon-ID)"""
    lines = text.splitlines()
    if mode == "errors":
        return [l for l in lines if " error " in l.lower() or " fatal " in l.lower()]
    if mode == "problems":
        return log_problems(text)[0]
    needle = (term or "").strip().lower()
    if not needle:
        return lines
    return [l for l in lines if needle in l.lower()]


def log_addons(text, limit=40):
    """Addon-IDs, die im Log vorkommen - häufigste zuerst: [(id, Anzahl)]"""
    counts = {}
    for match in ADDON_RE.finditer(text):
        addon = match.group(1).rstrip(".")
        counts[addon] = counts.get(addon, 0) + 1
    return sorted(counts.items(), key=lambda x: (-x[1], x[0]))[:limit]


def scrub_log(text):
    for pattern, replacement in SECRET_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def export_log(text, folder, name):
    """Text als Datei speichern - auch auf USB-Sticks und Netzwerkfreigaben (smb://, nfs://)"""
    import xbmcvfs
    target = folder.rstrip("/\\") + ("\\" if "\\" in folder and "://" not in folder else "/") + name
    handle = xbmcvfs.File(target, "w")
    try:
        ok = handle.write(bytearray(text.encode("utf-8")))
    finally:
        handle.close()
    if ok is False:
        raise IOError("Datei konnte nicht geschrieben werden: " + target)
    return target


def debug_logging():
    return bool(get_setting("debug.showloginfo"))


def set_debug_logging(on):
    set_setting("debug.showloginfo", bool(on))


# ====================== System Tweaks ======================

ADVANCED = os.path.join(USERDATA, "advancedsettings.xml")


def _merge_advanced(sections):
    try:
        tree = ET.parse(ADVANCED)
        root = tree.getroot()
    except (OSError, ET.ParseError):
        root = ET.Element("advancedsettings", version="1.0")
        tree = ET.ElementTree(root)
    for section, values in sections.items():
        node = root.find(section)
        if node is None:
            node = ET.SubElement(root, section)
        for key, value in values.items():
            child = node.find(key)
            if child is None:
                child = ET.SubElement(node, key)
            child.text = value
    tree.write(ADVANCED, encoding="utf-8", xml_declaration=True)


def advanced_text():
    try:
        with open(ADVANCED, "r", encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


def apply_network_preset():
    _merge_advanced({"network": {"curlclienttimeout": "30", "curllowspeedtime": "20", "curlretries": "2"}})


def remove_advanced():
    try:
        os.remove(ADVANCED)
        return True
    except OSError:
        return False


def unknown_sources():
    return bool(get_setting("addons.unknownsources"))


def set_unknown_sources(on):
    set_setting("addons.unknownsources", bool(on))


REFRESH_MODES = ["Aus", "Beim Start/Ende", "Immer"]


def refresh_mode():
    value = get_setting("videoplayer.adjustrefreshrate")
    return value if isinstance(value, int) and 0 <= value <= 2 else 0


def set_refresh_mode(value):
    set_setting("videoplayer.adjustrefreshrate", int(value))


def speedtest(progress=None, size=25 * 1000 * 1000):
    """Download-Geschwindigkeit in Mbit/s (Testdatei von Cloudflare)"""
    url = "https://speed.cloudflare.com/__down?bytes={0}".format(size)
    start = time.time()
    loaded = 0
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Kodi"}), timeout=30,
                                context=net._context()) as response:
        while True:
            chunk = response.read(256 * 1024)
            if not chunk:
                break
            loaded += len(chunk)
            if progress and progress(loaded * 100 // size) is False:
                break
    seconds = max(0.001, time.time() - start)
    return loaded * 8 / seconds / 1000000.0


# ====================== Misc Maintenance ======================

def reload_profile():
    xbmc.executebuiltin("ReloadSkin()")


def check_sources():
    """[(Name, Pfad, ok)] aus sources.xml - Netzwerkfreigaben (smb, nfs) werden nicht geprüft"""
    results = []
    try:
        root = ET.parse(os.path.join(USERDATA, "sources.xml")).getroot()
    except (OSError, ET.ParseError):
        return results
    for source in root.iter("source"):
        name = source.findtext("name") or ""
        path = (source.findtext("path") or "").strip()
        if path.startswith(("http://", "https://")):
            ok = _reachable(path)
        elif path.startswith(("smb://", "nfs://", "upnp://", "plugin://", "addons://")):
            ok = None
        else:
            ok = os.path.exists(translate(path))
        results.append((name, path, ok))
    return results


def repair_addon_database():
    """Addon-Datenbank löschen - Kodi baut sie beim nächsten Start neu auf (danach alle Addons einschalten)"""
    for db in glob.glob(os.path.join(DATABASE, "Addons*.db")):
        try:
            os.remove(db)
        except OSError:
            pass
    state = load_state()
    state["enable_all_pending"] = True
    save_state(state)


def reset_skin():
    set_setting("lookandfeel.skin", "skin.estuary")


def fresh_start(ui):
    """Kodi auf Werkseinstellung - Save Data und Whitelist bleiben"""
    from resources.lib import builds
    ui.step("Save Data sichern")
    savedata.save()
    ui.step("Aufräumen")
    errors = builds.wipe(savedata.whitelist())
    ui.step("Save Data zurückspielen")
    savedata.restore()
    state = load_state()
    state["build"] = None
    state["restore_update_mode"] = None     # Kodi-Einstellungen sind jetzt ohnehin im Werkszustand
    state["rss_applied"] = ""               # Laufschrift beim nächsten Start neu eintragen
    save_state(state)
    try:
        os.remove(builds.MARKER)
    except OSError:
        pass
    log("Fresh Start ausgeführt ({0} Fehler)".format(errors))
    return errors
