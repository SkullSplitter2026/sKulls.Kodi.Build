[![GitHub release](https://img.shields.io/github/release/add-ons/script.speedtester.svg)](https://github.com/add-ons/script.speedtester/releases)
[![Build status](https://github.com/add-ons/script.speedtester/workflows/CI/badge.svg)](https://github.com/add-ons/script.speedtester/actions)
[![Codecov status](https://img.shields.io/codecov/c/github/add-ons/script.speedtester/master)](https://codecov.io/gh/add-ons/script.speedtester/branch/master)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache2-yellow.svg)](https://opensource.org/licenses/Apache-2.0)
[![Contributors](https://img.shields.io/github/contributors/add-ons/script.speedtester.svg)](https://github.com/add-ons/script.speedtester/graphs/contributors)

# Kodi Speedtester add-on
**script.speedtester** is a [Kodi](https://kodi.tv/) add-on for testing your Internet bandwidth.


## Installing
This add-on ships with Kodi.

In Kodi, simply search the add-ons for `Speed` and install the Speedtester add-on.


## Releases

### v2.0.1 (2026-09-28)
- Unofficial update by The Red Wizard
- Numbered above the official Kodi repository 2.0.0, so that update does not replace this newer code

### v1.1.5 (2026-08-30)
- Unofficial update by The Red Wizard
- Keeps local results if there is no speedtest.net image
- Upload tries HTTPS first, then HTTP, instead of failing immediately
- Shows a toast if the test fails
- Ping uses a 10 second timeout and averages the probes that actually ran

### v1.1.4 (2026-08-28)
- Unofficial update by The Red Wizard
- Modern Ookla server discovery (api/js/servers) replacing the deprecated servers-static.php list
- Automatic nearest-server selection worldwide, plus optional city/country search or specific server ID
- Prefer-HTTPS server option and configurable connection timeout
- Optional download-only mode and optional result submission, off by default
- Settings and extra translations from script.speedtester pull request 31
- Python 3.9-3.12 compatibility (threading is_set) for Kodi 19-21

### v1.1.3 (2022-01-26)
- Add support for Python 3.9 and later (@dobo90)
- Add Dutch translations (@dagwieers)

### v1.1.2 (2020-10-10)
- Fix issues for Kodi repo review (@dagwieers)

### v1.1.1 (2020-10-10)
- Add localization (@dagwieers)

### v1.1.0 (2020-09-26)
- Move add-on to Add-ons project (@dagwieers)
- Fix typos and structure of standard output (@dagwieers)

### v1.0.1 (2019-08-06)
- Initial release (@Dr0idGuy)


## Thanks
- Original add-on by Dr0idGuy
- Icon made by Freepik from www.flaticon.com
